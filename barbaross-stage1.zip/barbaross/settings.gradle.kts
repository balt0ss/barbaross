pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "barbaross"

include(":ipc")      // общий IPC-контракт (Binder) между IDE и Build Runtime
include(":runtime")  // библиотека: сервис сборки (запускается в отдельном процессе :build)
include(":ide")      // единственное приложение (APK) Barbaross IDE

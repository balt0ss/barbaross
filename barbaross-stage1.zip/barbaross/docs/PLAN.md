# Barbaross IDE — план и статус

## Изменения в barbaross-stage1 (подготовка stage2)

- Исправлен `RuntimeClient`: при `bindService() == false` больше не вызывается ошибочный `unbindService()`.
- Подключение Binder и чтение статуса Runtime перенесены с главного потока на `Dispatchers.IO`.
- Добавлена обработка `onBindingDied` и `onNullBinding`, а устаревшие callbacks после отключения игнорируются.
- CI теперь явно устанавливает `platforms;android-36` и `build-tools;36.0.0`, необходимые для `compileSdk = 36`.
- Удалена повторяющаяся строка успешного результата в логе AndroidBuildProbe.
- Локальная Gradle-сборка в среде ChatGPT не завершена: загрузка Gradle Wrapper заблокирована отсутствием DNS-доступа к `services.gradle.org`. Требуется запуск GitHub Actions; компиляция этих изменений пока не подтверждена.

## Статус проверки (этап 1)

| Что | Статус |
|---|---|
| Исходники каркаса (3 Gradle-модуля) | написаны |
| Сборка APK (одного, после объединения) | **НЕ ВЫПОЛНЯЛАСЬ** — в среде разработки закрыты Google Maven, Maven Central, Gradle, нет Android SDK |
| Юнит-тесты (`BuildProtocolTest`) | **НЕ ЗАПУСКАЛИСЬ** по той же причине |
| Проверка на устройстве | не выполнялась |

Единственный способ проверить сборку: запустить `.github/workflows/build.yml` на GitHub
(или `gradle :ipc:testDebugUnitTest :ide:assembleDebug` на машине с JDK 17 и Android SDK 36).
Результаты первой сборки нужно прислать — этап 2 начинается только после зелёного CI.

## Версии зависимостей (не проверены сборкой)

- Проверено по документации: актуальная линия AGP — 9.x (9.2.0 требует Gradle 9.4.1, JDK 17, Build Tools 36.0.0, KGP ≥ 2.2.10, API до 37);
  Compose BOM 2026.09.00 содержит Material 3 1.4.0 (не подтверждено, что это stable).
- Выбрано: AGP 8.13.0 + Gradle 8.14.3 + Kotlin 2.2.10. Причина: AGP 9 меняет модель Kotlin/DSL, а проверить миграцию без сборки нельзя.
  Миграция на AGP 9.x — отдельный шаг после зелёного CI.
- Не проверены по источникам: activity-compose 1.11.0, core-ktx 1.17.0, lifecycle 2.9.4, coroutines 1.10.2.
- Gradle wrapper не сгенерирован (нет доступа к дистрибутиву); CI использует Gradle 8.14.3 напрямую.

## Архитектура (этап 1.5: один APK)

- `:ipc` — общий контракт (`IBuildService` — Binder, написанный вручную, и `BuildProtocol`) с версией протокола.
  AIDL не используется: `aidl` из Build Tools — бинарник x86_64 и не запускается на arm64-телефоне.
- `:runtime` (`dev.barbaross.runtime`) — теперь **Android-библиотека**, а не приложение: `BuildService`, `ToolchainInspector`.
  Сервис объявлен в манифесте библиотеки как `exported=false`, `android:process=":build"` (отдельный процесс для тяжёлой работы Gradle/JDK).
- `:ide` (`dev.barbaross.ide`) — **единственное приложение/APK**; зависит от `:runtime` и `:ipc`. `RuntimeClient` делает bind
  явным Intent на `BuildService` в собственном пакете.
- Signature-permission и двойная подпись больше не нужны (сервис не экспортирован). `<queries>` убран.
- CI собирает только `:ide:assembleDebug` и проверяет, что в манифесте APK есть `BuildService` с процессом `:build`.

Что изменено относительно этапа 1: удалены `RuntimeStatusActivity`, permission `BIND_BUILD_RUNTIME`, константы
`RUNTIME_PACKAGE/ACTION_BIND/PERMISSION_BIND`; состояния `NotInstalled/PermissionDenied` заменены на `ServiceUnavailable`.

## Диагностика исполнения (протокол IPC v2)

Кнопка «Диагностика исполнения» в Настройках IDE запускает `ExecProbe` в процессе `:build` и показывает: модель, API, ABI,
targetSdk, RAM, свободное место, запуск `/system/bin/sh`, запуск скрипта и копии бинарника из `filesDir` (ожидаемо запрещено при
targetSdk >= 29), содержимое `nativeLibraryDir`. Результат с POCO F4 определяет выбор в риске 1 (nativeLibraryDir vs targetSdk 28).

## Результат диагностики (POCO F4, Android 14, 7,6 ГБ RAM)

| Проба | targetSdk 36 | targetSdk 28 |
|---|---|---|
| exec скрипта из filesDir | запрещено (EACCES) | работает |
| exec бинарника из filesDir | запрещено (EACCES) | работает |
| бинарник через linker64 | работает | работает |
| System.load из filesDir | работает | работает |

**Решение: targetSdk 28** (риск 1 закрыт). linker64 на 36 не годится: Gradle/AGP порождают дочерние процессы обычным exec.
Ограничения: не для Google Play; системы будущих версий Android могут поднять минимальный targetSdk для установки
(Android 14: >= 23) — следить. Остаются риски 2–5: bionic/arm64-сборки JDK и Build Tools, память (свободно ~1,2–1,5 ГБ
при 7,6 ГБ всего), phantom process killer, размер.

## Проба JDK (протокол IPC v3)

Кнопка «Проба JDK» в Настройках: в процессе `:build` скачивает `openjdk-17` и зависимости из `packages.termux.dev/apt/termux-main`
(aarch64), проверяет SHA256, распаковывает .deb (ar + tar.xz) в `filesDir/jdkprobe/root` и запускает `java -version`
с `LD_LIBRARY_PATH`. Цель — выяснить, мешает ли жёсткий префикс `/data/data/com.termux/files/usr` при нашем applicationId.
Требует разрешение INTERNET (добавлено в манифест IDE). Зависимости: commons-compress 1.27.1, xz 1.10 (не проверены сборкой).

## Проба JDK — результат и проба Gradle (протокол IPC v4)

**JDK:** `openjdk-17` из Termux (aarch64) скачивается, распаковывается в `filesDir/jdkprobe/root` и **запускается** на POCO F4
(`java -version`, 17.0.21) с `LD_LIBRARY_PATH=<usr>/lib`. Жёсткий префикс Termux не помешал. Из 38 скачанных пакетов часть (pulseaudio,
alsa, x11, dbus…) не нужна — урезать в установщике.

**Gradle:** кнопка «Проба Gradle» скачивает gradle-8.14.3-bin.zip (проверка SHA256 с services.gradle.org), запускает
`java -classpath gradle-launcher-*.jar org.gradle.launcher.GradleMain --version` и собирает мини-проект на чистой Java
(`--no-daemon`, `org.gradle.jvmargs=-Xmx512m`). Лог показывает время и свободную RAM до/после, код 137 = убит системой.

## Результат пробы Gradle и проба сборки Android (протокол IPC v5)

**Gradle 8.14.3 работает** на Termux-JDK 17: `--version`, форк single-use daemon, сборка Java-проекта за 12 с, свободная RAM ~1,9 ГБ.

**Проба сборки Android** («Проба сборки Android-приложения»): ставит `aapt2` (Termux, arm64) в тот же префикс, скачивает из репозитория
Google `platforms;android-36` и `build-tools;36.0.0` (SHA1 проверяется; бинарники build-tools x86_64, `aapt2` подменяется arm64-версией),
создаёт проект (Java, AGP 8.13.0, без AndroidX) и запускает `assembleDebug` с `android.aapt2FromMavenOverride`.
Ожидаемые места отказа: `jlink`/jmods в Termux-JDK (AGP трансформирует android.jar для compileSdk >= 34), версия aapt2 vs AGP,
память (Xmx1024m), phantom process killer. Скачивание SDK подразумевает принятие Android SDK License — в продукте нужен экран согласия.

## Результат пробы сборки Android (POCO F4, Android 14)

**`BUILD SUCCESSFUL in 31s`**: Gradle 8.14.3 + AGP 8.13.0 + compileSdk 36 + aapt2 из Termux (`android.aapt2FromMavenOverride`)
собрали Android-приложение прямо на телефоне. 34 задачи, свободная RAM ~1,7 ГБ до и после. `jlink` не понадобился.
Замечания из лога: нет доступа к `~/.android` (метрики, безвредно); предупреждение о лицензии platform-tools (не мешает);
`minSdk 29 > targetSdk 28` — исправлено: minSdk установлен в 28 во всех Android-модулях. Проверка наличия APK в пробе искала неверное имя файла (исправлено:
имя берётся от `rootProject.name`). Добавлена кнопка установки собранного APK (FileProvider + REQUEST_INSTALL_PACKAGES).

## Проба Kotlin + Compose (протокол IPC v6)

Тот же `AndroidBuildProbe` в режиме `compose`: проект на Kotlin 2.2.10 + Compose BOM 2025.10.00 + activity-compose 1.11.0, компилятор Kotlin
внутри процесса Gradle (`kotlin.compiler.execution.strategy=in-process`, `-Xmx1536m`), SDK и aapt2 общие с базовой пробой
(`androidprobe/sdk`). Проверяет память и работу Kotlin-компилятора/Compose-плагина на bionic-JDK — это стек самой Barbaross IDE.

## Главные риски локальной сборки (исследовать на этапе 5 до написания кода)

1. **Исполняемые файлы.** При targetSdk ≥ 29 нельзя запускать бинарники из записываемых каталогов приложения (`filesDir`).
   Варианты: поставлять бинарники как нативные библиотеки в `nativeLibraryDir`; либо targetSdk ≤ 28 (подход Termux) —
   тогда ограничения на установку/распространение (в т.ч. Android 14+ для старых targetSdk) нужно проверить на реальном устройстве.
2. **Архитектура инструментов.** Официальные `aapt2`, `d8`-обвязка и прочие Build Tools из Android SDK — под Linux x86_64/Windows/macOS.
   Для arm64-Android нужны отдельные сборки (напр. из Termux-пакетов); их лицензии, версии и совместимость с AGP — открытый вопрос.
3. **JDK 17 для arm64 Android** и объём памяти: Gradle + Kotlin daemon реально требуют несколько ГБ RAM.
4. **Убийство дочерних процессов** (Android 12+ phantom process killer) и требования к foreground service (Android 14+).
5. **Размер**: JDK + Gradle + SDK + кэш зависимостей — порядка нескольких ГБ; нужна проверка свободного места до запуска.

## Этап 2 — проекты и файловая система (реализация в текущем ZIP)

- Добавлен экран «Проекты»: открытие существующей папки через Android Storage Access Framework (SAF) и создание проекта внутри выбранной родительской папки.
- Используется `DocumentFile`; запрашиваются только пользовательские разрешения на выбранное дерево, без широкого доступа к памяти устройства.
- Сохранение URI-разрешений и списка до 12 последних проектов в приватных настройках приложения; повторное открытие после перезапуска.
- Реализованы просмотр папок, создание файлов и каталогов, переименование, удаление, копирование и перемещение элементов в корень проекта (пока без произвольного выбора целевой папки).
- Добавлен текстовый просмотр/простое редактирование файлов с ограничением чтения 1 МиБ; полноценный редактор, вкладки и защита несохранённых изменений остаются этапами 3–4.
- Добавлена зависимость AndroidX DocumentFile 1.1.0 (официальный стабильный релиз).
- **Проверка сборкой не выполнена** в текущей среде: нет установленного Gradle и Android SDK; требуется CI и проверка на POCO F4. Возможны несовместимости отдельных SAF-провайдеров — проверить создание, переименование, копирование и удаление на внутреннем накопителе и SD-карте.

## Этапы

1. Каркас, IPC-контракт, CI — **сделано**; 1.5 — объединение в один APK — **сделано в коде, ожидает проверки CI и установки на POCO F4**
2. Проекты и файлы (основная реализация добавлена, ожидает CI и тестирования на устройстве)
3. Редактор (ввод, номера строк, undo/redo, автозакрытие скобок, подсветка)
4. Вкладки, поиск/замена, защита несохранённых изменений
5. Терминал и исследование исполнения бинарников (риски 1–4)
6. Локальная сборка APK через Runtime (установка инструментов, запуск Gradle, логи, отмена)
7. Git
8. Система расширений (манифест, версия API, разрешения, изоляция)
9. ИИ-помощник (провайдеры, ключи в Keystore, полностью отключаемый)

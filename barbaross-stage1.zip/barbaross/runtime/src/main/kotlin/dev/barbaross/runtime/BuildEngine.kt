package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Движок сборки: запускает Gradle (на установленном JDK) для проекта из filesDir/projects.
 * Все настройки (aapt2, память, Kotlin in-process, SDK) передаются через аргументы и окружение,
 * файлы проекта не изменяются. Лог читается порциями по смещению (лимит Binder ~1 МБ).
 */
object BuildEngine {
    const val IDLE = 0
    const val RUNNING = 1
    const val SUCCESS = 2
    const val FAILED = 3
    const val CANCELLED = 4

    private const val MAX_LOG_CHARS = 4_000_000
    private const val CHUNK = 100_000

    private val running = AtomicBoolean(false)
    private val log = StringBuffer()
    @Volatile private var state = IDLE
    @Volatile private var exitCode = 0
    @Volatile private var cancelled = false
    @Volatile private var proc: Process? = null
    @Volatile private var apkPath: String? = null
    @Volatile private var truncated = false

    /** Возвращает текст ошибки, если сборка не запущена, иначе null. */
    fun start(context: Context, project: String, task: String, cb: JobCallbacks): String? {
        val paths = ToolchainPaths(context)
        if (!paths.isReady()) return "Инструменты не установлены. Установите их в Настройках."
        if (!Regex("[A-Za-z0-9:_-]{1,64}").matches(task)) return "Недопустимое имя задачи."
        val dir = File(project).canonicalFile
        val allowed = File(context.filesDir, "projects").canonicalFile
        if (!dir.path.startsWith(allowed.path + File.separator) || !dir.isDirectory) {
            return "Проект должен находиться в каталоге проектов IDE."
        }
        if (!File(dir, "settings.gradle").isFile && !File(dir, "settings.gradle.kts").isFile) {
            return "В проекте нет settings.gradle(.kts)."
        }
        if (!running.compareAndSet(false, true)) return "Сборка уже выполняется."

        log.setLength(0)
        truncated = false
        cancelled = false
        apkPath = null
        exitCode = 0
        state = RUNNING
        cb.started("Сборка: ${dir.name}")
        Thread({
            try {
                runBuild(paths, dir, task)
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
                state = FAILED
            } finally {
                proc = null
                running.set(false)
                cb.finished()
            }
        }, "build-engine").start()
        return null
    }

    fun cancel() {
        if (state != RUNNING) return
        cancelled = true
        proc?.destroy()
        killGradleProcesses()
        proc?.destroyForcibly()
    }

    /** Порция лога начиная с offset (в символах) + состояние. */
    fun readLog(offset: Int): Bundle {
        val len = log.length
        val from = offset.coerceIn(0, len)
        val to = minOf(len, from + CHUNK)
        return Bundle().apply {
            putString("text", log.substring(from, to))
            putInt("next", to)
            putInt("state", state)
            putInt("exit", exitCode)
            putString("apk", apkPath)
        }
    }

    private fun say(s: String) {
        if (log.length > MAX_LOG_CHARS) {
            if (!truncated) {
                truncated = true
                log.append("\n[лог обрезан: слишком длинный]\n")
            }
            return
        }
        log.append(s).append('\n')
    }

    private fun runBuild(paths: ToolchainPaths, dir: File, task: String) {
        paths.tmp.mkdirs()
        val jar = paths.gradleLauncherJar() ?: run { say("Gradle не найден."); state = FAILED; return }
        val tmp = paths.tmp.absolutePath
        val jvmArgs = "-Xmx1536m -XX:MaxMetaspaceSize=512m -Djava.io.tmpdir=$tmp -Duser.home=$tmp"
        val cmd = listOf(
            paths.java.absolutePath, "-Xmx64m", "-Xms64m", "-Dorg.gradle.appname=gradle",
            "-Djava.io.tmpdir=$tmp", "-Duser.home=$tmp",
            "-classpath", jar.absolutePath, "org.gradle.launcher.GradleMain",
            "--no-daemon", "--console=plain", "--stacktrace", "--max-workers=2",
            "-Dorg.gradle.jvmargs=$jvmArgs",
            "-Pandroid.aapt2FromMavenOverride=${paths.aapt2.absolutePath}",
            "-Pkotlin.compiler.execution.strategy=in-process",
            task,
        )
        say("$ gradle $task  (проект: ${dir.name})")
        val t0 = System.currentTimeMillis()
        val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
        pb.environment().putAll(paths.env())
        val p = pb.start()
        proc = p
        val reader = Thread { p.inputStream.bufferedReader().forEachLine { say(it) } }.apply { isDaemon = true; start() }
        val code = p.waitFor()
        reader.join(3000)
        exitCode = code
        val secs = (System.currentTimeMillis() - t0) / 1000
        when {
            cancelled -> {
                state = CANCELLED
                say("\nОТМЕНЕНО (${secs} с)")
            }
            code == 0 -> {
                state = SUCCESS
                apkPath = File(dir, "build/outputs/apk/debug").listFiles { f -> f.name.endsWith(".apk") }?.firstOrNull()?.absolutePath
                say("\nУСПЕХ (${secs} с)" + (apkPath?.let { "\nAPK: $it" } ?: ""))
            }
            else -> {
                state = FAILED
                say("\nОШИБКА: код выхода $code (${secs} с)" +
                    if (code == 137 || code == 143 || code == 9) "\nПроцесс убит системой (память или phantom process killer)." else "")
            }
        }
    }

    /** Gradle может форкнуть single-use daemon: убиваем все свои процессы Gradle/Kotlin, кроме сервиса. */
    private fun killGradleProcesses() {
        val me = android.os.Process.myPid()
        File("/proc").listFiles()?.forEach { f ->
            val pid = f.name.toIntOrNull() ?: return@forEach
            if (pid == me) return@forEach
            val cmd = try { File(f, "cmdline").readText() } catch (e: Exception) { return@forEach }
            if ("org.gradle" in cmd || "GradleDaemon" in cmd || "kotlin-compiler" in cmd) {
                android.os.Process.killProcess(pid)
            }
        }
    }
}

package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import android.os.Process as AndroidProcess
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Простой терминал: одна команда за раз через `sh -c`, вывод накапливается в буфере и читается по смещению.
 * Ввода с клавиатуры в процесс нет (stdin закрыт), поэтому интерактивные программы не подойдут.
 */
object TerminalSupport {
    private const val MAX_BUF = 400_000
    private const val CHUNK = 200_000

    private val running = AtomicBoolean(false)
    private val lock = Any()
    private val buf = StringBuilder()
    private var total = 0L
    @Volatile private var exit = 0
    @Volatile private var proc: Process? = null
    @Volatile private var marker = ""

    private fun append(s: String) = synchronized(lock) {
        buf.append(s)
        total += s.length
        if (buf.length > MAX_BUF) buf.delete(0, buf.length - MAX_BUF)
    }

    private fun failure(text: String) = Bundle().apply { putString("error", text) }

    fun start(context: Context, dirPath: String, command: String, cb: JobCallbacks): Bundle {
        if (command.isBlank()) return failure("Пустая команда.")
        val p = ToolchainPaths(context)
        if (!p.isReady()) return failure("Сначала установите инструменты сборки (Настройки).")
        val projects = File(context.filesDir, "projects").apply { mkdirs() }.canonicalFile
        val dir = File(dirPath).canonicalFile
        if (!(dir == projects || dir.path.startsWith(projects.path + File.separator)) || !dir.isDirectory) {
            return failure("Каталог должен быть внутри каталога проектов IDE.")
        }
        if (!running.compareAndSet(false, true)) return failure("Команда уже выполняется.")

        val id = UUID.randomUUID().toString()
        marker = id
        synchronized(lock) {
            buf.setLength(0)
            total = 0
        }
        exit = 0
        cb.started("Терминал")

        val bin = File(p.root, "bin").apply { mkdirs() }
        p.gradleLauncherJar()?.let { jar ->
            val script = File(bin, "gradle")
            script.writeText(
                "#!/system/bin/sh\n" +
                    "exec '${p.java.absolutePath}' -Xmx1536m -classpath '${jar.absolutePath}' org.gradle.launcher.GradleMain \"\$@\"\n"
            )
            script.setExecutable(true, false)
        }

        val env = GitSupport.gitEnv(p, "", "", "", null, null).toMutableMap()
        env["PATH"] = bin.absolutePath + ":" + File(p.javaHome, "bin").absolutePath + ":" + File(p.usr, "bin").absolutePath + ":/system/bin"
        env["TERM"] = "dumb"
        env["BARBAROSS_TERM"] = id
        env["PWD"] = dir.absolutePath

        Thread({
            try {
                val pb = ProcessBuilder("/system/bin/sh", "-c", command).directory(dir).redirectErrorStream(true)
                pb.environment().putAll(env)
                val pr = pb.start()
                proc = pr
                try { pr.outputStream.close() } catch (_: Exception) {}
                val reader = pr.inputStream.bufferedReader()
                val chars = CharArray(4096)
                while (true) {
                    val n = reader.read(chars)
                    if (n < 0) break
                    append(String(chars, 0, n))
                }
                exit = pr.waitFor()
            } catch (e: Exception) {
                append("\nОшибка запуска: ${e.javaClass.simpleName}: ${e.message}\n")
                exit = -1
            } finally {
                proc = null
                running.set(false)
                cb.finished()
            }
        }, "terminal").start()
        return Bundle().apply { putBoolean("ok", true) }
    }

    fun read(offset: Long): Bundle = synchronized(lock) {
        val base = total - buf.length
        val from = offset.coerceIn(base, total)
        val end = minOf(total, from + CHUNK)
        val text = buf.substring((from - base).toInt(), (end - base).toInt())
        Bundle().apply {
            putString("text", text)
            putLong("next", end)
            putBoolean("running", running.get())
            putInt("exit", exit)
        }
    }

    /** Останавливает команду и все её дочерние процессы (находятся по метке в окружении). */
    fun stop() {
        val id = marker
        if (id.isNotEmpty()) {
            val needle = "BARBAROSS_TERM=$id".toByteArray()
            val self = AndroidProcess.myPid()
            File("/proc").listFiles()?.forEach { d ->
                val pid = d.name.toIntOrNull() ?: return@forEach
                if (pid == self) return@forEach
                try {
                    val env = File(d, "environ").readBytes()
                    if (indexOf(env, needle) >= 0) AndroidProcess.killProcess(pid)
                } catch (_: Exception) {
                }
            }
        }
        proc?.destroyForcibly()
    }

    private fun indexOf(hay: ByteArray, needle: ByteArray): Int {
        outer@ for (i in 0..hay.size - needle.size) {
            for (j in needle.indices) if (hay[i + j] != needle[j]) continue@outer
            return i
        }
        return -1
    }
}

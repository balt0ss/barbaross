package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/** Колбэки фонового задания: сервис по ним включает/выключает foreground-режим. */
class JobCallbacks(val started: (String) -> Unit, val finished: () -> Unit)

/**
 * Установщик инструментов: JDK 17 + aapt2 (пакеты Termux, aarch64), Gradle, Android SDK (platform + build-tools).
 * Работает в фоне, пишет лог, поддерживает отмену и докачку (уже установленные пакеты пропускаются).
 * Согласие с лицензией Android SDK обязано быть получено в UI до вызова start.
 */
object ToolchainInstaller {
    private const val SDK_REPO = "https://dl.google.com/android/repository"
    private const val LICENSE_URL = "https://developer.android.com/studio/terms"
    private const val MB = 1024L * 1024L

    /** Пакеты, не нужные для сборки (звук/графика); если без них java не стартует — ставится полный набор. */
    private val TRIM = setOf(
        "pulseaudio", "alsa-lib", "alsa-plugins", "dbus", "libx11", "libxcb", "xorgproto", "libxau", "libxdmcp",
        "xorg-util-macros", "libsndfile", "libsoxr", "libwebrtc-audio-processing", "speexdsp", "libflac",
        "libmp3lame", "libmpg123", "libogg", "libopus", "libvorbis", "libltdl",
    )

    private class CancelledException : RuntimeException("отменено")

    private val running = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    @Volatile private var success = false
    @Volatile private var done = false
    private val log = StringBuffer()

    fun start(context: Context, cb: JobCallbacks): Boolean {
        if (!running.compareAndSet(false, true)) return false
        cancelled.set(false)
        success = false
        done = false
        log.setLength(0)
        val app = context.applicationContext
        cb.started("Установка инструментов")
        Thread({
            try {
                success = run(app)
            } catch (c: CancelledException) {
                say("Отменено пользователем.")
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                done = true
                running.set(false)
                cb.finished()
            }
        }, "toolchain-install").start()
        return true
    }

    fun cancel() {
        cancelled.set(true)
    }

    // ---------- дополнительные версии (JDK, Gradle, платформы SDK, build-tools) ----------

    /** Возвращает текст ошибки, если установка не запущена, иначе null. Лог и отмена — те же, что у основной установки. */
    fun installVersion(context: Context, kind: String, value: String, cb: JobCallbacks): String? {
        val ok = when (kind) {
            "jdk" -> value.matches(Regex("\\d{1,2}"))
            "gradle", "buildtools" -> value.matches(Regex("[0-9][0-9.]{0,15}"))
            "platform" -> value.matches(Regex("\\d{2,3}"))
            else -> false
        }
        if (!ok) return "Недопустимое значение."
        if (!ToolchainPaths(context).isReady()) return "Сначала установите инструменты сборки."
        if (!running.compareAndSet(false, true)) return "Сейчас идёт другая установка."
        cancelled.set(false)
        success = false
        done = false
        log.setLength(0)
        val app = context.applicationContext
        cb.started("Установка: $kind $value")
        Thread({
            try {
                success = doInstallVersion(app, kind, value)
            } catch (c: CancelledException) {
                say("Отменено пользователем.")
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                done = true
                running.set(false)
                cb.finished()
            }
        }, "toolchain-version").start()
        return null
    }

    private fun doInstallVersion(context: Context, kind: String, value: String): Boolean {
        val p = ToolchainPaths(context)
        p.tmp.mkdirs(); p.cache.mkdirs()
        if (context.filesDir.usableSpace < 1024 * MB) {
            say("Нужно не менее 1 ГБ свободного места, сейчас ${context.filesDir.usableSpace / MB} МБ. Остановлено.")
            return false
        }
        return when (kind) {
            "jdk" -> installJdk(p, value)
            "gradle" -> {
                if (p.gradleDistDir(value) != null) {
                    say("Gradle $value уже установлен.")
                    true
                } else {
                    installGradleVersion(p, value)
                }
            }
            "platform" -> {
                val target = File(p.sdk, "platforms/android-$value")
                if (target.isDirectory) {
                    say("Платформа $value уже установлена.")
                    true
                } else {
                    val ok = installSdkPackage(loadRepositoryXml(), "platforms;android-$value", target, p)
                    if (ok) say("ГОТОВО: платформа Android API $value установлена.")
                    ok
                }
            }
            "buildtools" -> {
                val target = File(p.sdk, "build-tools/$value")
                if (target.isDirectory) {
                    say("Build-tools $value уже установлены.")
                    true
                } else {
                    val ok = installSdkPackage(loadRepositoryXml(), "build-tools;$value", target, p)
                    if (ok) {
                        p.aapt2.copyTo(File(target, "aapt2"), overwrite = true)
                        File(target, "aapt2").setExecutable(true, false)
                        say("ГОТОВО: build-tools $value установлены.")
                    }
                    ok
                }
            }
            else -> false
        }
    }

    private fun installJdk(p: ToolchainPaths, v: String): Boolean {
        val java = File(p.jdkHome(v), "bin/java")
        if (java.isFile) {
            say("JDK $v уже установлена.")
            return true
        }
        val roots = listOf("openjdk-$v")
        say("Ставлю openjdk-$v (пакеты Termux)")
        if (!JdkProbe.installPackages(roots, p.termuxRoot, p.cache, TRIM, { cancelled.get() }) { say(it) }) {
            say("Пакет openjdk-$v не найден в репозитории Termux или не установился.")
            return false
        }
        fun works(): Boolean {
            java.setExecutable(true, false)
            if (!java.isFile) {
                say("java не найден: ${java.absolutePath}")
                return false
            }
            val r = runCmd(listOf(java.absolutePath, "-version"), p.env(), p.tmp, 60)
            say("java -version: " + r.second.lines().firstOrNull().orEmpty())
            return r.first == 0
        }
        if (!works()) {
            say("С урезанным набором java не запустилась, ставлю полный набор.")
            if (!JdkProbe.installPackages(roots, p.termuxRoot, p.cache, emptySet(), { cancelled.get() }) { say(it) }) return false
            if (!works()) return false
        }
        say("ГОТОВО: JDK $v установлена. Выберите её активной в списке версий.")
        return true
    }

    private fun installGradleVersion(p: ToolchainPaths, v: String): Boolean {
        val dist = "https://services.gradle.org/distributions/gradle-$v-bin.zip"
        val zip = File(p.cache, "gradle-$v.zip")
        say("Скачиваю $dist")
        val expected = try {
            download(dist, zip)
            JdkProbe.open("$dist.sha256").use { it.bufferedReader().readText() }.trim().split(Regex("\\s+")).first()
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            say("Не удалось скачать Gradle $v: ${e.message}. Возможно, такой версии не существует.")
            zip.delete()
            return false
        }
        val actual = hash(zip, "SHA-256")
        if (!actual.equals(expected, ignoreCase = true)) {
            say("SHA256 Gradle не совпал (ожидалось $expected, получено $actual).")
            zip.delete()
            return false
        }
        val unpack = File(p.cache, "gradle-unpack").apply { StorageCleaner.deleteTree(this); mkdirs() }
        unzip(zip, unpack)
        zip.delete()
        val target = File(p.gradleVersionsDir, v)
        StorageCleaner.deleteTree(target)
        p.gradleVersionsDir.mkdirs()
        if (!unpack.renameTo(target)) {
            unpack.copyRecursively(target, overwrite = true)
            StorageCleaner.deleteTree(unpack)
        }
        val jar = p.gradleLauncherJar(v)
        if (jar == null) {
            say("В архиве не найден gradle-launcher.")
            StorageCleaner.deleteTree(target)
            return false
        }
        val g = runCmd(
            listOf(p.java.absolutePath, "-Xmx64m", "-Dorg.gradle.appname=gradle", "-Djava.io.tmpdir=${p.tmp.absolutePath}",
                "-Duser.home=${p.tmp.absolutePath}", "-classpath", jar.absolutePath, "org.gradle.launcher.GradleMain", "--version"),
            p.env(), p.tmp, 120,
        )
        say("gradle: " + g.second.lines().firstOrNull { it.startsWith("Gradle ") }.orEmpty())
        if (g.first != 0) {
            say("Gradle $v не запустился на активной JDK ${p.activeJdk}: ${g.second.lines().take(3).joinToString(" ")}")
            return false
        }
        say("ГОТОВО: Gradle $v установлен.")
        return true
    }

    fun status(): Bundle = Bundle().apply {
        putBoolean("running", running.get())
        putBoolean("done", done)
        putBoolean("success", success)
        putString("log", log.toString())
    }

    private fun say(s: String) {
        log.append(s).append('\n')
    }

    private fun check() {
        if (cancelled.get()) throw CancelledException()
    }

    private fun run(context: Context): Boolean {
        val p = ToolchainPaths(context, defaultsOnly = true)
        p.root.mkdirs(); p.tmp.mkdirs(); p.cache.mkdirs(); p.androidUserHome.mkdirs()

        say("[1/6] Подготовка")
        if (context.filesDir.usableSpace < 3 * 1024 * MB) {
            say("Нужно не менее 3 ГБ свободного места, сейчас ${context.filesDir.usableSpace / MB} МБ. Остановлено.")
            return false
        }
        p.consentFile.writeText("Android SDK License accepted by the user in the IDE at ${java.util.Date()} ($LICENSE_URL)\n")
        migrateFromProbes(context, p)

        say("\n[2/6] JDK 17 и aapt2 (пакеты Termux)")
        check()
        val roots = listOf("openjdk-17", "aapt2")
        if (!JdkProbe.installPackages(roots, p.termuxRoot, p.cache, TRIM, { cancelled.get() }) { say(it) }) return false
        if (!verifyJava(p)) {
            say("С урезанным набором java не запустилась, ставлю полный набор.")
            if (!JdkProbe.installPackages(roots, p.termuxRoot, p.cache, emptySet(), { cancelled.get() }) { say(it) }) return false
            if (!verifyJava(p)) {
                say("java не запускается даже с полным набором. Остановлено.")
                return false
            }
        }
        p.aapt2.setExecutable(true, false)

        say("\n[3/6] Gradle ${ToolchainPaths.GRADLE_VERSION}")
        check()
        if (p.gradleLauncherJar() == null && !installGradle(p)) return false
        if (p.gradleLauncherJar() != null) say("Gradle установлен.")

        say("\n[4/6] Android SDK (platform ${ToolchainPaths.COMPILE_SDK}, build-tools ${ToolchainPaths.BUILD_TOOLS})")
        check()
        if (!p.platformDir.isDirectory || !p.buildToolsDir.isDirectory) {
            val xml = loadRepositoryXml()
            if (!p.platformDir.isDirectory && !installSdkPackage(xml, "platforms;android-${ToolchainPaths.COMPILE_SDK}", p.platformDir, p)) return false
            if (!p.buildToolsDir.isDirectory && !installSdkPackage(xml, "build-tools;${ToolchainPaths.BUILD_TOOLS}", p.buildToolsDir, p)) return false
        } else {
            say("SDK-компоненты уже установлены.")
        }

        say("\n[5/6] aapt2 для arm64 в build-tools")
        p.aapt2.copyTo(File(p.buildToolsDir, "aapt2"), overwrite = true)
        File(p.buildToolsDir, "aapt2").setExecutable(true, false)

        say("\n[6/6] Проверка")
        check()
        val env = p.env()
        val aapt = runCmd(listOf(p.aapt2.absolutePath, "version"), env, p.tmp, 30)
        say("aapt2: ${aapt.second.lines().firstOrNull().orEmpty()}")
        if (aapt.first != 0) return false
        val jar = p.gradleLauncherJar()!!
        val g = runCmd(
            listOf(p.java.absolutePath, "-Xmx64m", "-Dorg.gradle.appname=gradle", "-Djava.io.tmpdir=${p.tmp.absolutePath}",
                "-Duser.home=${p.tmp.absolutePath}", "-classpath", jar.absolutePath, "org.gradle.launcher.GradleMain", "--version"),
            env, p.tmp, 120,
        )
        say("gradle: " + g.second.lines().firstOrNull { it.startsWith("Gradle ") }.orEmpty())
        if (g.first != 0) return false

        p.readyMarker.writeText("ready ${java.util.Date()}\n")
        say("\nГОТОВО: инструменты установлены.")
        return true
    }

    /** Переносим то, что безопасно переносить из старых проб (Gradle-дистрибутив, кэш зависимостей, SDK). */
    private fun migrateFromProbes(context: Context, p: ToolchainPaths) {
        fun moveIfAbsent(src: File, dst: File, label: String) {
            if (src.isDirectory && !dst.exists()) {
                dst.parentFile?.mkdirs()
                if (src.renameTo(dst)) say("Перенесено из проб: $label")
            }
        }
        moveIfAbsent(File(context.filesDir, "gradleprobe/dist"), p.gradleDir, "Gradle")
        moveIfAbsent(File(context.filesDir, "gradleprobe/gradle-user-home"), p.gradleUserHome, "кэш Gradle")
        moveIfAbsent(File(context.filesDir, "androidprobe/sdk"), p.sdk, "Android SDK")
    }

    private fun verifyJava(p: ToolchainPaths): Boolean {
        p.java.setExecutable(true, false)
        if (!p.java.isFile) {
            say("java не найден: ${p.java.absolutePath}")
            return false
        }
        val r = runCmd(listOf(p.java.absolutePath, "-version"), p.env(), p.tmp, 60)
        say("java -version: " + r.second.lines().firstOrNull().orEmpty())
        return r.first == 0
    }

    private fun installGradle(p: ToolchainPaths): Boolean {
        val dist = "https://services.gradle.org/distributions/gradle-${ToolchainPaths.GRADLE_VERSION}-bin.zip"
        val zip = File(p.cache, "gradle.zip")
        say("Скачиваю $dist")
        download(dist, zip)
        val expected = JdkProbe.open("$dist.sha256").use { it.bufferedReader().readText() }.trim().split(Regex("\\s+")).first()
        val actual = hash(zip, "SHA-256")
        if (!actual.equals(expected, ignoreCase = true)) {
            say("SHA256 Gradle не совпал (ожидалось $expected, получено $actual).")
            zip.delete()
            return false
        }
        p.gradleDir.deleteRecursively()
        p.gradleDir.mkdirs()
        unzip(zip, p.gradleDir)
        zip.delete()
        return true
    }

    private fun loadRepositoryXml(): String {
        for (name in listOf("repository2-3.xml", "repository2-2.xml")) {
            try {
                say("Читаю $SDK_REPO/$name")
                return JdkProbe.open("$SDK_REPO/$name").use { it.bufferedReader().readText() }
            } catch (e: Exception) {
                say("  не удалось: ${e.message}")
            }
        }
        throw IllegalStateException("репозиторий SDK Google недоступен")
    }

    private fun installSdkPackage(xml: String, path: String, target: File, p: ToolchainPaths): Boolean {
        val block = Regex("<remotePackage path=\"${Regex.escape(path)}\".*?</remotePackage>", RegexOption.DOT_MATCHES_ALL).find(xml)?.value
        if (block == null) {
            say("Пакет $path не найден в репозитории.")
            return false
        }
        val archives = Regex("<archive>.*?</archive>", RegexOption.DOT_MATCHES_ALL).findAll(block).map { it.value }.toList()
        val archive = archives.firstOrNull { "<host-os>linux</host-os>" in it }
            ?: archives.firstOrNull { "<host-os>" !in it }
            ?: archives.firstOrNull()
        val url = archive?.let { Regex("<url>(.*?)</url>").find(it)?.groupValues?.get(1) }
        if (archive == null || url == null) {
            say("Для $path нет подходящего архива.")
            return false
        }
        val sha1 = Regex("<checksum[^>]*>(.*?)</checksum>").find(archive)?.groupValues?.get(1)
        say("Скачиваю $path: $url")
        val zip = File(p.cache, "sdk-download.zip")
        download("$SDK_REPO/$url", zip)
        if (sha1 != null && !hash(zip, "SHA-1").equals(sha1, ignoreCase = true)) {
            say("SHA1 для $path не совпал — остановлено.")
            zip.delete()
            return false
        }
        val unpack = File(p.cache, "sdk-unpack").apply { deleteRecursively(); mkdirs() }
        unzip(zip, unpack)
        zip.delete()
        val top = unpack.listFiles()?.singleOrNull { it.isDirectory } ?: unpack
        target.deleteRecursively()
        target.parentFile?.mkdirs()
        if (!top.renameTo(target)) {
            top.copyRecursively(target, overwrite = true)
            top.deleteRecursively()
        }
        unpack.deleteRecursively()
        say("  установлено: ${target.name}")
        return true
    }

    // ---------- утилиты ----------

    private fun download(url: String, dest: File) {
        JdkProbe.open(url).use { input ->
            dest.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    check()
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
        }
    }

    private fun hash(f: File, algo: String): String {
        val md = MessageDigest.getInstance(algo)
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.toPath().toAbsolutePath().normalize()
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            while (true) {
                check()
                val e = z.nextEntry ?: break
                val out = File(dest, e.name)
                if (!out.toPath().toAbsolutePath().normalize().startsWith(destPath)) continue
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { z.copyTo(it) }
                }
            }
        }
    }

    private fun runCmd(cmd: List<String>, env: Map<String, String>, dir: File, timeoutSec: Long): Pair<Int, String> {
        return try {
            val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
            pb.environment().putAll(env)
            val proc = pb.start()
            val sb = StringBuffer()
            val reader = Thread { proc.inputStream.bufferedReader().forEachLine { sb.append(it).append('\n') } }.apply { isDaemon = true; start() }
            if (!proc.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                proc.destroyForcibly()
                return -1 to "таймаут $timeoutSec с"
            }
            reader.join(3000)
            proc.exitValue() to sb.toString().trim()
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.message}"
        }
    }
}

package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import java.io.File

/** Выбор и удаление установленных версий JDK, Gradle, платформ SDK и build-tools (установка — в ToolchainInstaller). */
object VersionManager {
    private val NUM = Regex("[0-9][0-9.]{0,15}")

    fun info(context: Context): Bundle {
        val p = ToolchainPaths(context)
        return Bundle().apply {
            putStringArray("jdkInstalled", p.installedJdks().toTypedArray())
            putString("jdkActive", p.activeJdk)
            putStringArray("gradleInstalled", p.installedGradles().toTypedArray())
            putString("gradleActive", p.activeGradle)
            putStringArray("platforms", p.installedPlatforms().toTypedArray())
            putStringArray("buildTools", p.installedBuildTools().toTypedArray())
            putString("buildToolsActive", p.activeBuildTools)
            putString("baseGradle", ToolchainPaths.GRADLE_VERSION)
            putString("basePlatform", ToolchainPaths.COMPILE_SDK.toString())
            putString("baseBuildTools", ToolchainPaths.BUILD_TOOLS)
        }
    }

    private fun valid(kind: String, value: String): Boolean = when (kind) {
        "jdk" -> value.matches(Regex("\\d{1,2}"))
        "gradle", "buildtools" -> value.matches(NUM)
        "platform" -> value.matches(Regex("\\d{2,3}"))
        else -> false
    }

    /** Возвращает null при успехе или текст ошибки. */
    fun activate(context: Context, kind: String, value: String): String? {
        if (!valid(kind, value)) return "Недопустимое значение."
        val p = ToolchainPaths(context)
        return when (kind) {
            "jdk" -> if (value in p.installedJdks()) { p.setActive("jdk", value); null } else "JDK $value не установлена."
            "gradle" -> if (value in p.installedGradles()) { p.setActive("gradle", value); null } else "Gradle $value не установлен."
            "buildtools" -> if (value in p.installedBuildTools()) { p.setActive("buildtools", value); null } else "Build-tools $value не установлены."
            else -> "Для этого вида выбор не нужен."
        }
    }

    /** Удаляет версию. Базовые и активные версии удалять нельзя. */
    fun remove(context: Context, kind: String, value: String): String? {
        if (!valid(kind, value)) return "Недопустимое значение."
        val p = ToolchainPaths(context)
        when (kind) {
            "jdk" -> {
                if (value == "17") return "Базовую JDK 17 удалить нельзя."
                if (value == p.activeJdk) return "Эта JDK сейчас активна. Сначала выберите другую."
                StorageCleaner.deleteTree(p.jdkHome(value))
                File(p.termuxRoot, ".installed/openjdk-$value").delete() // чтобы повторная установка не пропустила пакет
            }
            "gradle" -> {
                if (value == ToolchainPaths.GRADLE_VERSION) return "Базовый Gradle удалить нельзя."
                if (value == p.activeGradle) return "Этот Gradle сейчас активен. Сначала выберите другой."
                StorageCleaner.deleteTree(File(p.gradleVersionsDir, value))
            }
            "platform" -> {
                if (value == ToolchainPaths.COMPILE_SDK.toString()) return "Базовую платформу ${ToolchainPaths.COMPILE_SDK} удалить нельзя."
                StorageCleaner.deleteTree(File(p.sdk, "platforms/android-$value"))
            }
            "buildtools" -> {
                if (value == ToolchainPaths.BUILD_TOOLS) return "Базовые build-tools удалить нельзя."
                if (value == p.activeBuildTools) return "Эти build-tools сейчас активны. Сначала выберите другие."
                StorageCleaner.deleteTree(File(p.sdk, "build-tools/$value"))
            }
            else -> return "Неизвестный вид."
        }
        return null
    }
}

package dev.barbaross.runtime

import java.io.File

/** Шаблоны проектов. Стек проверен сборкой на устройстве: AGP 8.13.0 + Kotlin 2.2.10 + Compose BOM 2025.10.00. */
object ProjectTemplates {
    fun sanitize(name: String): String {
        val s = name.lowercase().filter { it in 'a'..'z' || it in '0'..'9' }
        return if (s.isEmpty() || !s[0].isLetter()) "app$s" else s
    }

    /** Создаёт проект «Hello Compose» в projectsDir и возвращает его каталог. */
    fun createComposeApp(projectsDir: File, rawName: String): File {
        val id = sanitize(rawName)
        var dir = File(projectsDir, id)
        var n = 2
        while (dir.exists()) {
            dir = File(projectsDir, "$id$n")
            n++
        }
        val pkg = "dev.barbaross.app.${dir.name}"
        val pkgPath = pkg.replace('.', '/')
        dir.mkdirs()

        File(dir, "settings.gradle").writeText(
            """
            pluginManagement {
                repositories { google(); mavenCentral(); gradlePluginPortal() }
            }
            dependencyResolutionManagement {
                repositories { google(); mavenCentral() }
            }
            rootProject.name = '${dir.name}'
            """.trimIndent() + "\n"
        )
        File(dir, "build.gradle").writeText(
            """
            plugins {
                id 'com.android.application' version '8.13.0'
                id 'org.jetbrains.kotlin.android' version '2.2.10'
                id 'org.jetbrains.kotlin.plugin.compose' version '2.2.10'
            }
            android {
                namespace '$pkg'
                compileSdk 36
                defaultConfig {
                    applicationId '$pkg'
                    minSdk 28
                    targetSdk 28
                    versionCode 1
                    versionName '1.0'
                    ndk { abiFilters 'arm64-v8a' }
                }
                buildFeatures { compose true }
                compileOptions {
                    sourceCompatibility JavaVersion.VERSION_17
                    targetCompatibility JavaVersion.VERSION_17
                }
            }
            dependencies {
                implementation platform('androidx.compose:compose-bom:2025.10.00')
                implementation 'androidx.compose.ui:ui'
                implementation 'androidx.compose.material3:material3'
                implementation 'androidx.activity:activity-compose:1.11.0'
            }
            """.trimIndent() + "\n"
        )
        File(dir, "gradle.properties").writeText("android.useAndroidX=true\nandroid.nonTransitiveRClass=true\nkotlin.code.style=official\n")
        File(dir, ".gitignore").writeText("build/\n.gradle/\nlocal.properties\n")
        File(dir, "src/main").mkdirs()
        File(dir, "src/main/AndroidManifest.xml").writeText(
            """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application android:label="${dir.name}" android:theme="@android:style/Theme.Material.Light.NoActionBar">
                    <activity android:name=".MainActivity" android:exported="true">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
            """.trimIndent() + "\n"
        )
        File(dir, "src/main/java/$pkgPath").mkdirs()
        File(dir, "src/main/java/$pkgPath/MainActivity.kt").writeText(
            """
            package $pkg

            import android.os.Bundle
            import androidx.activity.ComponentActivity
            import androidx.activity.compose.setContent
            import androidx.compose.material3.MaterialTheme
            import androidx.compose.material3.Text

            class MainActivity : ComponentActivity() {
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContent { MaterialTheme { Text("Привет из ${dir.name}!") } }
                }
            }
            """.trimIndent() + "\n"
        )
        return dir
    }
}

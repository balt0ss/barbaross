package dev.barbaross.runtime

import android.content.Context
import java.io.File
import java.util.Properties

/**
 * Единая раскладка установленных инструментов в filesDir/toolchain.
 * Версии JDK, Gradle и build-tools можно ставить несколько; «активные» хранятся в toolchain/active.properties.
 * defaultsOnly = true — игнорировать выбор пользователя (нужно базовому установщику).
 */
class ToolchainPaths(context: Context, defaultsOnly: Boolean = false) {
    val filesDir: File = context.filesDir
    val root = File(filesDir, "toolchain")

    /** Распакованные пакеты Termux; внутри сохраняется их родной префикс data/data/com.termux/files/usr. */
    val termuxRoot = File(root, "termux")
    val usr = File(termuxRoot, "data/data/com.termux/files/usr")
    val aapt2 = File(usr, "bin/aapt2")

    /** Базовый дистрибутив Gradle (версия GRADLE_VERSION) и каталог дополнительных версий. */
    val gradleDir = File(root, "gradle")
    val gradleVersionsDir = File(root, "gradle-versions")
    val sdk = File(root, "sdk")
    val gradleUserHome = File(root, "gradle-home")
    val androidUserHome = File(root, "android-home")
    val tmp = File(root, "tmp")
    val cache = File(root, "cache")
    val readyMarker = File(root, ".ready")
    val consentFile = File(root, "consent.txt")
    val activeFile = File(root, "active.properties")

    val platformDir = File(sdk, "platforms/android-$COMPILE_SDK")
    val buildToolsDir = File(sdk, "build-tools/$BUILD_TOOLS")

    fun jdkHome(version: String) = File(usr, "lib/jvm/java-$version-openjdk")

    fun gradleDistDir(version: String): File? =
        (if (version == GRADLE_VERSION) gradleDir else File(gradleVersionsDir, version)).takeIf { it.isDirectory }

    private fun readActive(key: String): String? {
        if (defaultsOnly || !activeFile.isFile) return null
        return try {
            Properties().apply { activeFile.inputStream().use { load(it) } }.getProperty(key)?.trim()
        } catch (e: Exception) {
            null
        }
    }

    /** Активные версии; если выбранной уже нет на диске — базовая. */
    val activeJdk: String = readActive("jdk")?.takeIf { it.matches(Regex("\\d{1,2}")) && jdkHome(it).isDirectory } ?: "17"
    val activeGradle: String = readActive("gradle")?.takeIf { it.matches(Regex("[0-9][0-9.]{0,15}")) && gradleDistDir(it) != null } ?: GRADLE_VERSION
    val activeBuildTools: String = readActive("buildtools")
        ?.takeIf { it.matches(Regex("[0-9][0-9.]{0,15}")) && File(sdk, "build-tools/$it").isDirectory } ?: BUILD_TOOLS

    val javaHome: File = jdkHome(activeJdk)
    val java = File(javaHome, "bin/java")

    fun setActive(key: String, value: String) {
        val props = Properties()
        if (activeFile.isFile) activeFile.inputStream().use { props.load(it) }
        props.setProperty(key, value)
        root.mkdirs()
        activeFile.outputStream().use { props.store(it, null) }
    }

    /** Launcher-jar Gradle указанной версии (по умолчанию — активной; активная при отсутствии заменяется базовой). */
    fun gradleLauncherJar(version: String? = null): File? {
        val dir = gradleDistDir(version ?: activeGradle) ?: (if (version == null) gradleDistDir(GRADLE_VERSION) else null) ?: return null
        return dir.walkTopDown().firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }
    }

    fun isReady(): Boolean =
        readyMarker.isFile && java.isFile && aapt2.isFile && gradleLauncherJar() != null &&
            platformDir.isDirectory && buildToolsDir.isDirectory

    // ---------- что установлено ----------

    private fun verKey(s: String): List<Int> = s.split('.', '-').map { it.toIntOrNull() ?: 0 }

    private fun byVersionDesc(list: List<String>): List<String> =
        list.sortedWith { a, b ->
            val x = verKey(a)
            val y = verKey(b)
            var r = 0
            for (i in 0 until maxOf(x.size, y.size)) {
                r = (y.getOrElse(i) { 0 }).compareTo(x.getOrElse(i) { 0 })
                if (r != 0) break
            }
            r
        }

    fun installedJdks(): List<String> =
        byVersionDesc(
            File(usr, "lib/jvm").listFiles()?.mapNotNull { Regex("java-(\\d{1,2})-openjdk").matchEntire(it.name)?.groupValues?.get(1) }
                ?.filter { File(jdkHome(it), "bin/java").isFile } ?: emptyList()
        )

    fun installedGradles(): List<String> {
        val extra = gradleVersionsDir.listFiles()?.filter { it.isDirectory && it.name.matches(Regex("[0-9][0-9.]{0,15}")) }?.map { it.name }
            ?: emptyList()
        val base = if (gradleDistDir(GRADLE_VERSION) != null) listOf(GRADLE_VERSION) else emptyList()
        return byVersionDesc((base + extra).distinct())
    }

    fun installedPlatforms(): List<String> =
        byVersionDesc(
            File(sdk, "platforms").listFiles()?.mapNotNull { Regex("android-(\\d{2,3})").matchEntire(it.name)?.groupValues?.get(1) }
                ?: emptyList()
        )

    fun installedBuildTools(): List<String> =
        byVersionDesc(File(sdk, "build-tools").listFiles()?.filter { it.isDirectory }?.map { it.name }?.filter { it.matches(Regex("[0-9][0-9.]{0,15}")) } ?: emptyList())

    /** Окружение для запуска Java/Gradle/aapt2 (bionic-сборки Termux с жёстким префиксом). */
    fun env(): Map<String, String> = mapOf(
        "LD_LIBRARY_PATH" to File(usr, "lib").absolutePath,
        "JAVA_HOME" to javaHome.absolutePath,
        "HOME" to tmp.absolutePath,
        "TMPDIR" to tmp.absolutePath,
        "PREFIX" to usr.absolutePath,
        "GRADLE_USER_HOME" to gradleUserHome.absolutePath,
        "ANDROID_USER_HOME" to androidUserHome.absolutePath,
        "ANDROID_HOME" to sdk.absolutePath,
        "ANDROID_SDK_ROOT" to sdk.absolutePath,
        "BARBAROSS_BUILD_TOOLS" to activeBuildTools,
    )

    companion object {
        const val GRADLE_VERSION = "8.14.3"
        const val COMPILE_SDK = 36
        const val BUILD_TOOLS = "36.0.0"
    }
}

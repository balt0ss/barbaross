package dev.barbaross.runtime

import android.content.Context
import java.io.File

/** Единая раскладка установленных инструментов в filesDir/toolchain. */
class ToolchainPaths(context: Context) {
    val filesDir: File = context.filesDir
    val root = File(filesDir, "toolchain")

    /** Распакованные пакеты Termux; внутри сохраняется их родной префикс data/data/com.termux/files/usr. */
    val termuxRoot = File(root, "termux")
    val usr = File(termuxRoot, "data/data/com.termux/files/usr")
    val javaHome = File(usr, "lib/jvm/java-17-openjdk")
    val java = File(javaHome, "bin/java")
    val aapt2 = File(usr, "bin/aapt2")

    val gradleDir = File(root, "gradle")
    val sdk = File(root, "sdk")
    val gradleUserHome = File(root, "gradle-home")
    val androidUserHome = File(root, "android-home")
    val tmp = File(root, "tmp")
    val cache = File(root, "cache")
    val readyMarker = File(root, ".ready")
    val consentFile = File(root, "consent.txt")

    val platformDir = File(sdk, "platforms/android-$COMPILE_SDK")
    val buildToolsDir = File(sdk, "build-tools/$BUILD_TOOLS")

    fun gradleLauncherJar(): File? =
        gradleDir.takeIf { it.isDirectory }?.walkTopDown()
            ?.firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }

    fun isReady(): Boolean =
        readyMarker.isFile && java.isFile && aapt2.isFile && gradleLauncherJar() != null &&
            platformDir.isDirectory && buildToolsDir.isDirectory

    /** Окружение для запуска Java/Gradle/aapt2 (bionic-сборки Termux с жёстким префиксом). */
    fun env(): Map<String, String> = mapOf(
        "LD_LIBRARY_PATH" to File(usr, "lib").absolutePath,
        "JAVA_HOME" to javaHome.absolutePath,
        "HOME" to tmp.absolutePath,
        "TMPDIR" to tmp.absolutePath,
        "PREFIX" to usr.absolutePath,
        "GRADLE_USER_HOME" to gradleUserHome.absolutePath,
        "ANDROID_USER_HOME" to androidUserHome.absolutePath,
        "ANDROID_HOME" to sdk.absolutePath,
        "ANDROID_SDK_ROOT" to sdk.absolutePath,
    )

    companion object {
        const val GRADLE_VERSION = "8.14.3"
        const val COMPILE_SDK = 36
        const val BUILD_TOOLS = "36.0.0"
    }
}

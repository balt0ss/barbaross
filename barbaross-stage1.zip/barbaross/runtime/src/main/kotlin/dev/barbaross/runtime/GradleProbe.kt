package dev.barbaross.runtime

import android.app.ActivityManager
import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/**
 * ЭКСПЕРИМЕНТ: на уже установленном JDK (см. JdkProbe) скачивает Gradle, запускает `--version`
 * и собирает крошечный проект на чистой Java. Android-плагин здесь НЕ участвует.
 * Проверяет: запуск Gradle на bionic-JDK, память, дочерний процесс Gradle (single-use daemon), phantom process killer.
 */
object GradleProbe {
    private const val GRADLE_VERSION = "8.14.3"
    private const val DIST = "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
    private const val TERMUX_USR = "data/data/com.termux/files/usr"
    private const val MB = 1024L * 1024L

    private val running = AtomicBoolean(false)
    private val log = StringBuffer()

    fun start(context: Context): Boolean {
        if (!running.compareAndSet(false, true)) return false
        log.setLength(0)
        val app = context.applicationContext
        Thread({
            try {
                runProbe(app)
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                running.set(false)
            }
        }, "gradle-probe").start()
        return true
    }

    fun status(): String = (if (running.get()) JdkProbe.RUNNING_MARK else JdkProbe.DONE_MARK) + "\n" + log

    private fun say(s: String) {
        log.append(s).append('\n')
    }

    private fun memLine(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return "RAM доступно ${mi.availMem / MB} МБ из ${mi.totalMem / MB} МБ"
    }

    private fun runProbe(context: Context) {
        val jdkRoot = File(context.filesDir, "jdkprobe/root")
        val usr = File(jdkRoot, TERMUX_USR)
        val java = File(usr, "lib/jvm/java-17-openjdk/bin/java")
        if (!java.isFile) {
            say("JDK не найден. Сначала выполните «Проба JDK».")
            return
        }
        val javaHome = java.parentFile!!.parentFile!!
        val base = File(context.filesDir, "gradleprobe").apply { mkdirs() }
        val tmp = File(base, "tmp").apply { mkdirs() }
        val gradleHomeDir = File(base, "gradle-user-home").apply { mkdirs() }
        say(memLine(context))

        // 1. Дистрибутив Gradle
        val dist = File(base, "dist")
        val launcher = dist.walkTopDown().firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }
        val launcherJar = if (launcher != null) {
            say("Gradle уже распакован: ${launcher.parentFile!!.parentFile!!.name}")
            launcher
        } else {
            say("Скачиваю Gradle $GRADLE_VERSION")
            val zip = File(base, "gradle.zip")
            JdkProbe.download(DIST, zip)
            val expected = JdkProbe.open("$DIST.sha256").use { it.bufferedReader().readText() }.trim().split(Regex("\\s+")).first()
            val actual = JdkProbe.sha256(zip)
            if (!actual.equals(expected, ignoreCase = true)) {
                say("SHA256 НЕ СОВПАЛ (ожидалось $expected, получено $actual) — остановлено.")
                zip.delete()
                return
            }
            say("SHA256 совпал. Распаковываю…")
            dist.deleteRecursively()
            dist.mkdirs()
            unzip(zip, dist)
            zip.delete()
            dist.walkTopDown().firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }
                ?: run { say("gradle-launcher не найден после распаковки."); return }
        }

        val env = mapOf(
            "LD_LIBRARY_PATH" to File(usr, "lib").absolutePath,
            "JAVA_HOME" to javaHome.absolutePath,
            "HOME" to tmp.absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "PREFIX" to usr.absolutePath,
            "GRADLE_USER_HOME" to gradleHomeDir.absolutePath,
        )
        val jvmCommon = listOf("-Djava.io.tmpdir=${tmp.absolutePath}", "-Duser.home=${tmp.absolutePath}")
        fun gradleCmd(vararg args: String) = listOf(java.absolutePath, "-Xmx64m", "-Xms64m", "-Dorg.gradle.appname=gradle") +
            jvmCommon + listOf("-classpath", launcherJar.absolutePath, "org.gradle.launcher.GradleMain") + args

        // 2. gradle --version
        say("\n== gradle --version ==")
        val v = exec(gradleCmd("--version"), env, base, 120)
        if (v != 0) {
            say("РЕЗУЛЬТАТ: Gradle не запустился (код $v).")
            return
        }

        // 3. Мини-проект на чистой Java
        say("\n== сборка проекта на чистой Java ==")
        val proj = File(base, "hello").apply { deleteRecursively(); mkdirs() }
        File(proj, "settings.gradle").writeText("rootProject.name = 'hello'\n")
        File(proj, "build.gradle").writeText("plugins { id 'java' }\n")
        File(proj, "gradle.properties").writeText(
            "org.gradle.daemon=false\norg.gradle.jvmargs=-Xmx512m -XX:MaxMetaspaceSize=256m " +
                "-Djava.io.tmpdir=${tmp.absolutePath} -Duser.home=${tmp.absolutePath}\n"
        )
        File(proj, "src/main/java").mkdirs()
        File(proj, "src/main/java/Hello.java").writeText(
            "public class Hello { public static void main(String[] a) { System.out.println(\"hello from gradle build\"); } }\n"
        )
        say(memLine(context))
        val t0 = System.currentTimeMillis()
        val b = exec(gradleCmd("--no-daemon", "--console=plain", "build"), env, proj, 600)
        say("Время: ${(System.currentTimeMillis() - t0) / 1000} с; ${memLine(context)}")
        if (b == 137 || b == 143 || b == 9) say("Код $b: процесс убит системой (память или phantom process killer).")
        val jar = File(proj, "build/libs/hello.jar")
        if (b != 0 || !jar.isFile) {
            say("РЕЗУЛЬТАТ: сборка не удалась (код $b).")
            return
        }
        say("\n== запуск собранного ==")
        exec(listOf(java.absolutePath, "-cp", jar.absolutePath, "Hello"), env, proj, 30)
        say("РЕЗУЛЬТАТ: Gradle запускается и собирает Java-проект.")
    }

    /** Запуск с построчным выводом в лог. Возвращает код выхода или -1. */
    private fun exec(cmd: List<String>, env: Map<String, String>, dir: File, timeoutSec: Long): Int {
        return try {
            val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
            pb.environment().putAll(env)
            val p = pb.start()
            val reader = Thread { p.inputStream.bufferedReader().forEachLine { say("  $it") } }.apply { isDaemon = true; start() }
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                say("ТАЙМАУТ ${timeoutSec} с")
                return -1
            }
            reader.join(3000)
            say("код выхода: ${p.exitValue()}")
            p.exitValue()
        } catch (e: Exception) {
            say("запуск не удался: ${e.javaClass.simpleName}: ${e.message}")
            -1
        }
    }

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.toPath().toAbsolutePath().normalize()
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val out = File(dest, e.name)
                if (!out.toPath().toAbsolutePath().normalize().startsWith(destPath)) continue
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { z.copyTo(it) }
                }
            }
        }
    }
}

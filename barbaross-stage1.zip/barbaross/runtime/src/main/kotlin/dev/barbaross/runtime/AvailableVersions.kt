package dev.barbaross.runtime

import org.json.JSONArray

/**
 * Список версий, доступных для установки, из первоисточников:
 * Gradle — services.gradle.org/versions/all, SDK — репозиторий Google, JDK — индекс пакетов Termux.
 * Результат кэшируется на 10 минут.
 */
object AvailableVersions {
    private const val SDK_REPO = "https://dl.google.com/android/repository"
    private const val TTL_MS = 10 * 60 * 1000L

    private class Cached(val at: Long, val list: List<String>)

    private val cache = HashMap<String, Cached>()

    /** Пара: список (новейшие первыми) или текст ошибки. */
    fun get(kind: String, force: Boolean): Pair<List<String>?, String?> {
        if (!force) {
            val c = synchronized(cache) { cache[kind] }
            if (c != null && System.currentTimeMillis() - c.at < TTL_MS) return c.list to null
        }
        return try {
            val list = when (kind) {
                "gradle" -> gradle()
                "platform" -> platforms()
                "buildtools" -> buildTools()
                "jdk" -> jdks()
                else -> return null to "Неизвестный вид."
            }
            if (list.isEmpty()) return null to "Источник вернул пустой список."
            synchronized(cache) { cache[kind] = Cached(System.currentTimeMillis(), list) }
            list to null
        } catch (e: Exception) {
            null to "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun verKey(s: String): List<Int> = s.split('.', '-').map { it.toIntOrNull() ?: 0 }

    private fun newestFirst(list: Collection<String>): List<String> = list.distinct().sortedWith { a, b ->
        val x = verKey(a)
        val y = verKey(b)
        var r = 0
        for (i in 0 until maxOf(x.size, y.size)) {
            r = y.getOrElse(i) { 0 }.compareTo(x.getOrElse(i) { 0 })
            if (r != 0) break
        }
        r
    }

    /** Только стабильные релизы Gradle 6 и новее (без RC, milestone, nightly, snapshot и отозванных). */
    private fun gradle(): List<String> {
        val text = JdkProbe.open("https://services.gradle.org/versions/all").use { it.bufferedReader().readText() }
        val arr = JSONArray(text)
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optBoolean("snapshot") || o.optBoolean("nightly") || o.optBoolean("releaseNightly") || o.optBoolean("broken")) continue
            if (o.optString("rcFor").isNotEmpty() || o.optString("milestoneFor").isNotEmpty()) continue
            val v = o.optString("version")
            if (!v.matches(Regex("\\d+\\.\\d+(\\.\\d+)?"))) continue
            if ((v.substringBefore('.').toIntOrNull() ?: 0) < 6) continue
            out.add(v)
        }
        return newestFirst(out)
    }

    private fun sdkXml(): String {
        var last: Exception? = null
        for (name in listOf("repository2-3.xml", "repository2-2.xml")) {
            try {
                return JdkProbe.open("$SDK_REPO/$name").use { it.bufferedReader().readText() }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("репозиторий SDK недоступен")
    }

    private fun platforms(): List<String> =
        newestFirst(
            Regex("<remotePackage path=\"platforms;android-(\\d{2,3})\"").findAll(sdkXml())
                .map { it.groupValues[1] }.filter { (it.toIntOrNull() ?: 0) >= 21 }.toList()
        )

    private fun buildTools(): List<String> =
        newestFirst(
            Regex("<remotePackage path=\"build-tools;(\\d+(?:\\.\\d+)+)\"").findAll(sdkXml())
                .map { it.groupValues[1] }.filter { (it.substringBefore('.').toIntOrNull() ?: 0) >= 28 }.toList()
        )

    private fun jdks(): List<String> =
        newestFirst(
            JdkProbe.packageNames().mapNotNull { Regex("openjdk-(\\d{1,2})").matchEntire(it)?.groupValues?.get(1) }
                .filter { (it.toIntOrNull() ?: 0) >= 17 }
        )
}

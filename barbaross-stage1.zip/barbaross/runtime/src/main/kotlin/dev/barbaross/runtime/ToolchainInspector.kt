package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import dev.barbaross.ipc.BuildProtocol

/** Реальная проверка наличия инструментов (раскладка — ToolchainPaths). */
object ToolchainInspector {
    fun inspect(context: Context): Bundle {
        val p = ToolchainPaths(context)
        return Bundle().apply {
            putBoolean(BuildProtocol.KEY_JDK_INSTALLED, p.java.isFile)
            putBoolean(BuildProtocol.KEY_GRADLE_INSTALLED, p.gradleLauncherJar() != null)
            putBoolean(BuildProtocol.KEY_SDK_INSTALLED, p.platformDir.isDirectory && p.buildToolsDir.isDirectory)
            putBoolean(BuildProtocol.KEY_READY, p.isReady())
            putString(BuildProtocol.KEY_DETAILS, "toolchain root: ${p.root.absolutePath}")
        }
    }
}

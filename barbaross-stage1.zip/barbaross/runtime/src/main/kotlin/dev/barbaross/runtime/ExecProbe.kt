package dev.barbaross.runtime

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Диагностика: что система реально разрешает этому приложению (targetSdk >= 29).
 * Ничего не устанавливает; пишет только в filesDir/probe. Отвечает на риски 1-3 из docs/PLAN.md.
 */
object ExecProbe {
    private const val MB = 1024L * 1024L

    fun run(context: Context): String = buildString {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }

        appendLine("== Устройство ==")
        appendLine("${Build.MANUFACTURER} ${Build.MODEL}, Android API ${Build.VERSION.SDK_INT}")
        appendLine("ABI: ${Build.SUPPORTED_ABIS.joinToString()}")
        appendLine("targetSdk: ${context.applicationInfo.targetSdkVersion}")
        appendLine("RAM: всего ${mem.totalMem / MB} МБ, доступно ${mem.availMem / MB} МБ")
        appendLine("Свободно в filesDir: ${context.filesDir.usableSpace / MB} МБ")
        appendLine("Java heap (этот процесс): ${Runtime.getRuntime().maxMemory() / MB} МБ")
        appendLine()

        val dir = File(context.filesDir, "probe").apply { mkdirs() }

        appendLine("== Запуск процессов ==")
        appendLine(exec("1. /system/bin/sh (системный)", listOf("/system/bin/sh", "-c", "echo ok; uname -m")))

        val script = File(dir, "hello.sh").apply {
            writeText("#!/system/bin/sh\necho script-ok\n")
            setExecutable(true)
        }
        appendLine(exec("2. скрипт из filesDir напрямую", listOf(script.absolutePath)))
        appendLine(exec("3. скрипт из filesDir через sh", listOf("/system/bin/sh", script.absolutePath)))

        val toybox = File("/system/bin/toybox")
        if (toybox.isFile) {
            val copy = File(dir, "toybox-copy")
            try {
                toybox.copyTo(copy, overwrite = true)
                copy.setExecutable(true)
                appendLine(exec("4. копия бинарника из filesDir", listOf(copy.absolutePath, "echo", "copy-ok")))
                val linker = if (Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()) "/system/bin/linker64" else "/system/bin/linker"
                appendLine(exec("5. та же копия через $linker", listOf(linker, copy.absolutePath, "echo", "linker-ok")))
            } catch (e: IOException) {
                appendLine("4. копия бинарника: не удалось подготовить: ${e.message}")
            }
        } else {
            appendLine("4. копия бинарника: /system/bin/toybox отсутствует, пропущено")
        }
        appendLine()

        appendLine("== Загрузка .so из filesDir (dlopen) ==")
        appendLine(loadProbe(dir))
        appendLine()

        appendLine("== nativeLibraryDir ==")
        val nld = File(context.applicationInfo.nativeLibraryDir)
        appendLine(nld.absolutePath)
        appendLine(nld.list()?.sorted()?.joinToString().takeUnless { it.isNullOrEmpty() } ?: "(пусто)")
    }

    private fun loadProbe(dir: File): String {
        val src = listOf("/system/lib64/libz.so", "/system/lib/libz.so").map(::File).firstOrNull { it.isFile }
            ?: return "системная libz.so не найдена, пропущено"
        return try {
            val copy = File(dir, "libz-copy.so")
            src.copyTo(copy, overwrite = true)
            System.load(copy.absolutePath)
            "System.load из filesDir: ОК"
        } catch (e: Throwable) {
            "System.load из filesDir: ЗАПРЕЩЕНО (${e.javaClass.simpleName}: ${e.message})"
        }
    }

    private fun exec(title: String, cmd: List<String>): String {
        return try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            if (!p.waitFor(5, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                return "$title: ТАЙМАУТ"
            }
            val out = p.inputStream.bufferedReader().readText().trim().replace("\n", " | ")
            "$title: код ${p.exitValue()}, вывод: $out"
        } catch (e: IOException) {
            "$title: ЗАПРЕЩЕНО (${e.message})"
        } catch (e: SecurityException) {
            "$title: ЗАПРЕЩЕНО (${e.message})"
        }
    }
}

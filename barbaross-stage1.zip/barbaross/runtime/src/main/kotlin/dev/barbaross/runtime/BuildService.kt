package dev.barbaross.runtime

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import dev.barbaross.ipc.BuildProtocol
import dev.barbaross.ipc.IBuildService
import java.util.concurrent.atomic.AtomicInteger

/**
 * Сервис Build Runtime (библиотека :runtime, процесс ":build"). Не экспортирован — доступен только своему приложению.
 * Долгие задания (установка инструментов, сборка) держат сервис в foreground с уведомлением,
 * чтобы Android не убил процесс при свёрнутом приложении.
 */
class BuildService : Service() {

    private val jobs = AtomicInteger(0)
    @Volatile private var foregroundText = "Barbaross"

    private val callbacks = JobCallbacks(
        started = { text ->
            foregroundText = text
            if (jobs.getAndIncrement() == 0) startForegroundService(Intent(this, BuildService::class.java))
        },
        finished = {
            if (jobs.decrementAndGet() <= 0) {
                jobs.set(0)
                stopForeground(true)
                stopSelf()
            }
        },
    )

    private val binder = object : IBuildService.Stub() {
        override fun getProtocolVersion(): Int = BuildProtocol.VERSION

        override fun ping(payload: String?): String = payload.orEmpty()

        override fun getToolchainStatus(): Bundle = ToolchainInspector.inspect(applicationContext)

        override fun runDiagnostics(): String = ExecProbe.run(applicationContext)

        override fun startJdkProbe(): Boolean = JdkProbe.start(applicationContext)

        override fun getJdkProbeStatus(): String = JdkProbe.status()

        override fun startGradleProbe(): Boolean = GradleProbe.start(applicationContext)

        override fun getGradleProbeStatus(): String = GradleProbe.status()

        override fun startAndroidBuildProbe(): Boolean = AndroidBuildProbe.BASIC.start(applicationContext)

        override fun getAndroidBuildProbeStatus(): String = AndroidBuildProbe.BASIC.status()

        override fun startComposeBuildProbe(): Boolean = AndroidBuildProbe.COMPOSE.start(applicationContext)

        override fun getComposeBuildProbeStatus(): String = AndroidBuildProbe.COMPOSE.status()

        override fun invoke(method: String, args: Bundle): Bundle = dispatch(method, args)
    }

    private fun dispatch(method: String, args: Bundle): Bundle = try {
        when (method) {
            "toolchain.status" -> ToolchainInspector.inspect(applicationContext)
            "toolchain.install.start" -> {
                if (!args.getBoolean("licenseAccepted")) {
                    error("Нужно согласие с лицензией Android SDK.")
                } else if (!ToolchainInstaller.start(applicationContext, callbacks)) {
                    error("Установка уже выполняется.")
                } else {
                    Bundle().apply { putBoolean("ok", true) }
                }
            }
            "toolchain.install.status" -> ToolchainInstaller.status()
            "toolchain.install.cancel" -> {
                ToolchainInstaller.cancel()
                Bundle().apply { putBoolean("ok", true) }
            }
            "build.start" -> {
                val err = BuildEngine.start(
                    applicationContext,
                    args.getString("project").orEmpty(),
                    args.getString("task") ?: "assembleDebug",
                    callbacks,
                )
                if (err != null) error(err) else Bundle().apply { putBoolean("ok", true) }
            }
            "build.log" -> BuildEngine.readLog(args.getInt("offset", 0))
            "build.cancel" -> {
                BuildEngine.cancel()
                Bundle().apply { putBoolean("ok", true) }
            }
            else -> error("Неизвестный метод: $method")
        }
    } catch (e: Exception) {
        error("${e.javaClass.simpleName}: ${e.message}")
    }

    private fun error(text: String) = Bundle().apply { putString("error", text) }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService() обязывает вызвать startForeground() в течение нескольких секунд.
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Сборка Barbaross", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Barbaross")
            .setContentText(foregroundText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        if (jobs.get() <= 0) {
            stopForeground(true)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private companion object {
        const val CHANNEL_ID = "barbaross_build"
        const val NOTIFICATION_ID = 1001
    }
}

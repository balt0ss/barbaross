package dev.barbaross.runtime

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import dev.barbaross.ipc.BuildProtocol
import dev.barbaross.ipc.IBuildService

/** Сервис Build Runtime (библиотека :runtime, процесс ":build"). Не экспортирован — доступен только своему приложению. */
class BuildService : Service() {

    private val binder = object : IBuildService.Stub() {
        override fun getProtocolVersion(): Int = BuildProtocol.VERSION

        override fun ping(payload: String?): String = payload.orEmpty()

        override fun getToolchainStatus(): Bundle = ToolchainInspector.inspect(filesDir)

        override fun runDiagnostics(): String = ExecProbe.run(applicationContext)

        override fun startJdkProbe(): Boolean = JdkProbe.start(applicationContext)

        override fun getJdkProbeStatus(): String = JdkProbe.status()

        override fun startGradleProbe(): Boolean = GradleProbe.start(applicationContext)

        override fun getGradleProbeStatus(): String = GradleProbe.status()

        override fun startAndroidBuildProbe(): Boolean = AndroidBuildProbe.start(applicationContext)

        override fun getAndroidBuildProbeStatus(): String = AndroidBuildProbe.status()
    }

    override fun onBind(intent: Intent?): IBinder = binder
}

package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

/** Учёт и очистка места: старые пробы, кэш Gradle, скачанные файлы, папки build проектов. Символические ссылки не разыменовываются. */
object StorageCleaner {
    private val PROBE_DIRS = listOf("probe", "jdkprobe", "gradleprobe", "androidprobe", "composeprobe")
    private val TARGETS = listOf("probes", "gradle", "downloads", "builds")

    private fun targetFiles(context: Context, target: String): List<File> {
        val p = ToolchainPaths(context)
        val projects = File(context.filesDir, "projects")
        return when (target) {
            "probes" -> PROBE_DIRS.map { File(context.filesDir, it) }
            "gradle" -> listOf(p.gradleUserHome)
            "downloads" -> listOf(p.cache)
            "builds" -> (projects.listFiles() ?: emptyArray()).filter { it.isDirectory }
                .flatMap { listOf(File(it, "build"), File(it, ".gradle")) }
            else -> emptyList()
        }
    }

    private fun sizeOf(f: File): Long {
        if (!f.exists()) return 0L
        var total = 0L
        try {
            Files.walkFileTree(f.toPath(), object : SimpleFileVisitor<Path>() {
                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    total += attrs.size()
                    return FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult = FileVisitResult.CONTINUE
            })
        } catch (_: Exception) {
        }
        return total
    }

    internal fun deleteTree(f: File) {
        val path = f.toPath()
        if (!Files.exists(path, java.nio.file.LinkOption.NOFOLLOW_LINKS)) return
        try {
            Files.walkFileTree(path, object : SimpleFileVisitor<Path>() {
                override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                    dir.toFile().setWritable(true, true)
                    return FileVisitResult.CONTINUE
                }

                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    try { Files.deleteIfExists(file) } catch (_: Exception) {}
                    return FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult = FileVisitResult.CONTINUE

                override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                    try { Files.deleteIfExists(dir) } catch (_: Exception) {}
                    return FileVisitResult.CONTINUE
                }
            })
        } catch (_: Exception) {
        }
    }

    fun info(context: Context): Bundle {
        val p = ToolchainPaths(context)
        return Bundle().apply {
            for (t in TARGETS) putLong(t, targetFiles(context, t).sumOf { sizeOf(it) })
            putLong("toolchain", sizeOf(p.termuxRoot) + sizeOf(p.gradleDir) + sizeOf(p.sdk))
            putLong("free", context.filesDir.usableSpace)
        }
    }

    /** Возвращает null при успехе или текст ошибки. */
    fun clean(context: Context, target: String): String? {
        if (target !in TARGETS) return "Неизвестная цель очистки."
        val p = ToolchainPaths(context)
        if (target == "probes" && !p.isReady()) return "Сначала установите инструменты сборки: старые данные ещё могут понадобиться."
        val base = context.filesDir.canonicalFile
        for (f in targetFiles(context, target)) {
            // Только внутри каталога данных приложения.
            val parent = f.parentFile?.canonicalFile ?: continue
            if (!parent.path.startsWith(base.path)) continue
            deleteTree(f)
        }
        if (target == "downloads") p.cache.mkdirs()
        if (target == "gradle") p.gradleUserHome.mkdirs()
        return null
    }
}

package dev.barbaross.runtime

import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit

/** Ключ подписи для release-APK: PKCS12-хранилище в закрытом каталоге приложения, пароль в файле рядом (доступен только приложению). */
object SigningSupport {
    private fun dir(context: Context) = File(context.filesDir, "signing")
    fun keystore(context: Context) = File(dir(context), "barbaross.jks")
    private fun passFile(context: Context) = File(dir(context), "keystore.pass")

    fun exists(context: Context): Boolean = keystore(context).isFile && passFile(context).isFile

    /** Переменные окружения для Gradle: пароль не попадает ни в аргументы, ни в лог. */
    fun env(context: Context): Map<String, String> =
        if (exists(context)) {
            mapOf(
                "BARBAROSS_KS_FILE" to keystore(context).absolutePath,
                "BARBAROSS_KS_PASS" to passFile(context).readText().trim(),
            )
        } else emptyMap()

    /** Возвращает null при успехе или текст ошибки. */
    fun create(context: Context, name: String, password: String): String? {
        if (exists(context)) return "Ключ уже создан."
        if (!Regex("[A-Za-z0-9 ._-]{1,40}").matches(name)) return "Имя: латиница, цифры, пробел, точка, дефис (до 40 символов)."
        if (password.length < 6 || password.any { it == '\n' || it == '\r' }) return "Пароль: не короче 6 символов, без переводов строк."
        val p = ToolchainPaths(context)
        if (!p.isReady()) return "Сначала установите инструменты сборки."
        val keytool = File(p.javaHome, "bin/keytool")
        if (!keytool.isFile) return "keytool не найден в JDK."
        val d = dir(context).apply { mkdirs() }
        val ks = keystore(context)
        ks.delete()
        return try {
            val pb = ProcessBuilder(
                keytool.absolutePath, "-genkeypair", "-keystore", ks.absolutePath, "-storetype", "PKCS12",
                "-alias", "barbaross", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
                "-dname", "CN=$name", "-storepass", password, "-keypass", password,
                "-J-Duser.home=${p.tmp.absolutePath}", "-J-Djava.io.tmpdir=${p.tmp.absolutePath}",
            ).directory(d).redirectErrorStream(true)
            pb.environment().putAll(p.env())
            val proc = pb.start()
            val out = StringBuffer()
            val reader = Thread { proc.inputStream.bufferedReader().forEachLine { out.append(it).append('\n') } }.apply { isDaemon = true; start() }
            if (!proc.waitFor(120, TimeUnit.SECONDS)) {
                proc.destroyForcibly()
                return "keytool: таймаут."
            }
            reader.join(3000)
            if (proc.exitValue() != 0 || !ks.isFile) {
                ks.delete()
                return "keytool: ${out.toString().replace(password, "***").trim().take(500)}"
            }
            val pf = passFile(context)
            pf.writeText(password + "\n")
            pf.setReadable(false, false)
            pf.setReadable(true, true)
            null
        } catch (e: Exception) {
            ks.delete()
            "Не удалось создать ключ: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    fun delete(context: Context) {
        keystore(context).delete()
        passFile(context).delete()
    }
}

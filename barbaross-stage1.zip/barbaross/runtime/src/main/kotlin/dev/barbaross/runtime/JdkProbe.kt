package dev.barbaross.runtime

import android.content.Context
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.Paths
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.GZIPInputStream

/**
 * ЭКСПЕРИМЕНТ: скачивает OpenJDK 17 из репозитория Termux (aarch64, bionic), распаковывает в filesDir/jdkprobe
 * и запускает `java -version`. Проверяет: сеть на устройстве, формат .deb, жёстко зашитый префикс
 * /data/data/com.termux/files/usr, совместимость с нашим applicationId.
 * Работает в фоне (поток в процессе :build); ход выполнения читается через status().
 */
object JdkProbe {
    private const val REPO = "https://packages.termux.dev/apt/termux-main"
    private const val INDEX = "$REPO/dists/stable/main/binary-aarch64/Packages"
    private const val PKG = "openjdk-17"
    private const val TERMUX_USR = "data/data/com.termux/files/usr"
    private const val MB = 1024L * 1024L
    private val SKIP = setOf("termux-exec", "termux-tools", "termux-keyring", "termux-licenses", "dpkg", "apt")

    private val running = AtomicBoolean(false)
    private val log = StringBuffer()

    const val RUNNING_MARK = "[выполняется]"
    const val DONE_MARK = "[завершено]"

    fun start(context: Context): Boolean {
        if (!running.compareAndSet(false, true)) return false
        log.setLength(0)
        val app = context.applicationContext
        Thread({
            try {
                runProbe(app)
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                running.set(false)
            }
        }, "jdk-probe").start()
        return true
    }

    fun status(): String = (if (running.get()) RUNNING_MARK else DONE_MARK) + "\n" + log

    private fun say(s: String) {
        log.append(s).append('\n')
    }

    private class Entry(val name: String, val filename: String, val size: Long, val sha256: String?, val depends: List<String>)

    private fun runProbe(context: Context) {
        val base = File(context.filesDir, "jdkprobe")
        val root = File(base, "root")
        val cache = File(base, "cache")
        say("Свободно: ${context.filesDir.usableSpace / MB} МБ")
        if (context.filesDir.usableSpace < 1024 * MB) {
            say("Меньше 1 ГБ свободного места, остановлено.")
            return
        }
        root.deleteRecursively()
        root.mkdirs()
        cache.mkdirs()

        say("Читаю индекс пакетов: $INDEX")
        val index = loadIndex()
        say("Пакетов в индексе: ${index.size}")

        val plan = resolve(index)
        if (plan.isEmpty()) return
        say("К установке (${plan.size}): " + plan.joinToString { "${it.name} ${it.size / 1024} КБ" })

        for ((i, e) in plan.withIndex()) {
            say("[${i + 1}/${plan.size}] ${e.name}: скачиваю")
            val deb = File(cache, e.name + ".deb")
            download("$REPO/${e.filename.removePrefix("./")}", deb)
            if (e.sha256 != null) {
                val actual = sha256(deb)
                if (!actual.equals(e.sha256, ignoreCase = true)) {
                    say("  SHA256 НЕ СОВПАЛ (ожидалось ${e.sha256}, получено $actual) — остановлено.")
                    return
                }
            }
            extractDeb(deb, root)
            deb.delete()
        }

        val usr = File(root, TERMUX_USR)
        val java = File(usr, "lib/jvm/java-17-openjdk/bin/java").takeIf { it.isFile }
            ?: usr.walkTopDown().maxDepth(6).firstOrNull { it.isFile && it.name == "java" && it.parentFile?.name == "bin" }
        if (java == null) {
            say("Файл java не найден после распаковки.")
            return
        }
        java.setExecutable(true, false)
        say("java: ${java.absolutePath}")
        say("Запускаю: java -version")
        val tmp = File(root, "tmp").apply { mkdirs() }
        val pb = ProcessBuilder(java.absolutePath, "-version").redirectErrorStream(true)
        pb.environment().apply {
            put("LD_LIBRARY_PATH", File(usr, "lib").absolutePath)
            put("JAVA_HOME", java.parentFile!!.parentFile!!.absolutePath)
            put("HOME", tmp.absolutePath)
            put("TMPDIR", tmp.absolutePath)
            put("PREFIX", usr.absolutePath)
        }
        try {
            val p = pb.start()
            if (!p.waitFor(60, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                say("ТАЙМАУТ 60 с")
                return
            }
            val out = p.inputStream.bufferedReader().readText().trim()
            say("Код выхода: ${p.exitValue()}")
            say(out)
            say(if (p.exitValue() == 0) "РЕЗУЛЬТАТ: JDK запускается." else "РЕЗУЛЬТАТ: JDK не запустился, см. вывод выше.")
        } catch (e: Exception) {
            say("РЕЗУЛЬТАТ: запуск запрещён/не удался: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    /**
     * Ставит пакеты Termux (с зависимостями) в root. exclude — зависимости, которые не ставим.
     * Уже установленные пакеты (маркер root/.installed/<имя> с тем же SHA256) пропускаются — это даёт докачку.
     * isCancelled проверяется между пакетами. true — успех.
     */
    internal fun installPackages(
        roots: List<String>,
        root: File,
        cache: File,
        exclude: Set<String> = emptySet(),
        isCancelled: () -> Boolean = { false },
        out: (String) -> Unit,
    ): Boolean {
        cache.mkdirs()
        val markers = File(root, ".installed").apply { mkdirs() }
        out("Читаю индекс пакетов Termux")
        val index = loadIndex()
        val plan = LinkedHashMap<String, Entry>()
        val queue = ArrayDeque<Entry>()
        for (r in roots) {
            val e = index[r]
            if (e == null) {
                out("Пакет $r не найден в индексе.")
                return false
            }
            queue.addLast(e)
        }
        while (queue.isNotEmpty()) {
            val e = queue.removeFirst()
            if (e.name in plan) continue
            plan[e.name] = e
            for (d in e.depends) {
                if (d in SKIP || d in exclude || d in plan) continue
                val dep = index[d]
                if (dep == null) out("Зависимость не найдена (пропущена): $d") else queue.addLast(dep)
            }
        }
        out("К установке (${plan.size}): " + plan.keys.joinToString())
        for ((i, e) in plan.values.withIndex()) {
            if (isCancelled()) {
                out("Отменено.")
                return false
            }
            val marker = File(markers, e.name)
            if (e.sha256 != null && marker.isFile && marker.readText() == e.sha256) {
                out("[${i + 1}/${plan.size}] ${e.name}: уже установлен")
                continue
            }
            out("[${i + 1}/${plan.size}] ${e.name}")
            val deb = File(cache, e.name + ".deb")
            download("$REPO/${e.filename.removePrefix("./")}", deb)
            if (e.sha256 != null && !sha256(deb).equals(e.sha256, ignoreCase = true)) {
                out("  SHA256 не совпал для ${e.name} — остановлено.")
                return false
            }
            extractDeb(deb, root)
            deb.delete()
            if (e.sha256 != null) marker.writeText(e.sha256)
        }
        return true
    }

    // ---------- индекс и зависимости ----------

    private fun loadIndex(): Map<String, Entry> {
        val text = open(INDEX).use { it.bufferedReader().readText() }
        val map = HashMap<String, Entry>()
        for (block in text.split("\n\n")) {
            val f = HashMap<String, String>()
            var last: String? = null
            for (line in block.lines()) {
                if (line.isEmpty()) continue
                if (line[0] == ' ' || line[0] == '\t') {
                    last?.let { f[it] = f[it] + "\n" + line.trim() }
                } else {
                    val k = line.substringBefore(':')
                    f[k] = line.substringAfter(':').trim()
                    last = k
                }
            }
            val name = f["Package"] ?: continue
            val filename = f["Filename"] ?: continue
            val deps = listOfNotNull(f["Pre-Depends"], f["Depends"]).joinToString(",")
                .split(',').map { it.trim() }.filter { it.isNotEmpty() }
                .map { it.substringBefore('|').substringBefore('(').trim() }
            map[name] = Entry(name, filename, f["Size"]?.toLongOrNull() ?: 0, f["SHA256"], deps)
        }
        return map
    }

    private fun resolve(index: Map<String, Entry>): List<Entry> {
        val start = index[PKG]
        if (start == null) {
            say("Пакет $PKG не найден в индексе.")
            return emptyList()
        }
        val out = LinkedHashMap<String, Entry>()
        val queue = ArrayDeque(listOf(start))
        while (queue.isNotEmpty()) {
            val e = queue.removeFirst()
            if (e.name in out) continue
            out[e.name] = e
            for (d in e.depends) {
                if (d in SKIP || d in out) continue
                val dep = index[d]
                if (dep == null) say("Зависимость не найдена в индексе (пропущена): $d") else queue.addLast(dep)
            }
        }
        return out.values.toList()
    }

    // ---------- сеть ----------

    internal fun open(url: String): InputStream {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        if (code != 200) throw java.io.IOException("HTTP $code для $url")
        return BufferedInputStream(c.inputStream)
    }

    internal fun download(url: String, dest: File) {
        open(url).use { input -> dest.outputStream().use { input.copyTo(it) } }
    }

    internal fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------- .deb = ar-архив с data.tar.{xz,gz} ----------

    private fun extractDeb(deb: File, root: File) {
        val dataTar = File(deb.parentFile, deb.name + ".data")
        var dataName: String? = null
        deb.inputStream().buffered().use { s ->
            val magic = ByteArray(8)
            if (s.read(magic) != 8 || String(magic) != "!<arch>\n") throw java.io.IOException("не ar-архив: ${deb.name}")
            val hdr = ByteArray(60)
            while (s.read(hdr) == 60) {
                val name = String(hdr, 0, 16).trim().trimEnd('/')
                val size = String(hdr, 48, 10).trim().toLong()
                if (name.startsWith("data.tar")) {
                    dataName = name
                    dataTar.outputStream().use { o -> copyN(s, o, size) }
                    break
                }
                skipN(s, size + (size and 1))
            }
        }
        val dn = dataName ?: throw java.io.IOException("в ${deb.name} нет data.tar")
        dataTar.inputStream().buffered().use { raw ->
            val decoded: InputStream = when {
                dn.endsWith(".xz") -> XZCompressorInputStream(raw)
                dn.endsWith(".gz") -> GZIPInputStream(raw)
                else -> throw java.io.IOException("неподдерживаемое сжатие: $dn")
            }
            untar(decoded, root)
        }
        dataTar.delete()
    }

    private fun untar(input: InputStream, root: File) {
        val rootPath = root.toPath().toAbsolutePath().normalize()
        TarArchiveInputStream(input).use { tar ->
            while (true) {
                val e = tar.nextEntry ?: break
                val rel = e.name.removePrefix("./").trimStart('/')
                if (rel.isEmpty()) continue
                val out = File(root, rel)
                val outPath = out.toPath().toAbsolutePath().normalize()
                if (!outPath.startsWith(rootPath)) continue // защита от выхода за пределы root
                when {
                    e.isDirectory -> out.mkdirs()
                    e.isSymbolicLink -> {
                        out.parentFile?.mkdirs()
                        Files.deleteIfExists(outPath)
                        val target = e.linkName
                        // Абсолютные ссылки Termux переписываем в ОТНОСИТЕЛЬНЫЕ внутри root (root можно переносить).
                        val link = if (target.startsWith("/")) {
                            val abs = File(root, target.trimStart('/')).toPath().toAbsolutePath().normalize()
                            outPath.parent.relativize(abs)
                        } else {
                            Paths.get(target)
                        }
                        Files.createSymbolicLink(outPath, link)
                    }
                    e.isFile -> {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tar.copyTo(it) }
                        if (e.mode and 0b001_001_001 != 0) out.setExecutable(true, false)
                    }
                }
            }
        }
    }

    private fun copyN(s: InputStream, o: java.io.OutputStream, n: Long) {
        var left = n
        val buf = ByteArray(64 * 1024)
        while (left > 0) {
            val r = s.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (r < 0) throw java.io.IOException("неожиданный конец архива")
            o.write(buf, 0, r)
            left -= r
        }
    }

    private fun skipN(s: InputStream, n: Long) {
        var left = n
        while (left > 0) {
            val k = s.skip(left)
            if (k <= 0) {
                if (s.read() < 0) throw java.io.IOException("неожиданный конец архива")
                left -= 1
            } else left -= k
        }
    }
}

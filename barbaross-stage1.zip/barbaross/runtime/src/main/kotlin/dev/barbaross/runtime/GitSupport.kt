package dev.barbaross.runtime

import android.content.Context
import android.os.Bundle
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Git на устройстве: бинарник `git` (+ca-certificates) из пакетов Termux (aarch64) ставится в тот же префикс, что и JDK.
 * Команды запускаются из службы сборки; токен передаётся только через окружение процесса (GIT_ASKPASS), не через аргументы.
 */
object GitSupport {
    /** Ненужные для базового Git зависимости. */
    private val EXCLUDE = setOf("perl", "less", "python")

    /** Разрешённые подкоманды. Глобальные опции (-c и т.п.) невозможны: argv[0] обязан быть подкомандой. */
    private val ALLOWED = setOf(
        "status", "add", "commit", "log", "diff", "branch", "checkout", "switch", "restore", "init", "clone",
        "pull", "push", "fetch", "remote", "show", "rev-parse", "merge", "stash", "tag", "reset", "rm", "mv",
    )
    private const val MAX_OUT = 200_000

    // ---------- установка ----------

    private val running = AtomicBoolean(false)
    private val cancelled = AtomicBoolean(false)
    @Volatile private var success = false
    @Volatile private var done = false
    private val log = StringBuffer()

    fun isInstalled(context: Context): Boolean {
        val p = ToolchainPaths(context)
        return File(p.usr, "bin/git").isFile && File(p.usr, "libexec/git-core").isDirectory
    }

    fun startInstall(context: Context, cb: JobCallbacks): Boolean {
        if (!running.compareAndSet(false, true)) return false
        cancelled.set(false)
        success = false
        done = false
        log.setLength(0)
        val app = context.applicationContext
        cb.started("Установка Git")
        Thread({
            try {
                success = install(app)
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                done = true
                running.set(false)
                cb.finished()
            }
        }, "git-install").start()
        return true
    }

    fun cancelInstall() {
        cancelled.set(true)
    }

    fun installStatus(): Bundle = Bundle().apply {
        putBoolean("running", running.get())
        putBoolean("done", done)
        putBoolean("success", success)
        putString("log", log.toString())
    }

    private fun say(s: String) {
        log.append(s).append('\n')
    }

    private fun install(context: Context): Boolean {
        val p = ToolchainPaths(context)
        if (!p.isReady()) {
            say("Сначала установите инструменты сборки (Настройки → Инструменты сборки).")
            return false
        }
        say("Ставлю git и ca-certificates (пакеты Termux)")
        if (!JdkProbe.installPackages(listOf("git", "ca-certificates"), p.termuxRoot, p.cache, EXCLUDE, { cancelled.get() }) { say(it) }) {
            return false
        }
        val git = File(p.usr, "bin/git")
        git.setExecutable(true, false)
        val r = execSimple(listOf(git.absolutePath, "--version"), gitEnv(p, "", "", "", null, null), p.tmp, 30)
        say("git --version: ${r.second.lines().firstOrNull().orEmpty()}")
        if (r.first != 0) return false
        val remoteHttps = File(p.usr, "libexec/git-core/git-remote-https")
        say(if (remoteHttps.exists()) "HTTPS-транспорт: есть" else "HTTPS-транспорт НЕ найден (clone/push по https не будут работать)")
        say("ГОТОВО: Git установлен.")
        return true
    }

    private fun execSimple(cmd: List<String>, env: Map<String, String>, dir: File, timeoutSec: Long): Pair<Int, String> {
        return try {
            val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
            pb.environment().putAll(env)
            val proc = pb.start()
            val sb = StringBuffer()
            val reader = Thread { proc.inputStream.bufferedReader().forEachLine { sb.append(it).append('\n') } }.apply { isDaemon = true; start() }
            if (!proc.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                proc.destroyForcibly()
                return -1 to "таймаут $timeoutSec с"
            }
            reader.join(3000)
            proc.exitValue() to sb.toString().trim()
        } catch (e: Exception) {
            -1 to "${e.javaClass.simpleName}: ${e.message}"
        }
    }

    // ---------- запуск команд ----------

    private fun gitEnv(
        p: ToolchainPaths,
        name: String,
        email: String,
        user: String,
        token: String?,
        askpass: File?,
    ): Map<String, String> {
        val usr = p.usr
        val env = HashMap(p.env())
        env["PATH"] = File(usr, "bin").absolutePath + ":/system/bin"
        env["GIT_EXEC_PATH"] = File(usr, "libexec/git-core").absolutePath
        env["GIT_TEMPLATE_DIR"] = File(usr, "share/git-core/templates").absolutePath
        env["GIT_SSL_CAINFO"] = File(usr, "etc/tls/cert.pem").absolutePath
        env["GIT_CONFIG_NOSYSTEM"] = "1"
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["GIT_PAGER"] = "cat"
        env["GIT_MERGE_AUTOEDIT"] = "no"
        env["GIT_ALLOW_PROTOCOL"] = "https:http"
        env["GIT_CONFIG_COUNT"] = "2"
        env["GIT_CONFIG_KEY_0"] = "core.quotepath"
        env["GIT_CONFIG_VALUE_0"] = "false"
        env["GIT_CONFIG_KEY_1"] = "pull.rebase"
        env["GIT_CONFIG_VALUE_1"] = "false"
        if (name.isNotBlank()) {
            env["GIT_AUTHOR_NAME"] = name
            env["GIT_COMMITTER_NAME"] = name
        }
        if (email.isNotBlank()) {
            env["GIT_AUTHOR_EMAIL"] = email
            env["GIT_COMMITTER_EMAIL"] = email
        }
        if (askpass != null && !token.isNullOrEmpty()) {
            env["GIT_ASKPASS"] = askpass.absolutePath
            env["BARBAROSS_GIT_USER"] = user.ifBlank { "git" }
            env["BARBAROSS_GIT_TOKEN"] = token
        }
        return env
    }

    private fun result(code: Int, output: String) = Bundle().apply {
        putInt("code", code)
        putString("output", output)
    }

    private fun failure(text: String) = Bundle().apply { putString("error", text) }

    fun run(
        context: Context,
        dirPath: String,
        argv: List<String>,
        network: Boolean,
        name: String,
        email: String,
        user: String,
        token: String?,
        cb: JobCallbacks,
    ): Bundle {
        if (argv.isEmpty() || argv[0] !in ALLOWED) return failure("Команда git не разрешена: ${argv.firstOrNull().orEmpty()}")
        for (a in argv) {
            if (a.startsWith("--upload-pack") || a.startsWith("--receive-pack") || a.startsWith("--exec") ||
                a.startsWith("--config") || a.startsWith("--template") || a.contains("ext::")
            ) return failure("Недопустимый аргумент: $a")
        }
        if (argv[0] == "clone" && argv.any { it == "-u" || it == "-c" }) return failure("Недопустимый аргумент для clone.")
        if (!isInstalled(context)) return failure("Git не установлен. Установите его в Настройках.")

        val p = ToolchainPaths(context)
        val projects = File(context.filesDir, "projects").canonicalFile
        val dir = File(dirPath).canonicalFile
        val allowed = dir.path.startsWith(projects.path + File.separator) || (dir == projects && argv[0] == "clone")
        if (!allowed || !dir.isDirectory) return failure("Каталог должен быть внутри каталога проектов IDE.")

        val askpass = if (network && !token.isNullOrEmpty()) {
            File(p.root, "git-askpass.sh").apply {
                writeText(
                    "#!/system/bin/sh\n" +
                        "case \"\$1\" in\n" +
                        "Username*) printf '%s\\n' \"\$BARBAROSS_GIT_USER\" ;;\n" +
                        "*) printf '%s\\n' \"\$BARBAROSS_GIT_TOKEN\" ;;\n" +
                        "esac\n"
                )
                setExecutable(true, true)
            }
        } else null

        if (network) cb.started("Git: ${argv[0]}")
        try {
            val cmd = listOf(File(p.usr, "bin/git").absolutePath) + argv
            val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
            pb.environment().putAll(gitEnv(p, name, email, user, token, askpass))
            val proc = pb.start()
            val sb = StringBuffer()
            val reader = Thread {
                proc.inputStream.bufferedReader().forEachLine { if (sb.length < MAX_OUT) sb.append(it).append('\n') }
            }.apply { isDaemon = true; start() }
            val timeout = if (network) 600L else 60L
            if (!proc.waitFor(timeout, TimeUnit.SECONDS)) {
                proc.destroyForcibly()
                return result(-1, scrub(sb.toString(), token) + "\nТАЙМАУТ $timeout с")
            }
            reader.join(3000)
            return result(proc.exitValue(), scrub(sb.toString(), token))
        } catch (e: Exception) {
            return failure("Не удалось запустить git: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            if (network) cb.finished()
        }
    }

    private fun scrub(text: String, token: String?): String =
        if (token.isNullOrEmpty()) text else text.replace(token, "***")
}

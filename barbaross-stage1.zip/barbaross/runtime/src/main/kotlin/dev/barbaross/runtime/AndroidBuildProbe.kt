package dev.barbaross.runtime

import android.app.ActivityManager
import android.content.Context
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * ЭКСПЕРИМЕНТ: настоящая сборка Android-приложения на телефоне.
 * Шаги: aapt2 (arm64, Termux) -> платформа android-36 и build-tools 36.0.0 из репозитория Google ->
 * мини-проект (Java, без AndroidX) -> Gradle + AGP 8.13.0 :assembleDebug.
 * Требует выполненные пробы JDK и Gradle. Скачивание SDK-компонентов Google подразумевает принятие
 * Android SDK License (в финальном продукте нужен явный экран согласия).
 */
object AndroidBuildProbe {
    private const val GRADLE_VERSION = "8.14.3"
    private const val AGP_VERSION = "8.13.0"
    private const val COMPILE_SDK = 36
    private const val BUILD_TOOLS = "36.0.0"
    private const val SDK_REPO = "https://dl.google.com/android/repository"
    private const val TERMUX_USR = "data/data/com.termux/files/usr"
    private const val MB = 1024L * 1024L

    private val running = AtomicBoolean(false)
    private val log = StringBuffer()

    fun start(context: Context): Boolean {
        if (!running.compareAndSet(false, true)) return false
        log.setLength(0)
        val app = context.applicationContext
        Thread({
            try {
                runProbe(app)
            } catch (t: Throwable) {
                say("ОШИБКА: ${t.javaClass.simpleName}: ${t.message}")
            } finally {
                running.set(false)
            }
        }, "android-build-probe").start()
        return true
    }

    fun status(): String = (if (running.get()) JdkProbe.RUNNING_MARK else JdkProbe.DONE_MARK) + "\n" + log

    private fun say(s: String) {
        log.append(s).append('\n')
    }

    private fun memLine(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return "RAM доступно ${mi.availMem / MB} МБ из ${mi.totalMem / MB} МБ; свободно на диске ${context.filesDir.usableSpace / MB} МБ"
    }

    private fun runProbe(context: Context) {
        val jdkRoot = File(context.filesDir, "jdkprobe/root")
        val usr = File(jdkRoot, TERMUX_USR)
        val java = File(usr, "lib/jvm/java-17-openjdk/bin/java")
        val launcherJar = File(context.filesDir, "gradleprobe/dist").walkTopDown()
            .firstOrNull { it.isFile && it.name.startsWith("gradle-launcher-") && it.name.endsWith(".jar") }
        if (!java.isFile || launcherJar == null) {
            say("Нужны JDK и Gradle. Сначала выполните «Проба JDK» и «Проба Gradle».")
            return
        }
        val base = File(context.filesDir, "androidprobe").apply { mkdirs() }
        val sdk = File(base, "sdk")
        val tmp = File(base, "tmp").apply { mkdirs() }
        say(memLine(context))
        if (context.filesDir.usableSpace < 3 * 1024 * MB) {
            say("Меньше 3 ГБ свободного места, остановлено.")
            return
        }

        val env = mapOf(
            "LD_LIBRARY_PATH" to File(usr, "lib").absolutePath,
            "JAVA_HOME" to java.parentFile!!.parentFile!!.absolutePath,
            "HOME" to tmp.absolutePath,
            "TMPDIR" to tmp.absolutePath,
            "PREFIX" to usr.absolutePath,
            "GRADLE_USER_HOME" to File(context.filesDir, "gradleprobe/gradle-user-home").absolutePath,
            "ANDROID_USER_HOME" to File(base, "android-home").apply { mkdirs() }.absolutePath,
            "ANDROID_HOME" to sdk.absolutePath,
            "ANDROID_SDK_ROOT" to sdk.absolutePath,
        )

        // 1. aapt2 для arm64 (Termux)
        say("\n== 1. aapt2 (Termux, arm64) ==")
        val aapt2 = File(usr, "bin/aapt2")
        if (!aapt2.isFile) {
            if (!JdkProbe.installPackages(listOf("aapt2"), jdkRoot, File(base, "cache")) { say(it) }) return
        }
        aapt2.setExecutable(true, false)
        if (!aapt2.isFile) {
            say("aapt2 не найден после установки: ${aapt2.absolutePath}")
            return
        }
        exec(listOf(aapt2.absolutePath, "version"), env, base, 30)

        // 2. SDK: платформа и build-tools
        say("\n== 2. Android SDK (Google) ==")
        val platform = File(sdk, "platforms/android-$COMPILE_SDK")
        val buildTools = File(sdk, "build-tools/$BUILD_TOOLS")
        if (!platform.isDirectory || !buildTools.isDirectory) {
            val manifest = loadRepositoryXml()
            if (!installSdkPackage(manifest, "platforms;android-$COMPILE_SDK", platform, base)) return
            if (!installSdkPackage(manifest, "build-tools;$BUILD_TOOLS", buildTools, base)) return
        } else {
            say("SDK-компоненты уже установлены.")
        }
        // Бинарники build-tools из репозитория Google — x86_64; подменяем aapt2 на arm64-версию.
        aapt2.copyTo(File(buildTools, "aapt2"), overwrite = true)
        File(buildTools, "aapt2").setExecutable(true, false)

        // 3. Проект
        say("\n== 3. Проект ==")
        val proj = File(base, "app").apply { deleteRecursively(); mkdirs() }
        writeProject(proj, sdk, aapt2, tmp)

        // 4. Сборка
        say("\n== 4. Gradle + AGP $AGP_VERSION :assembleDebug ==")
        say("Первый запуск скачивает AGP и зависимости с Google Maven (сотни МБ), это может занять много минут.")
        say(memLine(context))
        val cmd = listOf(java.absolutePath, "-Xmx64m", "-Xms64m", "-Dorg.gradle.appname=gradle",
            "-Djava.io.tmpdir=${tmp.absolutePath}", "-Duser.home=${tmp.absolutePath}",
            "-classpath", launcherJar.absolutePath, "org.gradle.launcher.GradleMain",
            "--no-daemon", "--console=plain", "--stacktrace", "assembleDebug")
        val t0 = System.currentTimeMillis()
        val code = exec(cmd, env, proj, 30 * 60)
        say("Время: ${(System.currentTimeMillis() - t0) / 1000} с; ${memLine(context)}")
        if (code == 137 || code == 143 || code == 9) say("Код $code: процесс убит системой (память или phantom process killer).")

        val apk = File(proj, "build/outputs/apk/debug/app-debug.apk")
        if (code != 0 || !apk.isFile) {
            say("РЕЗУЛЬТАТ: сборка Android-приложения не удалась (код $code).")
            return
        }
        say("\n== 5. Проверка APK ==")
        say("Файл: ${apk.absolutePath} (${apk.length() / 1024} КБ)")
        ZipFile(apk).use { z -> say("Содержимое: " + z.entries().asSequence().map { it.name }.filter { !it.startsWith("META-INF/") }.joinToString()) }
        say("РЕЗУЛЬТАТ: Android-приложение собрано на телефоне.")
    }

    // ---------- SDK ----------

    private fun loadRepositoryXml(): String {
        for (name in listOf("repository2-3.xml", "repository2-2.xml")) {
            try {
                say("Читаю $SDK_REPO/$name")
                return JdkProbe.open("$SDK_REPO/$name").use { it.bufferedReader().readText() }
            } catch (e: Exception) {
                say("  не удалось: ${e.message}")
            }
        }
        throw IllegalStateException("репозиторий SDK Google недоступен")
    }

    private fun installSdkPackage(xml: String, path: String, target: File, base: File): Boolean {
        val block = Regex("<remotePackage path=\"${Regex.escape(path)}\".*?</remotePackage>", RegexOption.DOT_MATCHES_ALL).find(xml)?.value
        if (block == null) {
            say("Пакет $path не найден в репозитории.")
            return false
        }
        val archives = Regex("<archive>.*?</archive>", RegexOption.DOT_MATCHES_ALL).findAll(block).map { it.value }.toList()
        val archive = archives.firstOrNull { "<host-os>linux</host-os>" in it }
            ?: archives.firstOrNull { "<host-os>" !in it }
            ?: archives.firstOrNull()
        if (archive == null) {
            say("Для $path нет архивов.")
            return false
        }
        val url = Regex("<url>(.*?)</url>").find(archive)?.groupValues?.get(1)
        val sha1 = Regex("<checksum[^>]*>(.*?)</checksum>").find(archive)?.groupValues?.get(1)
        if (url == null) {
            say("Для $path не найден URL.")
            return false
        }
        say("Скачиваю $path: $url")
        val zip = File(base, "sdk-download.zip")
        JdkProbe.download("$SDK_REPO/$url", zip)
        if (sha1 != null) {
            val actual = sha1(zip)
            if (!actual.equals(sha1, ignoreCase = true)) {
                say("SHA1 НЕ СОВПАЛ (ожидалось $sha1, получено $actual) — остановлено.")
                zip.delete()
                return false
            }
        }
        val unpack = File(base, "sdk-unpack").apply { deleteRecursively(); mkdirs() }
        unzip(zip, unpack)
        zip.delete()
        val top = unpack.listFiles()?.singleOrNull { it.isDirectory } ?: unpack
        target.deleteRecursively()
        target.parentFile?.mkdirs()
        if (!top.renameTo(target)) {
            top.copyRecursively(target, overwrite = true)
            top.deleteRecursively()
        }
        unpack.deleteRecursively()
        say("  установлено: ${target.absolutePath}")
        return true
    }

    private fun sha1(f: File): String {
        val md = java.security.MessageDigest.getInstance("SHA-1")
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------- проект ----------

    private fun writeProject(proj: File, sdk: File, aapt2: File, tmp: File) {
        File(proj, "local.properties").writeText("sdk.dir=${sdk.absolutePath}\n")
        File(proj, "settings.gradle").writeText(
            """
            pluginManagement {
                repositories { google(); mavenCentral(); gradlePluginPortal() }
            }
            dependencyResolutionManagement {
                repositories { google(); mavenCentral() }
            }
            rootProject.name = 'probeapp'
            """.trimIndent() + "\n"
        )
        File(proj, "build.gradle").writeText(
            """
            plugins { id 'com.android.application' version '$AGP_VERSION' }
            android {
                namespace 'dev.barbaross.probeapp'
                compileSdk $COMPILE_SDK
                buildToolsVersion '$BUILD_TOOLS'
                defaultConfig {
                    applicationId 'dev.barbaross.probeapp'
                    minSdk 29
                    targetSdk 28
                    versionCode 1
                    versionName '1.0'
                }
                compileOptions {
                    sourceCompatibility JavaVersion.VERSION_17
                    targetCompatibility JavaVersion.VERSION_17
                }
            }
            """.trimIndent() + "\n"
        )
        File(proj, "gradle.properties").writeText(
            """
            org.gradle.daemon=false
            org.gradle.parallel=false
            org.gradle.workers.max=2
            org.gradle.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=384m -Djava.io.tmpdir=${tmp.absolutePath} -Duser.home=${tmp.absolutePath}
            android.aapt2FromMavenOverride=${aapt2.absolutePath}
            android.useAndroidX=false
            """.trimIndent() + "\n"
        )
        File(proj, "src/main/AndroidManifest.xml").apply { parentFile!!.mkdirs() }.writeText(
            """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application android:label="Probe App">
                    <activity android:name=".MainActivity" android:exported="true">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
            """.trimIndent() + "\n"
        )
        File(proj, "src/main/java/dev/barbaross/probeapp").mkdirs()
        File(proj, "src/main/java/dev/barbaross/probeapp/MainActivity.java").writeText(
            """
            package dev.barbaross.probeapp;

            import android.app.Activity;
            import android.os.Bundle;
            import android.widget.TextView;

            public class MainActivity extends Activity {
                @Override
                protected void onCreate(Bundle savedInstanceState) {
                    super.onCreate(savedInstanceState);
                    TextView t = new TextView(this);
                    t.setText("Собрано на телефоне");
                    setContentView(t);
                }
            }
            """.trimIndent() + "\n"
        )
    }

    // ---------- процессы ----------

    private fun exec(cmd: List<String>, env: Map<String, String>, dir: File, timeoutSec: Long): Int {
        return try {
            val pb = ProcessBuilder(cmd).directory(dir).redirectErrorStream(true)
            pb.environment().putAll(env)
            val p = pb.start()
            val reader = Thread { p.inputStream.bufferedReader().forEachLine { say("  $it") } }.apply { isDaemon = true; start() }
            if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                say("ТАЙМАУТ $timeoutSec с")
                return -1
            }
            reader.join(3000)
            say("код выхода: ${p.exitValue()}")
            p.exitValue()
        } catch (e: Exception) {
            say("запуск не удался: ${e.javaClass.simpleName}: ${e.message}")
            -1
        }
    }

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.toPath().toAbsolutePath().normalize()
        ZipInputStream(zip.inputStream().buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val out = File(dest, e.name)
                if (!out.toPath().toAbsolutePath().normalize().startsWith(destPath)) continue
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    out.outputStream().use { z.copyTo(it) }
                }
            }
        }
    }
}

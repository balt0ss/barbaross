plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// targetSdk = 28 ОСОЗНАННО (решение по итогам диагностики на POCO F4, Android 14, см. docs/PLAN.md):
// при targetSdk >= 29 система запрещает exec файлов из filesDir, а Gradle/AGP сами порождают процессы
// (java, aapt2, kotlin daemon). Подход Termux. Не для Google Play. Переопределение: -Pbarbaross.targetSdk=36.
val probeTargetSdk = (project.findProperty("barbaross.targetSdk") as String?)?.toInt() ?: 28

android {
    namespace = "dev.barbaross.ide"
    compileSdk = 36

    defaultConfig {
        applicationId = if (probeTargetSdk == 28) "dev.barbaross.ide" else "dev.barbaross.ide.t$probeTargetSdk"
        minSdk = 28
        targetSdk = probeTargetSdk
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(project(":ipc"))
    implementation(project(":runtime"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    testImplementation(libs.junit)
}

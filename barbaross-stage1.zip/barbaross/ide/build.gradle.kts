plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

// Для эксперимента с запуском бинарников: -Pbarbaross.targetSdk=28 собирает копию с другим applicationId.
val probeTargetSdk = (project.findProperty("barbaross.targetSdk") as String?)?.toInt() ?: 36

android {
    namespace = "dev.barbaross.ide"
    compileSdk = 36

    defaultConfig {
        applicationId = if (probeTargetSdk == 36) "dev.barbaross.ide" else "dev.barbaross.ide.t$probeTargetSdk"
        minSdk = 29
        targetSdk = probeTargetSdk
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation(project(":ipc"))
    implementation(project(":runtime"))
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    testImplementation(libs.junit)
}

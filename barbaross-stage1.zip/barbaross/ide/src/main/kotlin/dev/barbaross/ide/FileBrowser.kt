package dev.barbaross.ide

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

private sealed interface FileDialog {
    data object NewFile : FileDialog
    data object NewDir : FileDialog
    data class Rename(val file: File) : FileDialog
    data class Delete(val file: File) : FileDialog
}

private fun validName(name: String) =
    name.isNotBlank() && name != "." && name != ".." && '/' !in name && '\u0000' !in name

/** Дерево файлов проекта: навигация по папкам, создание, переименование, удаление. Работает строго внутри root. */
@Composable
fun FileBrowser(root: File, onOpen: (File) -> Unit) {
    var dir by remember(root) { mutableStateOf(root) }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    val entries = remember(dir, refresh) {
        dir.listFiles { f -> !Fs.isLink(f) }?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
    }
    val rel = dir.relativeTo(root).path.ifEmpty { "." }

    Text("Файлы: ${root.name}/${if (rel == ".") "" else rel}", style = MaterialTheme.typography.titleSmall)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (dir != root) OutlinedButton(onClick = { dir = dir.parentFile ?: root }) { Text("↑ Вверх") }
        OutlinedButton(onClick = { dialog = FileDialog.NewFile }) { Text("+ Файл") }
        OutlinedButton(onClick = { dialog = FileDialog.NewDir }) { Text("+ Папка") }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    if (entries.isEmpty()) Text("Папка пуста.")
    entries.forEach { f ->
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(
                onClick = { if (f.isDirectory) dir = f else onOpen(f) },
                modifier = Modifier.weight(1f),
            ) { Text((if (f.isDirectory) "📁 " else "📄 ") + f.name, maxLines = 1) }
            TextButton(onClick = { dialog = FileDialog.Rename(f) }) { Text("✏️") }
            TextButton(onClick = { dialog = FileDialog.Delete(f) }) { Text("🗑️") }
        }
    }

    when (val d = dialog) {
        FileDialog.NewFile, FileDialog.NewDir -> NameDialog(
            title = if (d == FileDialog.NewFile) "Новый файл" else "Новая папка",
            initial = "",
            onDismiss = { dialog = null },
            onOk = { name ->
                dialog = null
                val target = File(dir, name)
                message = when {
                    target.exists() -> "«$name» уже существует."
                    d == FileDialog.NewDir -> if (target.mkdirs()) null else "Не удалось создать папку."
                    else -> try {
                        target.createNewFile()
                        null
                    } catch (e: Exception) {
                        "Не удалось создать файл: ${e.message}"
                    }
                }
                refresh++
                if (message == null && d == FileDialog.NewFile) onOpen(target)
            },
        )
        is FileDialog.Rename -> NameDialog(
            title = "Переименовать",
            initial = d.file.name,
            onDismiss = { dialog = null },
            onOk = { name ->
                dialog = null
                val target = File(d.file.parentFile, name)
                message = when {
                    target.exists() -> "«$name» уже существует."
                    d.file.renameTo(target) -> null
                    else -> "Не удалось переименовать."
                }
                refresh++
            },
        )
        is FileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Удалить?") },
            text = { Text("«${d.file.name}»" + (if (d.file.isDirectory) " и всё внутри" else "") + " будет удалено безвозвратно.") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    message = if (Fs.deleteTree(d.file)) null else "Не удалось удалить."
                    refresh++
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Отмена") } },
        )
        null -> {}
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Имя") }) },
        confirmButton = { TextButton(enabled = validName(name.trim()), onClick = { onOk(name.trim()) }) { Text("ОК") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

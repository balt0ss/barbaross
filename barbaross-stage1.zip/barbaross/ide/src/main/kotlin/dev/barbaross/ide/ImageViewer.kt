package dev.barbaross.ide

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

internal val IMAGE_EXT = setOf("png", "jpg", "jpeg", "webp", "gif", "bmp")

/** Просмотр картинки с масштабированием двумя пальцами. SVG и прочее открываются как текст. */
@Composable
fun ImageViewer(file: File) {
    val bmp by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, file) {
        value = withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, bounds)
                var sample = 1
                while (bounds.outWidth / sample > 2048 || bounds.outHeight / sample > 2048) sample *= 2
                BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
            } catch (e: Throwable) {
                null
            }
        }
    }
    var scale by remember(file) { mutableFloatStateOf(1f) }
    var offX by remember(file) { mutableFloatStateOf(0f) }
    var offY by remember(file) { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxSize()) {
        Text(
            "${file.name} · ${FileOps.humanSize(file.length())}" + (bmp?.let { " · ${it.width}×${it.height}" } ?: ""),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(10.dp),
        )
        Box(Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b == null) {
                Text("Не удалось показать изображение.")
            } else {
                Image(
                    bitmap = b,
                    contentDescription = file.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(file) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 8f)
                                offX += pan.x
                                offY += pan.y
                                if (scale == 1f) { offX = 0f; offY = 0f }
                            }
                        }
                        .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offX, translationY = offY),
                )
            }
        }
    }
}

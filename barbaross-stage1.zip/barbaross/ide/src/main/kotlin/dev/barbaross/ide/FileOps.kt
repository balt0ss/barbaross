package dev.barbaross.ide

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Операции с файлами проекта. Все пути проверяются: работаем только внутри корня проекта, символические ссылки не трогаем. */
internal object FileOps {
    enum class SortBy(val title: String) { Name("По имени"), Size("По размеру"), Date("По дате") }

    /** Лежит ли file внутри root (или это сам root). */
    fun inside(root: File, file: File): Boolean = try {
        val r = root.canonicalPath
        val c = file.canonicalPath
        c == r || c.startsWith(r + File.separator)
    } catch (e: Exception) {
        false
    }

    private fun size(f: File): Long = if (f.isFile) f.length() else 0L

    fun list(dir: File, sort: SortBy, desc: Boolean, showHidden: Boolean): List<File> {
        val items = dir.listFiles { f -> !Fs.isLink(f) && (showHidden || !f.name.startsWith(".")) } ?: return emptyList()
        val cmp: Comparator<File> = when (sort) {
            SortBy.Name -> compareBy<File> { it.name.lowercase() }
            SortBy.Size -> compareBy<File> { size(it) }
            SortBy.Date -> compareBy<File> { it.lastModified() }
        }
        // Папки всегда сверху; внутри группы — выбранная сортировка.
        val ordered = items.sortedWith(if (desc) cmp.reversed() else cmp)
        return ordered.filter { it.isDirectory } + ordered.filter { !it.isDirectory }
    }

    /** Поиск по имени (подстрока) или по расширению (запрос вида «.kt» или «*.kt»). */
    fun search(root: File, query: String, showHidden: Boolean, limit: Int = 300): List<File> {
        val q = query.trim().lowercase().removePrefix("*")
        if (q.isEmpty()) return emptyList()
        val out = ArrayList<File>()
        fun walk(d: File) {
            if (out.size >= limit) return
            val kids = d.listFiles { f -> !Fs.isLink(f) && (showHidden || !f.name.startsWith(".")) } ?: return
            for (f in kids.sortedBy { it.name.lowercase() }) {
                if (out.size >= limit) return
                val n = f.name.lowercase()
                val hit = if (q.startsWith(".")) (f.isFile && n.endsWith(q)) || n.contains(q) else n.contains(q)
                if (hit) out.add(f)
                if (f.isDirectory) walk(f)
            }
        }
        walk(root)
        return out
    }

    /** Свободное имя рядом с исходным: «a.txt» → «a копия.txt» → «a копия 2.txt». */
    fun uniqueName(dir: File, name: String, suffix: String = " копия"): File {
        val dot = name.lastIndexOf('.')
        val (base, ext) = if (dot > 0) name.substring(0, dot) to name.substring(dot) else name to ""
        var f = File(dir, name)
        if (!f.exists()) return f
        f = File(dir, "$base$suffix$ext")
        var i = 2
        while (f.exists()) {
            f = File(dir, "$base$suffix $i$ext")
            i++
        }
        return f
    }

    /** Рекурсивное копирование без символических ссылок. */
    fun copyTree(src: File, dst: File): Boolean {
        if (Fs.isLink(src)) return false
        if (src.isDirectory) {
            if (!dst.mkdirs() && !dst.isDirectory) return false
            var ok = true
            for (c in src.listFiles().orEmpty()) {
                if (Fs.isLink(c)) continue
                if (!copyTree(c, File(dst, c.name))) ok = false
            }
            return ok
        }
        return try {
            src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Копирование в папку dir (нельзя копировать папку в саму себя). Возвращает созданный файл или текст ошибки. */
    fun copyInto(root: File, src: File, dir: File): Pair<File?, String?> {
        if (!inside(root, src) || !inside(root, dir)) return null to "Операции разрешены только внутри проекта."
        if (src.isDirectory && inside(src, dir)) return null to "Нельзя копировать «${src.name}» в саму себя."
        val dst = uniqueName(dir, src.name)
        return if (copyTree(src, dst)) dst to null else null to "Не удалось скопировать «${src.name}»."
    }

    /** Перемещение в папку dir. Если имя занято — добавляется «копия». */
    fun moveInto(root: File, src: File, dir: File): Pair<File?, String?> {
        if (!inside(root, src) || !inside(root, dir)) return null to "Операции разрешены только внутри проекта."
        if (src == root) return null to "Нельзя переместить корень проекта."
        if (src.isDirectory && inside(src, dir)) return null to "Нельзя переместить «${src.name}» в саму себя."
        if (src.parentFile == dir) return src to null
        val dst = uniqueName(dir, src.name)
        if (src.renameTo(dst)) return dst to null
        // renameTo может не сработать между разными томами: копируем и удаляем.
        if (copyTree(src, dst)) {
            return if (Fs.deleteTree(src)) dst to null else dst to "Скопировано, но исходник удалить не удалось."
        }
        Fs.deleteTree(dst)
        return null to "Не удалось переместить «${src.name}»."
    }

    fun humanSize(b: Long): String = when {
        b < 1024 -> "$b Б"
        b < 1024 * 1024 -> "${b / 1024} КБ"
        else -> String.format(Locale.US, "%.1f МБ", b / 1048576.0)
    }

    fun humanDate(ms: Long): String = SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault()).format(Date(ms))

    fun icon(f: File, open: Boolean = false): String {
        if (f.isDirectory) {
            return when (f.name) {
                ".git" -> "🌿"
                "build", ".gradle" -> "⚙️"
                else -> if (open) "📂" else "📁"
            }
        }
        return when (f.extension.lowercase()) {
            "kt", "kts" -> "🟣"
            "java" -> "☕"
            "xml" -> "🧾"
            "gradle" -> "🐘"
            "json" -> "🔣"
            "md", "txt" -> "📝"
            "png", "jpg", "jpeg", "webp", "gif", "svg" -> "🖼️"
            "apk", "jar", "aar", "zip" -> "📦"
            "properties", "toml", "yml", "yaml", "cfg" -> "🛠️"
            "sh", "bat" -> "⌨️"
            else -> "📄"
        }
    }
}

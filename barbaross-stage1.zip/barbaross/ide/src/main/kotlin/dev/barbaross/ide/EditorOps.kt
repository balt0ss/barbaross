package dev.barbaross.ide

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/** Правки текста для панели инструментов редактора: комментарий, отступы, дублирование строки, вставка символов. */
internal object EditorOps {
    /** Начало первой и конец последней строки выделения (конец — перед символом новой строки). */
    private fun range(t: String, sel: TextRange): Pair<Int, Int> {
        val a = sel.min
        val b = sel.max
        val start = t.lastIndexOf('\n', a - 1) + 1
        val endRef = if (b > a && b > 0 && t[b - 1] == '\n') b - 1 else b
        val nl = t.indexOf('\n', endRef)
        return start to (if (nl < 0) t.length else nl)
    }

    private fun apply(ed: EditorState, f: (List<String>) -> List<String>) {
        val v = ed.value
        val t = v.text
        val (start, end) = range(t, v.selection)
        val block = f(t.substring(start, end).split('\n')).joinToString("\n")
        val newText = t.substring(0, start) + block + t.substring(end)
        val sel = v.selection
        val newSel = if (sel.collapsed) {
            TextRange((sel.start + block.length - (end - start)).coerceIn(start, start + block.length))
        } else {
            TextRange(start, start + block.length)
        }
        ed.replaceValue(TextFieldValue(newText, newSel))
    }

    fun toggleComment(ed: EditorState) = apply(ed) { lines ->
        val nonBlank = lines.filter { it.isNotBlank() }
        val allCommented = nonBlank.isNotEmpty() && nonBlank.all { it.trimStart().startsWith("//") }
        lines.map { l ->
            if (l.isBlank()) {
                l
            } else {
                val indent = l.takeWhile { it == ' ' || it == '\t' }
                val rest = l.substring(indent.length)
                if (allCommented) indent + rest.removePrefix("//").removePrefix(" ") else "$indent// $rest"
            }
        }
    }

    fun indent(ed: EditorState) = apply(ed) { lines -> lines.map { if (it.isBlank()) it else "    $it" } }

    fun outdent(ed: EditorState) = apply(ed) { lines ->
        lines.map { l ->
            when {
                l.startsWith("\t") -> l.substring(1)
                else -> l.substring(minOf(4, l.takeWhile { it == ' ' }.length))
            }
        }
    }

    fun duplicateLine(ed: EditorState) {
        val v = ed.value
        val t = v.text
        val (start, end) = range(t, v.selection)
        val block = t.substring(start, end)
        val shift = block.length + 1
        val sel = v.selection
        ed.replaceValue(
            TextFieldValue(t.substring(0, end) + "\n" + block + t.substring(end), TextRange(sel.start + shift, sel.end + shift))
        )
    }

    /** Вставляет текст на место выделения; back — на сколько символов вернуть курсор назад. */
    fun insert(ed: EditorState, s: String, back: Int = 0) {
        val v = ed.value
        val sel = v.selection
        val t = v.text.substring(0, sel.min) + s + v.text.substring(sel.max)
        ed.replaceValue(TextFieldValue(t, TextRange(sel.min + s.length - back)))
    }
}

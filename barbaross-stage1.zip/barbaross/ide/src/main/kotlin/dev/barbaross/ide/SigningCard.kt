package dev.barbaross.ide

import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Ключ подписи release-APK: создание, резервная копия, удаление. */
@Composable
fun SigningCard(runtime: RuntimeClient, state: RuntimeState) {
    val context = LocalContext.current
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var exists by remember { mutableStateOf<Boolean?>(null) }
    var name by remember { mutableStateOf("Barbaross") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    suspend fun refresh() {
        val b = runtime.invoke("sign.status")
        exists = if (b.getString("error") == null) b.getBoolean("exists") else null
    }

    LaunchedEffect(connected) { if (connected) refresh() }

    val backup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            scope.launch {
                message = withContext(Dispatchers.IO) {
                    try {
                        val src = File(context.filesDir, "signing/barbaross.jks")
                        val out = context.contentResolver.openOutputStream(uri) ?: return@withContext "Не удалось открыть файл для записи."
                        out.use { o -> src.inputStream().use { it.copyTo(o) } }
                        "Резервная копия сохранена. Пароль храните отдельно."
                    } catch (e: Exception) {
                        "Не удалось сохранить: ${e.message}"
                    }
                }
            }
        }
    }

    Text("Подпись release-APK", style = MaterialTheme.typography.titleMedium)
    when (exists) {
        null -> Text(if (connected) "Проверяю…" else "Нет соединения с сервисом сборки.")
        true -> {
            Text("Ключ создан. Release-сборки подписываются им автоматически.")
            Text(
                "Важно: без этого ключа обновить приложение, подписанное им, не получится. " +
                    "При удалении Barbaross ключ пропадёт — сделайте резервную копию.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedButton(onClick = { backup.launch("barbaross-release.jks") }) { Text("Сохранить резервную копию ключа…") }
            OutlinedButton(enabled = !busy, onClick = { confirmDelete = true }) { Text("Удалить ключ") }
        }
        false -> {
            Text("Ключа пока нет: release-APK без подписи установить нельзя.")
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя владельца (латиницей)") }, singleLine = true)
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль ключа (от 6 символов, запомните)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
            )
            Button(enabled = connected && !busy && password.length >= 6 && name.isNotBlank(), onClick = {
                busy = true
                message = "Создаю ключ…"
                scope.launch {
                    val r = runtime.invoke("sign.create", Bundle().apply {
                        putString("name", name.trim())
                        putString("password", password)
                    })
                    message = r.getString("error") ?: "Ключ создан."
                    if (r.getString("error") == null) password = ""
                    refresh()
                    busy = false
                }
            }) { Text("Создать ключ") }
        }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Удалить ключ?") },
            text = { Text("Приложения, подписанные этим ключом, нельзя будет обновить новыми сборками. Сначала сделайте резервную копию.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch {
                        val r = runtime.invoke("sign.delete")
                        message = r.getString("error") ?: "Ключ удалён."
                        refresh()
                    }
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Отмена") } },
        )
    }
}

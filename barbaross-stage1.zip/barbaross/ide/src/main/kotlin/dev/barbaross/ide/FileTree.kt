package dev.barbaross.ide

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface FileDialog {
    data class NewFile(val dir: File) : FileDialog
    data class NewDir(val dir: File) : FileDialog
    data class Rename(val file: File) : FileDialog
    data class Delete(val files: List<File>) : FileDialog
}

private fun validName(name: String) =
    name.isNotBlank() && name != "." && name != ".." && '/' !in name && '\u0000' !in name

/**
 * Файловый менеджер проекта: дерево с иконками, путь, поиск по имени/расширению, сортировка, скрытые файлы,
 * множественный выбор (долгое нажатие), копирование/перемещение/дублирование, создание, переименование, удаление.
 * Работает строго внутри root; символические ссылки не показываются.
 */
@Composable
fun FileTree(root: File, ws: Workspace) {
    val context = LocalContext.current
    var showHidden by remember { mutableStateOf(AppPrefs.showHidden(context)) }
    var sortIdx by remember { mutableIntStateOf(AppPrefs.sortBy(context)) }
    var desc by remember { mutableStateOf(AppPrefs.sortDesc(context)) }
    val expanded = remember(root) { mutableStateOf(setOf(root.path)) }
    var version by remember { mutableIntStateOf(0) }
    var focusDir by remember(root) { mutableStateOf(root) }
    var selected by remember(root) { mutableStateOf(setOf<String>()) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    val sort = FileOps.SortBy.entries[sortIdx]

    if (!focusDir.isDirectory || !FileOps.inside(root, focusDir)) focusDir = root

    fun refresh() { version++ }
    fun expand(d: File) { expanded.value = expanded.value + d.path }
    fun toggle(d: File) {
        expanded.value = if (d.path in expanded.value) expanded.value - d.path else expanded.value + d.path
    }
    fun toggleSel(f: File) {
        selected = if (f.path in selected) selected - f.path else selected + f.path
    }
    fun selectedFiles(): List<File> = selected.map { File(it) }.filter { it.exists() && it != root }

    fun paste(into: File) {
        val items = ws.clipFiles
        if (items.isEmpty()) return
        val errors = ArrayList<String>()
        var ok = 0
        for (src in items) {
            if (!src.exists()) continue
            if (ws.clipCut) {
                val busy = ws.closeUnder(src)
                if (busy != null) { errors.add(busy); continue }
                val r = FileOps.moveInto(root, src, into)
                if (r.second != null) errors.add(r.second!!)
                if (r.first != null) ok++
            } else {
                val r = FileOps.copyInto(root, src, into)
                if (r.second != null) errors.add(r.second!!)
                if (r.first != null) ok++
            }
        }
        if (ws.clipCut && errors.isEmpty()) ws.clipFiles = emptyList()
        expand(into)
        message = (if (ok > 0) (if (ws.clipCut) "Перемещено: $ok" else "Скопировано: $ok") else "") +
            (if (errors.isNotEmpty()) (if (ok > 0) "\n" else "") + errors.joinToString("\n") else "")
        refresh()
    }

    fun duplicate(files: List<File>) {
        var ok = 0
        val errors = ArrayList<String>()
        for (f in files) {
            val parent = f.parentFile ?: continue
            val r = FileOps.copyInto(root, f, parent)
            if (r.first != null) ok++ else r.second?.let { errors.add(it) }
        }
        message = "Дублировано: $ok" + (if (errors.isNotEmpty()) "\n" + errors.joinToString("\n") else "")
        selected = emptySet()
        refresh()
    }

    @Composable
    fun Node(f: File, depth: Int) {
        var menu by remember { mutableStateOf(false) }
        val isDir = f.isDirectory
        val open = isDir && f.path in expanded.value
        val isSelected = f.path in selected
        val current = ws.active?.file == f
        val bg = when {
            isSelected -> MaterialTheme.colorScheme.primaryContainer
            f == focusDir -> MaterialTheme.colorScheme.surfaceVariant
            else -> androidx.compose.ui.graphics.Color.Transparent
        }
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 44.dp)
                .background(bg)
                .pointerInput(f) {
                    detectTapGestures(
                        onLongPress = { if (f != root) toggleSel(f) },
                        onTap = {
                            if (selected.isNotEmpty()) {
                                if (f != root) toggleSel(f)
                            } else if (isDir) {
                                toggle(f)
                                focusDir = f
                            } else {
                                ws.open(f)
                            }
                        },
                    )
                }
                .padding(start = (8 + depth * 14).dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (isDir) (if (open) "▾" else "▸") else " ", modifier = Modifier.padding(end = 4.dp))
            Text(FileOps.icon(f, open), modifier = Modifier.padding(end = 8.dp))
            Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
                Text(
                    f.name,
                    maxLines = 1,
                    color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                )
                if (!isDir) {
                    Text(
                        FileOps.humanSize(f.length()) + " · " + FileOps.humanDate(f.lastModified()),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            }
            if (isSelected) Text("✓", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 6.dp))
            Box {
                Text("⋮", modifier = Modifier.clickable { menu = true }.padding(horizontal = 14.dp, vertical = 10.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (!isDir) DropdownMenuItem(text = { Text("Открыть") }, onClick = { menu = false; ws.open(f) })
                    if (isDir) {
                        DropdownMenuItem(text = { Text("Новый файл") }, onClick = { menu = false; dialog = FileDialog.NewFile(f) })
                        DropdownMenuItem(text = { Text("Новая папка") }, onClick = { menu = false; dialog = FileDialog.NewDir(f) })
                        if (ws.clipFiles.isNotEmpty()) {
                            DropdownMenuItem(text = { Text("Вставить сюда (${ws.clipFiles.size})") }, onClick = { menu = false; paste(f) })
                        }
                    }
                    if (f != root) {
                        DropdownMenuItem(text = { Text("Копировать") }, onClick = { menu = false; ws.clipFiles = listOf(f); ws.clipCut = false })
                        DropdownMenuItem(text = { Text("Вырезать") }, onClick = { menu = false; ws.clipFiles = listOf(f); ws.clipCut = true })
                        DropdownMenuItem(text = { Text("Дублировать") }, onClick = { menu = false; duplicate(listOf(f)) })
                        DropdownMenuItem(text = { Text("Переименовать") }, onClick = { menu = false; dialog = FileDialog.Rename(f) })
                        DropdownMenuItem(text = { Text("Выбрать") }, onClick = { menu = false; toggleSel(f) })
                        DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; dialog = FileDialog.Delete(listOf(f)) })
                    }
                }
            }
        }
        if (open) {
            val list = FileOps.list(f, sort, desc, showHidden)
            if (list.isEmpty()) {
                Text("пусто", modifier = Modifier.padding(start = (34 + depth * 14).dp, bottom = 4.dp), style = MaterialTheme.typography.bodySmall)
            }
            list.forEach { Node(it, depth + 1) }
        }
    }

    // ---- путь (хлебные крошки) ----
    val crumbs = ArrayList<File>()
    run {
        var c: File? = focusDir
        while (c != null && FileOps.inside(root, c)) {
            crumbs.add(0, c)
            if (c == root) break
            c = c.parentFile
        }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        crumbs.forEachIndexed { i, c ->
            if (i > 0) Text(" › ", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                c.name,
                style = MaterialTheme.typography.titleSmall,
                color = if (c == focusDir) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.clickable { focusDir = c; expand(c) }.padding(vertical = 4.dp),
            )
        }
    }

    // ---- панель действий ----
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)) {
        TextButton(onClick = { dialog = FileDialog.NewFile(focusDir) }) { Text("＋ Файл") }
        TextButton(onClick = { dialog = FileDialog.NewDir(focusDir) }) { Text("＋ Папка") }
        TextButton(onClick = { searching = !searching; if (!searching) query = "" }) { Text(if (searching) "✕ Поиск" else "🔍 Поиск") }
        Box {
            TextButton(onClick = { sortMenu = true }) { Text("⇅ ${sort.title}${if (desc) " ↓" else " ↑"}") }
            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                FileOps.SortBy.entries.forEach { s ->
                    DropdownMenuItem(
                        text = { Text((if (s == sort) "✓ " else "") + s.title) },
                        onClick = { sortIdx = s.ordinal; AppPrefs.setSort(context, sortIdx, desc); sortMenu = false },
                    )
                }
                DropdownMenuItem(
                    text = { Text((if (desc) "✓ " else "") + "Обратный порядок") },
                    onClick = { desc = !desc; AppPrefs.setSort(context, sortIdx, desc); sortMenu = false },
                )
            }
        }
        TextButton(onClick = { showHidden = !showHidden; AppPrefs.setShowHidden(context, showHidden) }) {
            Text(if (showHidden) "👁 Скрытые: да" else "👁 Скрытые: нет")
        }
        TextButton(onClick = { refresh() }) { Text("⟳") }
        if (ws.clipFiles.isNotEmpty()) {
            TextButton(onClick = { paste(focusDir) }) {
                Text("📋 Вставить (${ws.clipFiles.size}${if (ws.clipCut) ", перенос" else ""})")
            }
        }
    }

    // ---- режим выбора ----
    if (selected.isNotEmpty()) {
        Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text("Выбрано: ${selected.size}", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                TextButton(onClick = { ws.clipFiles = selectedFiles(); ws.clipCut = false; selected = emptySet(); message = "Скопировано в буфер" }) { Text("Копировать") }
                TextButton(onClick = { ws.clipFiles = selectedFiles(); ws.clipCut = true; selected = emptySet(); message = "Вырезано в буфер" }) { Text("Вырезать") }
                TextButton(onClick = { duplicate(selectedFiles()) }) { Text("Дублировать") }
                TextButton(onClick = {
                    val all = FileOps.list(focusDir, sort, desc, showHidden).map { it.path }
                    selected = selected + all
                }) { Text("Всё в папке") }
                TextButton(onClick = { dialog = FileDialog.Delete(selectedFiles()) }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = { selected = emptySet() }) { Text("Снять") }
            }
        }
    }

    message?.let {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text("✕", modifier = Modifier.clickable { message = null }.padding(8.dp))
        }
    }

    // ---- поиск или дерево ----
    if (searching) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            label = { Text("Имя или расширение (.kt)") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp),
        )
        val results by produceState(emptyList<File>(), query, showHidden, version) {
            value = withContext(Dispatchers.IO) { FileOps.search(root, query, showHidden) }
        }
        if (query.isNotBlank() && results.isEmpty()) Text("Ничего не найдено.", modifier = Modifier.padding(12.dp))
        results.forEach { f ->
            Row(
                Modifier.fillMaxWidth().heightIn(min = 44.dp).clickable {
                    if (f.isDirectory) {
                        searching = false
                        query = ""
                        focusDir = f
                        var p: File? = f
                        while (p != null && FileOps.inside(root, p)) { expand(p); p = p.parentFile }
                    } else {
                        ws.open(f)
                    }
                }.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(FileOps.icon(f), modifier = Modifier.padding(end = 8.dp))
                Column {
                    Text(f.name, maxLines = 1)
                    Text(
                        f.parentFile?.relativeTo(root)?.path.orEmpty().ifEmpty { "/" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                }
            }
        }
    } else {
        key(version, showHidden, sortIdx, desc) { Node(root, 0) }
    }

    // ---- диалоги ----
    when (val d = dialog) {
        is FileDialog.NewFile -> NameDialog("Новый файл в «${d.dir.name}»", "", { dialog = null }) { name ->
            dialog = null
            val target = File(d.dir, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                else -> try {
                    target.createNewFile()
                    expand(d.dir)
                    ws.open(target)
                    null
                } catch (e: Exception) {
                    "Не удалось создать файл: ${e.message}"
                }
            }
            refresh()
        }
        is FileDialog.NewDir -> NameDialog("Новая папка в «${d.dir.name}»", "", { dialog = null }) { name ->
            dialog = null
            val target = File(d.dir, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                target.mkdirs() -> {
                    expand(d.dir)
                    null
                }
                else -> "Не удалось создать папку."
            }
            refresh()
        }
        is FileDialog.Rename -> NameDialog("Переименовать", d.file.name, { dialog = null }) { name ->
            dialog = null
            val target = File(d.file.parentFile, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                else -> ws.closeUnder(d.file) ?: if (d.file.renameTo(target)) null else "Не удалось переименовать."
            }
            refresh()
        }
        is FileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(if (d.files.size == 1) "Удалить?" else "Удалить ${d.files.size} элементов?") },
            text = {
                val names = d.files.take(5).joinToString("\n") { (if (it.isDirectory) "📁 " else "📄 ") + it.name }
                val more = if (d.files.size > 5) "\nи ещё ${d.files.size - 5}…" else ""
                val dirs = if (d.files.any { it.isDirectory }) "\n\nПапки будут удалены вместе со всем содержимым." else ""
                Text("$names$more$dirs\n\nЭто действие необратимо.")
            },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    val errors = ArrayList<String>()
                    var ok = 0
                    for (f in d.files) {
                        if (f == root || !FileOps.inside(root, f)) continue
                        val busy = ws.closeUnder(f)
                        if (busy != null) { errors.add(busy); continue }
                        if (Fs.deleteTree(f)) ok++ else errors.add("Не удалось удалить «${f.name}».")
                    }
                    ws.clipFiles = ws.clipFiles.filter { it.exists() }
                    selected = emptySet()
                    message = "Удалено: $ok" + (if (errors.isNotEmpty()) "\n" + errors.joinToString("\n") else "")
                    refresh()
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Отмена") } },
        )
        null -> {}
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Имя") }) },
        confirmButton = { TextButton(enabled = validName(name.trim()), onClick = { onOk(name.trim()) }) { Text("ОК") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

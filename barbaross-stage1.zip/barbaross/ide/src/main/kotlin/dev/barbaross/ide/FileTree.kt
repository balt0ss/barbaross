package dev.barbaross.ide

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

private sealed interface FileDialog {
    data class NewFile(val dir: File) : FileDialog
    data class NewDir(val dir: File) : FileDialog
    data class Rename(val file: File) : FileDialog
    data class Delete(val file: File) : FileDialog
}

private fun validName(name: String) =
    name.isNotBlank() && name != "." && name != ".." && '/' !in name && '\u0000' !in name

private val HIDDEN = setOf(".git", ".gradle", ".idea")

private fun children(dir: File): List<File> =
    dir.listFiles { f -> !Fs.isLink(f) && !(f.isDirectory && f.name in HIDDEN) }
        ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()

/** Раскрывающееся дерево файлов проекта (как в VS Code). Работает строго внутри root. */
@Composable
fun FileTree(root: File, ws: Workspace) {
    val expanded = remember(root) { mutableStateOf(setOf(root.path)) }
    var version by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun toggle(d: File) {
        expanded.value = if (d.path in expanded.value) expanded.value - d.path else expanded.value + d.path
    }

    @Composable
    fun Node(f: File, depth: Int) {
        var menu by remember { mutableStateOf(false) }
        val isDir = f.isDirectory
        val open = isDir && f.path in expanded.value
        val current = ws.active?.file == f
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 40.dp)
                .clickable { if (isDir) toggle(f) else ws.open(f) }
                .padding(start = (8 + depth * 14).dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (isDir) (if (open) "▾ 📂 " else "▸ 📁 ") else "     📄 ")
            Text(
                f.name,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Box {
                Text("⋮", modifier = Modifier.clickable { menu = true }.padding(horizontal = 12.dp, vertical = 8.dp))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (isDir) {
                        DropdownMenuItem(text = { Text("Новый файл") }, onClick = { menu = false; dialog = FileDialog.NewFile(f) })
                        DropdownMenuItem(text = { Text("Новая папка") }, onClick = { menu = false; dialog = FileDialog.NewDir(f) })
                    }
                    if (f != root) {
                        DropdownMenuItem(text = { Text("Переименовать") }, onClick = { menu = false; dialog = FileDialog.Rename(f) })
                        DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; dialog = FileDialog.Delete(f) })
                    }
                }
            }
        }
        if (open) {
            val list = children(f)
            if (list.isEmpty()) Text("пусто", modifier = Modifier.padding(start = (30 + depth * 14).dp), style = MaterialTheme.typography.bodySmall)
            list.forEach { Node(it, depth + 1) }
        }
    }

    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(8.dp)) }
    key(version) { Node(root, 0) }

    when (val d = dialog) {
        is FileDialog.NewFile -> NameDialog("Новый файл", "", { dialog = null }) { name ->
            dialog = null
            val target = File(d.dir, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                else -> try {
                    target.createNewFile()
                    expanded.value = expanded.value + d.dir.path
                    ws.open(target)
                    null
                } catch (e: Exception) {
                    "Не удалось создать файл: ${e.message}"
                }
            }
            version++
        }
        is FileDialog.NewDir -> NameDialog("Новая папка", "", { dialog = null }) { name ->
            dialog = null
            val target = File(d.dir, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                target.mkdirs() -> {
                    expanded.value = expanded.value + d.dir.path
                    null
                }
                else -> "Не удалось создать папку."
            }
            version++
        }
        is FileDialog.Rename -> NameDialog("Переименовать", d.file.name, { dialog = null }) { name ->
            dialog = null
            val target = File(d.file.parentFile, name)
            message = when {
                target.exists() -> "«$name» уже существует."
                else -> ws.closeUnder(d.file) ?: if (d.file.renameTo(target)) null else "Не удалось переименовать."
            }
            version++
        }
        is FileDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Удалить?") },
            text = { Text("«${d.file.name}»" + (if (d.file.isDirectory) " и всё внутри" else "") + " будет удалено безвозвратно.") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    message = ws.closeUnder(d.file) ?: if (Fs.deleteTree(d.file)) null else "Не удалось удалить."
                    version++
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Отмена") } },
        )
        null -> {}
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Имя") }) },
        confirmButton = { TextButton(enabled = validName(name.trim()), onClick = { onOk(name.trim()) }) { Text("ОК") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

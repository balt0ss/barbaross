package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Установка инструментов (JDK, Gradle, Android SDK) с явным согласием с лицензией Android SDK. */
@Composable
fun ToolchainCard(runtime: RuntimeClient, state: RuntimeState) {
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var ready by remember { mutableStateOf(false) }
    var showLicense by remember { mutableStateOf(false) }
    var installing by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun refresh() {
        ready = runtime.invoke("toolchain.status").getBoolean("ready")
    }

    suspend fun follow() {
        installing = true
        while (true) {
            val b = runtime.invoke("toolchain.install.status")
            log = b.getString("log").orEmpty()
            if (!b.getBoolean("running")) {
                message = if (b.getBoolean("success")) "Готово: инструменты установлены." else "Установка не завершена, см. лог."
                break
            }
            delay(1000)
        }
        installing = false
        refresh()
    }

    LaunchedEffect(connected) {
        if (connected) {
            refresh()
            if (runtime.invoke("toolchain.install.status").getBoolean("running")) follow()
        }
    }

    Text("Инструменты сборки", style = MaterialTheme.typography.titleMedium)
    Text(
        when {
            !connected -> "Нет соединения с сервисом сборки."
            ready -> "Установлены: JDK 17, Gradle, Android SDK. Можно собирать проекты."
            else -> "Не установлены. Для сборки нужны JDK, Gradle и Android SDK (несколько сотен МБ, потребуется интернет)."
        }
    )
    if (!ready || installing) {
        Button(enabled = connected && !installing, onClick = { showLicense = true }) {
            Text(if (installing) "Идёт установка…" else "Установить инструменты")
        }
    }
    if (installing) {
        OutlinedButton(onClick = { scope.launch { runtime.invoke("toolchain.install.cancel") } }) { Text("Отменить установку") }
    }
    message?.let { Text(it) }
    if (log.isNotEmpty()) {
        SelectionContainer {
            Text(log.lines().takeLast(40).joinToString("\n"), style = MaterialTheme.typography.bodySmall)
        }
    }

    GitInstallSection(runtime, state)

    if (showLicense) {
        AlertDialog(
            onDismissRequest = { showLicense = false },
            title = { Text("Лицензия Android SDK") },
            text = {
                Text(
                    "Будут скачаны компоненты Android SDK (Google), JDK и сборочные инструменты. " +
                        "Нажимая «Принимаю», вы соглашаетесь с Android Software Development Kit License Agreement: " +
                        "https://developer.android.com/studio/terms\n\n" +
                        "Нужно не менее 3 ГБ свободного места и интернет."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showLicense = false
                    message = null
                    log = ""
                    scope.launch {
                        val r = runtime.invoke("toolchain.install.start", Bundle().apply { putBoolean("licenseAccepted", true) })
                        val err = r.getString("error")
                        if (err != null) message = err else follow()
                    }
                }) { Text("Принимаю") }
            },
            dismissButton = { TextButton(onClick = { showLicense = false }) { Text("Отмена") } },
        )
    }
}

package dev.barbaross.ide.projects

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProjectsScreen(repository: ProjectRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var project by remember { mutableStateOf<ProjectRepository.Project?>(null) }
    var recent by remember { mutableStateOf(repository.recentProjects()) }
    val path = remember { mutableStateListOf<Uri>() }
    var entries by remember { mutableStateOf<List<ProjectRepository.Entry>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    var createDialog by remember { mutableStateOf(false) }
    var createName by remember { mutableStateOf("") }
    var createDirectory by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<ProjectRepository.Entry?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<ProjectRepository.Entry?>(null) }
    var editing by remember { mutableStateOf<ProjectRepository.Entry?>(null) }
    var editText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun refresh() {
        val current = project ?: return
        val directory = path.lastOrNull() ?: current.uri
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { repository.list(current, directory) } }
                .onSuccess { entries = it }
                .onFailure { message = it.message ?: "Ошибка чтения папки" }
        }
    }

    fun acceptTree(uri: Uri?, create: Boolean) {
        if (uri == null) return
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
        scope.launch {
            busy = true
            runCatching {
                withContext(Dispatchers.IO) {
                    if (create) repository.createProject(uri, createName) else repository.openProject(uri)
                }
            }.onSuccess {
                project = it
                path.clear()
                recent = repository.recentProjects()
                entries = withContext(Dispatchers.IO) { repository.list(it) }
                createName = ""
            }.onFailure { message = it.message ?: "Не удалось открыть проект" }
            busy = false
        }
    }

    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { acceptTree(it, false) }
    val createPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { acceptTree(it, true) }

    LaunchedEffect(project?.uri) {
        project?.let { current ->
            runCatching { withContext(Dispatchers.IO) { repository.list(current) } }
                .onSuccess { entries = it }
                .onFailure { message = it.message ?: "Проект недоступен" }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        if (project == null) {
            Text("Рабочие пространства", style = MaterialTheme.typography.titleMedium)
            Text("Проекты хранятся в выбранных папках устройства. Доступ к ним сохраняется после перезапуска.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !busy, onClick = { openPicker.launch(null) }) { Text("Открыть папку") }
                OutlinedButton(enabled = !busy, onClick = { createDialog = true }) { Text("Новый проект") }
            }
            if (recent.isNotEmpty()) {
                Text("Недавние проекты", style = MaterialTheme.typography.titleSmall)
                recent.forEach { item ->
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !busy,
                        onClick = {
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { repository.restoreProject(item) } }
                                    .onSuccess { opened ->
                                        project = opened
                                        path.clear()
                                        entries = withContext(Dispatchers.IO) { repository.list(opened) }
                                    }
                                    .onFailure { message = "Нет доступа к проекту. Откройте папку заново: ${it.message}" }
                            }
                        },
                    ) { Text(item.name) }
                }
            }
        } else {
            val current = project!!
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { project = null; path.clear(); recent = repository.recentProjects() }) { Text("← Проекты") }
                Text(current.name, style = MaterialTheme.typography.titleMedium)
            }
            val depth = path.size
            Text(if (depth == 0) current.name else "${current.name} / ${depth} уровень")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (path.isNotEmpty()) path.removeAt(path.lastIndex)
                    refresh()
                }, enabled = path.isNotEmpty()) { Text("Назад") }
                Button(onClick = { createDirectory = true; createDialog = true }) { Text("Новая папка") }
                OutlinedButton(onClick = { createDirectory = false; createDialog = true }) { Text("Новый файл") }
            }
            if (entries.isEmpty()) Text("Папка пуста")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f, fill = false)) {
                items(entries, key = { it.uri.toString() }) { entry ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable {
                            if (entry.directory) {
                                path.add(entry.uri)
                                refresh()
                            } else {
                                scope.launch {
                                    runCatching { withContext(Dispatchers.IO) { repository.readText(current, entry.uri) } }
                                        .onSuccess { editText = it; editing = entry }
                                        .onFailure { message = it.message ?: "Не удалось открыть файл" }
                                }
                            }
                        }.padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text((if (entry.directory) "📁 " else "📄 ") + entry.name)
                            if (!entry.directory) Text("${entry.size} байт", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { renameTarget = entry; renameValue = entry.name }) { Text("Имя") }
                        TextButton(onClick = {
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { repository.copyToRoot(current, entry.uri) } }
                                    .onSuccess { if (path.isEmpty()) refresh() else message = "Копия создана в корне проекта" }
                                    .onFailure { message = it.message ?: "Ошибка копирования" }
                            }
                        }) { Text("Копия") }
                        TextButton(onClick = {
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { repository.moveToRoot(current, entry.uri) } }
                                    .onSuccess { refresh() }
                                    .onFailure { message = it.message ?: "Ошибка перемещения" }
                            }
                        }) { Text("В корень") }
                        TextButton(onClick = { deleteTarget = entry }) { Text("Удалить") }
                    }
                }
            }
        }
        message?.let {
            Text(it, color = MaterialTheme.colorScheme.error)
            TextButton(onClick = { message = null }) { Text("Закрыть") }
        }
    }

    if (createDialog) AlertDialog(
        onDismissRequest = { createDialog = false },
        title = { Text(if (project == null) "Новый проект" else if (createDirectory) "Новая папка" else "Новый файл") },
        text = {
            OutlinedTextField(value = createName, onValueChange = { createName = it }, label = { Text("Имя") }, singleLine = true)
        },
        confirmButton = {
            TextButton(onClick = {
                createDialog = false
                if (project == null) createPicker.launch(null)
                else {
                    val current = project!!
                    val parent = path.lastOrNull() ?: current.uri
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { repository.create(current, parent, createName, createDirectory) } }
                            .onSuccess { createName = ""; refresh() }
                            .onFailure { message = it.message ?: "Не удалось создать элемент" }
                    }
                }
            }) { Text("Продолжить") }
        },
        dismissButton = { TextButton(onClick = { createDialog = false }) { Text("Отмена") } },
    )

    renameTarget?.let { target -> AlertDialog(
        onDismissRequest = { renameTarget = null },
        title = { Text("Переименовать") },
        text = { OutlinedTextField(value = renameValue, onValueChange = { renameValue = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = {
            val current = project ?: return@TextButton
            renameTarget = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { repository.rename(current, target.uri, renameValue) } }
                    .onSuccess { refresh() }.onFailure { message = it.message ?: "Ошибка переименования" }
            }
        }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Отмена") } },
    ) }

    deleteTarget?.let { target -> AlertDialog(
        onDismissRequest = { deleteTarget = null },
        title = { Text("Удалить ${target.name}?") },
        text = { Text("Удаление необратимо. Для папок также будет удалено содержимое, если это поддерживает файловый провайдер.") },
        confirmButton = { TextButton(onClick = {
            val current = project ?: return@TextButton
            deleteTarget = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { repository.delete(current, target.uri) } }
                    .onSuccess { refresh() }.onFailure { message = it.message ?: "Ошибка удаления" }
            }
        }) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } },
    ) }

    editing?.let { target -> AlertDialog(
        onDismissRequest = { editing = null },
        title = { Text(target.name) },
        text = {
            OutlinedTextField(
                value = editText,
                onValueChange = { editText = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 8,
                maxLines = 16,
            )
        },
        confirmButton = { TextButton(onClick = {
            val current = project ?: return@TextButton
            editing = null
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { repository.writeText(current, target.uri, editText) } }
                    .onFailure { message = it.message ?: "Ошибка сохранения" }
            }
        }) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = { editing = null }) { Text("Закрыть") } },
    ) }
}

package dev.barbaross.ide

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

/** Выбор темы: как в системе / светлая / тёмная. */
@Composable
fun AppearanceCard(mode: Int, onChange: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("Системная", "Светлая", "Тёмная").forEachIndexed { i, title ->
            if (mode == i) Button(onClick = { onChange(i) }) { Text(title) }
            else OutlinedButton(onClick = { onChange(i) }) { Text(title) }
        }
    }
}

package dev.barbaross.ide

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState

/**
 * Каркас IDE в стиле VS Code для телефона: сверху тонкая панель, слева полоса значков (проводник, поиск, Git,
 * расширения, настройки), в центре редактор на весь экран, снизу выдвижная панель (сборка, терминал, проблемы).
 */
@Composable
fun IdeShell(
    runtime: RuntimeClient,
    state: RuntimeState,
    ws: Workspace,
    settings: @Composable () -> Unit,
) {
    val context = LocalContext.current
    var showExit by remember { mutableStateOf(false) }

    // Порядок важен: последний зарегистрированный обработчик «Назад» срабатывает первым.
    BackHandler(enabled = ws.anyDirty()) { showExit = true }
    BackHandler(enabled = ws.panelOpen) { ws.panelOpen = false }
    BackHandler(enabled = ws.sidebar != null) { ws.sidebar = null }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            TopBar(ws)
            Row(Modifier.weight(1f).fillMaxWidth()) {
                ActivityBar(ws)
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f).fillMaxWidth()) { EditorArea(ws) }
                        if (ws.panelOpen) BottomPanel(runtime, state, ws)
                    }
                    ws.sidebar?.let { sb -> SidePanel(ws, sb) { SidebarContent(runtime, state, ws, sb, settings) } }
                }
            }
        }
    }

    if (showExit) {
        AlertDialog(
            onDismissRequest = { showExit = false },
            title = { Text("Несохранённые файлы") },
            text = { Text("В редакторе есть изменения, которые ещё не сохранены.") },
            confirmButton = {
                TextButton(onClick = {
                    showExit = false
                    if (ws.saveAll()) context.findActivity()?.finish()
                }) { Text("Сохранить и выйти") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showExit = false; context.findActivity()?.finish() }) { Text("Выйти без сохранения") }
                    TextButton(onClick = { showExit = false }) { Text("Отмена") }
                }
            },
        )
    }
}

@Composable
private fun TopBar(ws: Workspace) {
    Row(
        Modifier.fillMaxWidth().height(46.dp).background(MaterialTheme.colorScheme.surface).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "☰  " + (ws.selectedProject?.name ?: "Выберите проект"),
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            modifier = Modifier
                .weight(1f)
                .clickable { ws.sidebar = if (ws.sidebar == Sidebar.Files) null else Sidebar.Files }
                .padding(horizontal = 12.dp, vertical = 12.dp),
        )
        Button(
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF3F8F4A), contentColor = Color.White),
            onClick = {
                if (ws.selectedProject == null) {
                    ws.showProjects = true
                    ws.sidebar = Sidebar.Files
                } else if (ws.saveAll()) {
                    ws.runBuild()
                }
            },
        ) { Text("▶ Собрать") }
        TextButton(onClick = { ws.panelOpen = !ws.panelOpen }) { Text(if (ws.panelOpen) "▼" else "▲", style = MaterialTheme.typography.titleMedium) }
    }
}

@Composable
private fun ActivityBar(ws: Workspace) {
    val accent = MaterialTheme.colorScheme.primary
    Column(
        Modifier.width(52.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surface),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Sidebar.entries.forEach { s ->
            val selected = ws.sidebar == s
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clickable { ws.sidebar = if (selected) null else s },
                contentAlignment = Alignment.Center,
            ) {
                if (selected) Box(Modifier.align(Alignment.CenterStart).width(3.dp).height(32.dp).background(accent))
                Text(s.icon, style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
private fun EditorArea(ws: Workspace) {
    val session = ws.active
    if (session == null) {
        Welcome(ws)
        return
    }
    Column(Modifier.fillMaxSize()) {
        EditorTabs(ws)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            key(session) {
                EditorScreen(
                    session,
                    onSaveAndBuild = { ws.runBuild() },
                    onShowProblems = { ws.panelTab = 2; ws.panelOpen = true },
                )
            }
        }
    }
}

@Composable
private fun Welcome(ws: Workspace) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Barbaross IDE", style = MaterialTheme.typography.headlineSmall)
        if (ws.selectedProject == null) {
            Text("Создайте проект, клонируйте репозиторий или импортируйте zip.")
            Button(onClick = { ws.showProjects = true; ws.sidebar = Sidebar.Files }) { Text("Проекты") }
        } else {
            Text("Откройте файл из проводника — файлы проекта «${ws.selectedProject?.name}».")
            Button(onClick = { ws.showProjects = false; ws.sidebar = Sidebar.Files }) { Text("Открыть проводник") }
        }
    }
}

@Composable
private fun BottomPanel(runtime: RuntimeClient, state: RuntimeState, ws: Workspace) {
    val problemCount = ws.sessions.sumOf { it.problems.size }
    Column(Modifier.fillMaxWidth().fillMaxHeight(0.45f).background(MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                listOf("Сборка", "Терминал", if (problemCount > 0) "Проблемы ($problemCount)" else "Проблемы").forEachIndexed { i, title ->
                    val on = ws.panelTab == i
                    Text(
                        title,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { ws.panelTab = i }.padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }
            }
            Text("✕", modifier = Modifier.clickable { ws.panelOpen = false }.padding(horizontal = 16.dp, vertical = 10.dp))
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            when (ws.panelTab) {
                0 -> BuildTab(runtime, state, ws)
                1 -> TerminalScreen(runtime, state, ws)
                else -> ProblemsTab(ws)
            }
        }
    }
}

@Composable
private fun ProblemsTab(ws: Workspace) {
    val withProblems = ws.sessions.filter { it.problems.isNotEmpty() }
    if (withProblems.isEmpty()) {
        Text("Проблем в открытых файлах нет.")
        return
    }
    withProblems.forEach { s ->
        Text(s.file.name, style = MaterialTheme.typography.titleSmall)
        s.problems.take(20).forEach { p ->
            TextButton(onClick = { ws.open(s.file, p.line) }) {
                Text("Строка ${p.line}: ${p.message}", color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun SidePanel(ws: Workspace, sb: Sidebar, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.4f)).clickable { ws.sidebar = null })
        Surface(Modifier.fillMaxHeight().fillMaxWidth(0.88f), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(sb.title.uppercase(), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f).padding(14.dp))
                    Text("✕", modifier = Modifier.clickable { ws.sidebar = null }.padding(14.dp))
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) { content() }
            }
        }
    }
}

@Composable
private fun SidebarContent(runtime: RuntimeClient, state: RuntimeState, ws: Workspace, sb: Sidebar, settings: @Composable () -> Unit) {
    val project = ws.selectedProject
    val pad = Modifier.fillMaxWidth().padding(10.dp)
    when (sb) {
        Sidebar.Files -> {
            if (project == null || ws.showProjects) {
                Column(pad, verticalArrangement = Arrangement.spacedBy(8.dp)) { ProjectsPanel(runtime, state, ws) }
            } else {
                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(project.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1)
                    TextButton(onClick = { ws.showProjects = true }) { Text("Проекты") }
                }
                FileTree(project, ws)
            }
        }
        Sidebar.Search -> Column(pad, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (project == null) Text("Сначала выберите проект.") else SearchPanel(project) { f, l -> ws.open(f, l) }
        }
        Sidebar.Git -> Column(pad, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (project == null) Text("Сначала выберите проект.") else GitPanel(runtime, state, project)
        }
        Sidebar.Extensions -> Column(pad, verticalArrangement = Arrangement.spacedBy(8.dp)) { ExtensionsScreen(ws) }
        Sidebar.Settings -> Column(pad, verticalArrangement = Arrangement.spacedBy(8.dp)) { settings() }
    }
}

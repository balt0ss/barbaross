package dev.barbaross.ide

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/** Лёгкие подсказки и проверка кода без компилятора: автодополнение слов/шаблонов и баланс скобок/строк/комментариев. */
internal object CodeAssist {
    val CODE_EXT = setOf("kt", "kts", "java", "gradle")

    class Suggestion(val label: String, val insert: String)
    class Problem(val line: Int, val message: String)

    private val KEYWORDS = listOf(
        "package", "import", "class", "interface", "object", "fun", "val", "var", "return", "when", "else", "while",
        "for", "break", "continue", "try", "catch", "finally", "throw", "null", "true", "false", "this", "super",
        "override", "private", "public", "protected", "internal", "open", "abstract", "sealed", "data class",
        "enum class", "companion object", "suspend", "inline", "lateinit", "const", "typealias",
    )

    /** "|" — место курсора после вставки. */
    private val SNIPPETS = listOf(
        "fun" to "fun |() {\n}",
        "if" to "if (|) {\n}",
        "for" to "for (i in |) {\n}",
        "when" to "when (|) {\n    else -> {}\n}",
        "println" to "println(|)",
        "@Composable" to "@Composable\nfun |() {\n}",
        "Text" to "Text(\"|\")",
        "Button" to "Button(onClick = { | }) {\n    Text(\"\")\n}",
        "Column" to "Column {\n    |\n}",
        "Row" to "Row {\n    |\n}",
        "Box" to "Box {\n    |\n}",
        "LazyColumn" to "LazyColumn {\n    items(|) { item ->\n    }\n}",
        "Spacer" to "Spacer(Modifier.height(|.dp))",
        "Modifier" to "Modifier",
        "remember" to "remember { mutableStateOf(|) }",
        "mutableStateOf" to "mutableStateOf(|)",
        "LaunchedEffect" to "LaunchedEffect(|) {\n}",
        "MaterialTheme" to "MaterialTheme",
        "OutlinedTextField" to "OutlinedTextField(value = |, onValueChange = { }, label = { Text(\"\") })",
    )

    private fun isWordChar(c: Char) = c.isLetterOrDigit() || c == '_'

    private val WORD_RE = Regex("[A-Za-z_][A-Za-z0-9_]{2,}")

    fun suggest(text: String, sel: TextRange, extra: List<Pair<String, String>> = emptyList()): List<Suggestion> {
        if (!sel.collapsed || text.length > 200_000) return emptyList()
        val pos = sel.start.coerceIn(0, text.length)
        var start = pos
        while (start > 0 && isWordChar(text[start - 1])) start--
        val prefix = text.substring(start, pos)
        if (prefix.length < 2 || prefix[0].isDigit()) return emptyList()
        val member = start > 0 && text[start - 1] == '.'
        val out = ArrayList<Suggestion>()
        val seen = HashSet<String>()
        fun add(label: String, insert: String) {
            if (label == prefix || out.size >= 8 || !seen.add(label)) return
            out.add(Suggestion(label, insert))
        }
        if (!member) {
            SNIPPETS.filter { it.first.startsWith(prefix, ignoreCase = true) }.forEach { add(it.first, it.second) }
            extra.filter { it.first.startsWith(prefix, ignoreCase = true) }.forEach { add(it.first, it.second) }
            KEYWORDS.filter { it.startsWith(prefix) }.forEach { add(it, it) }
        }
        // Слова из текущего файла, кроме слова под курсором.
        val words = LinkedHashSet<String>()
        for (m in WORD_RE.findAll(text)) {
            if (m.range.first == start) continue
            if (m.value.startsWith(prefix) && m.value != prefix) words.add(m.value)
        }
        words.sorted().forEach { add(it, it) }
        return out
    }

    /** Заменяет слово под курсором на подсказку; для шаблонов расставляет отступы и курсор. */
    fun apply(v: TextFieldValue, s: Suggestion): TextFieldValue {
        val t = v.text
        val pos = v.selection.start.coerceIn(0, t.length)
        var start = pos
        while (start > 0 && isWordChar(t[start - 1])) start--
        val lineStart = t.lastIndexOf('\n', start - 1) + 1
        val indent = t.substring(lineStart, start).takeWhile { it == ' ' || it == '\t' }
        val body = s.insert.replace("\n", "\n" + indent)
        val marker = body.indexOf('|')
        val finalText = if (marker >= 0) body.removeRange(marker, marker + 1) else body
        val cursor = start + (if (marker >= 0) marker else finalText.length)
        return TextFieldValue(t.substring(0, start) + finalText + t.substring(pos), TextRange(cursor))
    }

    // ---------- проверка ----------

    fun check(src: String): List<Problem> {
        val out = ArrayList<Problem>()
        if (src.length > 500_000) return out
        val stack = ArrayList<Pair<Char, Int>>()
        val n = src.length
        var i = 0
        var line = 1

        fun add(l: Int, m: String) {
            if (out.size < 20) out.add(Problem(l, m))
        }

        while (i < n) {
            val c = src[i]
            if (c == '\n') {
                line++
                i++
            } else if (c == '/' && i + 1 < n && src[i + 1] == '/') {
                while (i < n && src[i] != '\n') i++
            } else if (c == '/' && i + 1 < n && src[i + 1] == '*') {
                val end = src.indexOf("*/", i + 2)
                if (end < 0) {
                    add(line, "Не закрыт комментарий /*")
                    i = n
                } else {
                    for (k in i until end) if (src[k] == '\n') line++
                    i = end + 2
                }
            } else if (c == '"') {
                if (src.startsWith("\"\"\"", i)) {
                    val end = src.indexOf("\"\"\"", i + 3)
                    if (end < 0) {
                        add(line, "Не закрыта строка \"\"\"")
                        i = n
                    } else {
                        for (k in i until end) if (src[k] == '\n') line++
                        i = end + 3
                    }
                } else {
                    var j = i + 1
                    var closed = false
                    while (j < n) {
                        val d = src[j]
                        if (d == '\\' && j + 1 < n && src[j + 1] != '\n') {
                            j += 2
                            continue
                        }
                        if (d == '\n') break
                        if (d == '"') {
                            closed = true
                            break
                        }
                        if (d == '$' && j + 1 < n && src[j + 1] == '{') {
                            var depth = 1
                            j += 2
                            while (j < n && depth > 0 && src[j] != '\n') {
                                if (src[j] == '{') depth++ else if (src[j] == '}') depth--
                                j++
                            }
                            continue
                        }
                        j++
                    }
                    if (!closed) add(line, "Не закрыта строка \"")
                    i = if (closed) j + 1 else j
                }
            } else if (c == '\'') {
                var j = i + 1
                while (j < n && src[j] != '\n') {
                    if (src[j] == '\\' && j + 1 < n && src[j + 1] != '\n') {
                        j += 2
                        continue
                    }
                    if (src[j] == '\'') break
                    j++
                }
                val closed = j < n && src[j] == '\''
                if (!closed) add(line, "Не закрыта кавычка '")
                i = if (closed) j + 1 else j
            } else {
                when (c) {
                    '(', '[', '{' -> stack.add(c to line)
                    ')', ']', '}' -> {
                        val open = when (c) {
                            ')' -> '('
                            ']' -> '['
                            else -> '{'
                        }
                        if (stack.isEmpty()) {
                            add(line, "Лишняя «$c»")
                        } else {
                            val top = stack.removeAt(stack.size - 1)
                            if (top.first != open) add(line, "«$c» не подходит к «${top.first}» из строки ${top.second}")
                        }
                    }
                }
                i++
            }
        }
        for ((ch, l) in stack) add(l, "Не закрыта «$ch»")
        return out
    }
}

package dev.barbaross.ide

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Настройки Git. Токен хранится зашифрованным (AES-GCM, ключ в Android Keystore) и никуда не экспортируется. */
class GitSettings(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("git_settings", Context.MODE_PRIVATE)

    var name: String
        get() = prefs.getString("name", "").orEmpty()
        set(v) { prefs.edit().putString("name", v).apply() }

    var email: String
        get() = prefs.getString("email", "").orEmpty()
        set(v) { prefs.edit().putString("email", v).apply() }

    var user: String
        get() = prefs.getString("user", "").orEmpty()
        set(v) { prefs.edit().putString("user", v).apply() }

    fun hasToken(): Boolean = prefs.contains("token")

    fun token(): String? {
        val stored = prefs.getString("token", null) ?: return null
        return try {
            val raw = Base64.decode(stored, Base64.NO_WRAP)
            if (raw.size < 13) return null
            val iv = raw.copyOfRange(0, 12)
            val c = Cipher.getInstance(TRANSFORM)
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    fun saveToken(token: String?) {
        if (token.isNullOrEmpty()) {
            prefs.edit().remove("token").apply()
            return
        }
        val c = Cipher.getInstance(TRANSFORM)
        c.init(Cipher.ENCRYPT_MODE, key())
        val enc = c.doFinal(token.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("token", Base64.encodeToString(c.iv + enc, Base64.NO_WRAP)).apply()
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    private companion object {
        const val ALIAS = "barbaross_git_token"
        const val TRANSFORM = "AES/GCM/NoPadding"
    }
}

package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Запуск git в службе сборки. Возвращает текст для показа пользователю. */
suspend fun runGit(
    runtime: RuntimeClient,
    settings: GitSettings,
    dir: File,
    argv: List<String>,
    network: Boolean = false,
): String {
    val args = Bundle().apply {
        putString("dir", dir.absolutePath)
        putStringArray("argv", argv.toTypedArray())
        putBoolean("network", network)
        putString("name", settings.name)
        putString("email", settings.email)
        putString("user", settings.user)
        if (network) putString("token", settings.token())
    }
    val r = runtime.invoke("git.run", args)
    r.getString("error")?.let { return it }
    val out = r.getString("output").orEmpty().trim()
    val code = r.getInt("code")
    return if (code == 0) out.ifEmpty { "Готово." } else "Код $code\n$out"
}

/** Установка Git (показывается в Настройках, когда инструменты сборки готовы). */
@Composable
fun GitInstallSection(runtime: RuntimeClient, state: RuntimeState) {
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var toolchainReady by remember { mutableStateOf(false) }
    var installed by remember { mutableStateOf(false) }
    var installing by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }

    suspend fun refresh() {
        toolchainReady = runtime.invoke("toolchain.status").getBoolean("ready")
        installed = runtime.invoke("git.status").getBoolean("installed")
    }

    suspend fun follow() {
        installing = true
        while (true) {
            val b = runtime.invoke("git.install.status")
            log = b.getString("log").orEmpty()
            if (!b.getBoolean("running")) break
            delay(1000)
        }
        installing = false
        refresh()
    }

    LaunchedEffect(connected) {
        if (connected) {
            refresh()
            if (runtime.invoke("git.install.status").getBoolean("running")) follow()
        }
    }

    Text("Git", style = MaterialTheme.typography.titleMedium)
    when {
        !connected -> Text("Нет соединения с сервисом сборки.")
        !toolchainReady -> Text("Сначала установите инструменты сборки.")
        installed && !installing -> Text("Git установлен.")
        else -> {
            Text("Git не установлен (небольшой пакет, нужен интернет).")
            Button(enabled = !installing, onClick = {
                log = ""
                scope.launch {
                    val r = runtime.invoke("git.install.start")
                    val err = r.getString("error")
                    if (err != null) log = err else follow()
                }
            }) { Text(if (installing) "Идёт установка…" else "Установить Git") }
        }
    }
    if (installing) {
        OutlinedButton(onClick = { scope.launch { runtime.invoke("git.install.cancel") } }) { Text("Отменить") }
    }
    if (log.isNotEmpty()) {
        SelectionContainer {
            Text(log.lines().takeLast(25).joinToString("\n"), style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Вкладка Git для выбранного проекта. */
@Composable
fun GitPanel(runtime: RuntimeClient, state: RuntimeState, project: File) {
    val context = LocalContext.current
    val settings = remember { GitSettings(context) }
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf<Boolean?>(null) }
    var busy by remember { mutableStateOf(false) }
    var output by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(settings.name) }
    var email by remember { mutableStateOf(settings.email) }
    var user by remember { mutableStateOf(settings.user) }
    var token by remember { mutableStateOf("") }
    var tokenSaved by remember { mutableStateOf(settings.hasToken()) }
    var message by remember { mutableStateOf("") }
    var remoteUrl by remember { mutableStateOf("") }

    LaunchedEffect(state) {
        if (state is RuntimeState.Connected) installed = runtime.invoke("git.status").getBoolean("installed")
    }

    fun git(vararg argv: String, network: Boolean = false) {
        if (busy) return
        busy = true
        output = if (network) "Выполняю (может занять время)…" else "…"
        scope.launch {
            output = runGit(runtime, settings, project, argv.toList(), network)
            busy = false
        }
    }

    if (installed != true) {
        Text(if (installed == null) "Проверяю Git…" else "Git не установлен. Установите его: Настройки → Git.")
        return
    }
    val isRepo = File(project, ".git").exists()

    Text("Автор коммитов и доступ", style = MaterialTheme.typography.titleMedium)
    OutlinedTextField(value = name, onValueChange = { name = it; settings.name = it }, label = { Text("Имя") }, singleLine = true)
    OutlinedTextField(value = email, onValueChange = { email = it; settings.email = it }, label = { Text("Email") }, singleLine = true)
    OutlinedTextField(value = user, onValueChange = { user = it; settings.user = it }, label = { Text("Логин (для токена)") }, singleLine = true)
    OutlinedTextField(
        value = token,
        onValueChange = { token = it },
        label = { Text(if (tokenSaved) "Токен сохранён (введите новый, чтобы заменить)" else "Токен доступа (GitHub PAT)") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = token.isNotEmpty(), onClick = {
            try {
                settings.saveToken(token)
                tokenSaved = true
                token = ""
                output = "Токен сохранён в защищённом хранилище."
            } catch (e: Exception) {
                output = "Не удалось сохранить токен: ${e.message}"
            }
        }) { Text("Сохранить токен") }
        OutlinedButton(enabled = tokenSaved, onClick = {
            settings.saveToken(null)
            tokenSaved = false
            output = "Токен удалён."
        }) { Text("Удалить токен") }
    }

    Text("Репозиторий", style = MaterialTheme.typography.titleMedium)
    if (!isRepo) {
        Text("Это не Git-репозиторий.")
        Button(enabled = !busy, onClick = { git("init") }) { Text("git init") }
    } else {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = androidx.compose.ui.Modifier.horizontalScroll(rememberScrollState())) {
            OutlinedButton(enabled = !busy, onClick = { git("status", "-sb") }) { Text("Статус") }
            OutlinedButton(enabled = !busy, onClick = { git("diff", "--stat") }) { Text("Изменения") }
            OutlinedButton(enabled = !busy, onClick = { git("log", "--oneline", "-n", "20") }) { Text("История") }
            OutlinedButton(enabled = !busy, onClick = { git("branch", "-a") }) { Text("Ветки") }
        }
        OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Сообщение коммита") }, singleLine = true)
        Button(enabled = !busy && message.isNotBlank(), onClick = {
            val m = message
            busy = true
            output = "…"
            scope.launch {
                val a = runGit(runtime, settings, project, listOf("add", "-A"))
                val c = runGit(runtime, settings, project, listOf("commit", "-m", m))
                output = if (a == "Готово.") c else a + "\n" + c
                if (!c.startsWith("Код")) message = ""
                busy = false
            }
        }) { Text("Добавить всё и закоммитить") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = !busy, onClick = { git("pull", network = true) }) { Text("Pull") }
            OutlinedButton(enabled = !busy, onClick = { git("push", "-u", "origin", "HEAD", network = true) }) { Text("Push") }
        }
        OutlinedTextField(value = remoteUrl, onValueChange = { remoteUrl = it }, label = { Text("URL origin (https://…)") }, singleLine = true)
        OutlinedButton(enabled = !busy && remoteUrl.startsWith("https://"), onClick = {
            val u = remoteUrl
            busy = true
            scope.launch {
                val r = runGit(runtime, settings, project, listOf("remote", "set-url", "origin", u))
                output = if (r.startsWith("Код")) runGit(runtime, settings, project, listOf("remote", "add", "origin", u)) else r
                busy = false
            }
        }) { Text("Задать origin") }
    }
    if (output.isNotEmpty()) {
        SelectionContainer {
            Text(output, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }
    }
}

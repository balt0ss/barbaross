package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val GRADLE_PRESETS = listOf("8.14.3", "8.13", "8.11.1", "8.10.2", "8.9", "8.7", "8.5", "8.2.1", "7.6.4")
private val PLATFORM_PRESETS = listOf("36", "35", "34", "33", "32", "31", "30", "29")
private val TOOLS_PRESETS = listOf("36.0.0", "35.0.0", "34.0.0", "33.0.2", "30.0.3")

/** Выбор версий инструментов: JDK, Gradle, платформы Android SDK, build-tools. Можно ставить несколько и выбирать активные. */
@Composable
fun VersionsCard(runtime: RuntimeClient, state: RuntimeState) {
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var ready by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<Bundle?>(null) }
    var installing by remember { mutableStateOf(false) }
    var log by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<Pair<String, String>?>(null) }

    suspend fun refresh() {
        ready = runtime.invoke("toolchain.status").getBoolean("ready")
        val b = runtime.invoke("versions.info")
        info = if (b.getString("error") == null) b else null
    }

    suspend fun follow() {
        installing = true
        while (true) {
            val b = runtime.invoke("toolchain.install.status")
            log = b.getString("log").orEmpty()
            if (!b.getBoolean("running")) {
                message = if (b.getBoolean("success")) "Готово." else "Не получилось, см. лог."
                break
            }
            delay(1000)
        }
        installing = false
        refresh()
    }

    LaunchedEffect(connected) {
        if (connected) {
            refresh()
            if (runtime.invoke("toolchain.install.status").getBoolean("running")) follow()
        }
    }

    fun install(kind: String, value: String) {
        scope.launch {
            message = null
            log = ""
            val r = runtime.invoke("versions.install", Bundle().apply { putString("kind", kind); putString("value", value) })
            val err = r.getString("error")
            if (err != null) message = err else follow()
        }
    }

    fun activate(kind: String, value: String) {
        scope.launch {
            val r = runtime.invoke("versions.activate", Bundle().apply { putString("kind", kind); putString("value", value) })
            message = r.getString("error") ?: "Выбрано: $value"
            refresh()
        }
    }

    val i = info
    if (!connected) {
        Text("Нет соединения с сервисом сборки.")
        return
    }
    if (!ready || i == null) {
        Text("Сначала установите инструменты сборки (блок выше).")
        return
    }
    val busy = installing

    Text(
        "Версии можно ставить рядом и выбирать активные. Каждая версия занимает место: Gradle около 130 МБ, JDK 200–300 МБ, платформа SDK 60–100 МБ.",
        style = MaterialTheme.typography.bodySmall,
    )

    VersionList(
        title = "JDK",
        hint = "Для проектов на AGP 8.x хватает 17. Ставьте 21, если проект её требует.",
        installed = i.getStringArray("jdkInstalled")?.toList().orEmpty(),
        active = i.getString("jdkActive"),
        base = "17",
        presets = listOf("17", "21"),
        label = { "JDK $it" },
        customLabel = null,
        busy = busy,
        onActivate = { activate("jdk", it) },
        onRemove = { confirm = "jdk" to it },
        onInstall = { install("jdk", it) },
    )
    VersionList(
        title = "Gradle",
        hint = "Если у проекта есть gradle-wrapper.properties и такая версия установлена, соберётся ею. Иначе — активной.",
        installed = i.getStringArray("gradleInstalled")?.toList().orEmpty(),
        active = i.getString("gradleActive"),
        base = i.getString("baseGradle"),
        presets = GRADLE_PRESETS,
        label = { "Gradle $it" },
        customLabel = "Другая версия (например 8.12)",
        busy = busy,
        onActivate = { activate("gradle", it) },
        onRemove = { confirm = "gradle" to it },
        onInstall = { install("gradle", it) },
    )
    VersionList(
        title = "Платформы Android SDK",
        hint = "compileSdk проекта должен быть установлен. Здесь выбирается номер API.",
        installed = i.getStringArray("platforms")?.toList().orEmpty(),
        active = null,
        base = i.getString("basePlatform"),
        presets = PLATFORM_PRESETS,
        label = { "Android API $it" },
        customLabel = "Другой API (например 28)",
        busy = busy,
        onActivate = null,
        onRemove = { confirm = "platform" to it },
        onInstall = { install("platform", it) },
    )
    VersionList(
        title = "Build-tools",
        hint = "Если проект не указал buildToolsVersion, используется активная версия.",
        installed = i.getStringArray("buildTools")?.toList().orEmpty(),
        active = i.getString("buildToolsActive"),
        base = i.getString("baseBuildTools"),
        presets = TOOLS_PRESETS,
        label = { "Build-tools $it" },
        customLabel = "Другая версия (например 34.0.0)",
        busy = busy,
        onActivate = { activate("buildtools", it) },
        onRemove = { confirm = "buildtools" to it },
        onInstall = { install("buildtools", it) },
    )

    if (installing) {
        OutlinedButton(onClick = { scope.launch { runtime.invoke("toolchain.install.cancel") } }) { Text("Отменить установку") }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    if (log.isNotEmpty()) {
        SelectionContainer {
            Text(log.lines().takeLast(25).joinToString("\n"), style = MaterialTheme.typography.bodySmall)
        }
    }

    confirm?.let { (kind, value) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Удалить $value?") },
            text = { Text("Версия будет удалена с телефона. При необходимости её можно установить заново.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    scope.launch {
                        val r = runtime.invoke("versions.remove", Bundle().apply { putString("kind", kind); putString("value", value) })
                        message = r.getString("error") ?: "Удалено: $value"
                        refresh()
                    }
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun VersionList(
    title: String,
    hint: String,
    installed: List<String>,
    active: String?,
    base: String?,
    presets: List<String>,
    label: (String) -> String,
    customLabel: String?,
    busy: Boolean,
    onActivate: ((String) -> Unit)?,
    onRemove: (String) -> Unit,
    onInstall: (String) -> Unit,
) {
    var custom by remember(title) { mutableStateOf("") }
    Text(title, style = MaterialTheme.typography.titleSmall)
    Text(hint, style = MaterialTheme.typography.bodySmall)
    if (installed.isEmpty()) Text("Не установлено.", style = MaterialTheme.typography.bodySmall)
    installed.forEach { v ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label(v) + (if (v == active) "  ● активна" else ""), modifier = Modifier.weight(1f))
            if (onActivate != null && v != active) TextButton(enabled = !busy, onClick = { onActivate(v) }) { Text("Выбрать") }
            if (v != base && v != active) TextButton(enabled = !busy, onClick = { onRemove(v) }) { Text("🗑️") }
        }
    }
    val addable = presets.filter { it !in installed }
    if (addable.isNotEmpty()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            addable.forEach { v -> OutlinedButton(enabled = !busy, onClick = { onInstall(v) }) { Text("＋ " + label(v)) } }
        }
    }
    if (customLabel != null) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = custom,
                onValueChange = { custom = it.filter { c -> c.isDigit() || c == '.' }.take(16) },
                label = { Text(customLabel) },
                singleLine = true,
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(enabled = !busy && custom.isNotEmpty(), onClick = { onInstall(custom.trim()); custom = "" }) { Text("Ставить") }
        }
    }
}

package dev.barbaross.ide

import java.io.File
import java.io.IOException
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes

/** Файловые операции, не заходящие по символическим ссылкам (в клонированных репозиториях они бывают и могут вести за пределы проекта). */
internal object Fs {
    fun isLink(f: File): Boolean = Files.isSymbolicLink(f.toPath())

    /** Удаляет файл или папку со всем содержимым. Ссылки удаляются сами, цель ссылки не затрагивается. */
    fun deleteTree(f: File): Boolean {
        val path = f.toPath()
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return true
        try {
            Files.walkFileTree(path, object : SimpleFileVisitor<Path>() {
                override fun preVisitDirectory(dir: Path, attrs: BasicFileAttributes): FileVisitResult {
                    dir.toFile().setWritable(true, true)
                    return FileVisitResult.CONTINUE
                }

                override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
                    try { Files.deleteIfExists(file) } catch (_: Exception) {}
                    return FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: Path, exc: IOException): FileVisitResult = FileVisitResult.CONTINUE

                override fun postVisitDirectory(dir: Path, exc: IOException?): FileVisitResult {
                    try { Files.deleteIfExists(dir) } catch (_: Exception) {}
                    return FileVisitResult.CONTINUE
                }
            })
        } catch (_: Exception) {
        }
        return !Files.exists(path, LinkOption.NOFOLLOW_LINKS)
    }
}

/** Настройки внешнего вида и редактора. */
internal object AppPrefs {
    private fun p(c: android.content.Context) = c.applicationContext.getSharedPreferences("app_prefs", android.content.Context.MODE_PRIVATE)

    /** 0 — как в системе, 1 — светлая, 2 — тёмная. */
    fun theme(c: android.content.Context): Int = p(c).getInt("theme", 0).coerceIn(0, 2)
    fun setTheme(c: android.content.Context, v: Int) { p(c).edit().putInt("theme", v).apply() }

    fun fontSize(c: android.content.Context): Int = p(c).getInt("font", 13).coerceIn(9, 26)
    fun setFontSize(c: android.content.Context, v: Int) { p(c).edit().putInt("font", v.coerceIn(9, 26)).apply() }
}

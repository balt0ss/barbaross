package dev.barbaross.ide.projects

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

/** SAF-backed workspaces. Access survives process/app restarts via persisted URI permissions. */
class ProjectRepository(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("project_workspaces", Context.MODE_PRIVATE)

    data class Project(val name: String, val uri: Uri, val treeUri: Uri = uri)
    data class Entry(val name: String, val uri: Uri, val directory: Boolean, val size: Long)

    fun recentProjects(): List<Project> {
        val raw = prefs.getString(KEY_RECENT, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        return buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val name = item.optString("name").takeIf(String::isNotBlank) ?: continue
                val uri = runCatching { Uri.parse(item.getString("uri")) }.getOrNull() ?: continue
                val treeUri = runCatching { Uri.parse(item.optString("treeUri", uri.toString())) }.getOrNull() ?: continue
                if (appContext.contentResolver.persistedUriPermissions.any { it.uri == treeUri && it.isReadPermission }) {
                    add(Project(name, uri, treeUri))
                }
            }
        }
    }

    fun restoreProject(project: Project): Project {
        resolve(project, project.uri)
        remember(project)
        return project
    }

    fun openProject(uri: Uri): Project {
        val root = DocumentFile.fromTreeUri(appContext, uri)
            ?: error("Не удалось открыть выбранную папку")
        require(root.isDirectory && root.canRead()) { "Нет доступа к папке проекта" }
        val project = Project(root.name?.takeIf(String::isNotBlank) ?: "Проект", root.uri, uri)
        remember(project)
        return project
    }

    fun createProject(parentUri: Uri, name: String): Project {
        val safeName = validateName(name)
        val parent = DocumentFile.fromTreeUri(appContext, parentUri)
            ?: error("Не удалось открыть выбранную папку")
        require(parent.isDirectory && parent.canWrite()) { "Нет прав на запись в выбранную папку" }
        require(parent.findFile(safeName) == null) { "Папка с таким именем уже существует" }
        val folder = parent.createDirectory(safeName) ?: error("Не удалось создать папку проекта")
        val project = Project(folder.name ?: safeName, folder.uri, parentUri)
        remember(project)
        return project
    }

    fun list(project: Project, directoryUri: Uri = project.uri): List<Entry> {
        val directory = DocumentFile.fromTreeUri(appContext, project.treeUri)
            ?.let { tree -> findByUri(tree, project.uri)?.let { root -> if (directoryUri == project.uri) root else findByUri(root, directoryUri) } }
            ?: error("Папка больше недоступна")
        require(directory.isDirectory && directory.canRead()) { "Нет доступа к папке" }
        return directory.listFiles().mapNotNull { file ->
            val name = file.name ?: return@mapNotNull null
            Entry(name, file.uri, file.isDirectory, file.length())
        }.sortedWith(compareByDescending<Entry> { it.directory }.thenBy { it.name.lowercase() })
    }

    fun create(project: Project, parentUri: Uri, name: String, directory: Boolean): Entry {
        val safeName = validateName(name)
        val parent = resolve(project, parentUri)
        require(parent.isDirectory && parent.canWrite()) { "Нет прав на запись" }
        require(parent.findFile(safeName) == null) { "Файл или папка уже существует" }
        val created = if (directory) parent.createDirectory(safeName) else parent.createFile(mimeFor(safeName), safeName)
        val file = created ?: error("Не удалось создать элемент")
        return Entry(file.name ?: safeName, file.uri, file.isDirectory, file.length())
    }

    fun rename(project: Project, uri: Uri, newName: String) {
        val safeName = validateName(newName)
        val file = resolve(project, uri)
        require(file.canWrite()) { "Нет прав на переименование" }
        require(file.parentFile?.findFile(safeName) == null) { "Элемент с таким именем уже существует" }
        require(file.renameTo(safeName)) { "Не удалось переименовать элемент" }
    }

    fun delete(project: Project, uri: Uri) {
        require(uri != project.uri) { "Нельзя удалить корневую папку проекта из IDE" }
        val file = resolve(project, uri)
        require(file.canWrite()) { "Нет прав на удаление" }
        require(file.delete()) { "Не удалось удалить элемент" }
    }

    /** Copies an item into the project root. A suffix is added if the name already exists. */
    fun copyToRoot(project: Project, sourceUri: Uri): Entry {
        require(sourceUri != project.uri) { "Нельзя копировать корень проекта" }
        val source = resolve(project, sourceUri)
        val root = resolve(project, project.uri)
        require(root.canWrite()) { "Нет прав на запись в корень проекта" }
        val targetName = uniqueName(root, source.name ?: "Копия")
        val target = copyDocument(source, root, targetName)
        return Entry(target.name ?: targetName, target.uri, target.isDirectory, target.length())
    }

    /** Moves an item into the project root only after a complete copy succeeds. */
    fun moveToRoot(project: Project, sourceUri: Uri) {
        require(sourceUri != project.uri) { "Нельзя переместить корень проекта" }
        val source = resolve(project, sourceUri)
        val root = resolve(project, project.uri)
        require(root.canWrite() && source.canWrite()) { "Нет прав на перемещение" }
        require(source.parentFile?.uri != root.uri) { "Элемент уже находится в корне проекта" }
        val targetName = uniqueName(root, source.name ?: "Элемент")
        copyDocument(source, root, targetName)
        require(source.delete()) { "Копия создана, но исходный элемент удалить не удалось" }
    }

    private fun copyDocument(source: DocumentFile, parent: DocumentFile, name: String): DocumentFile {
        if (source.isDirectory) {
            val directory = parent.createDirectory(name) ?: error("Не удалось создать папку-копию")
            try {
                source.listFiles().forEach { child ->
                    val childName = child.name ?: "Без имени"
                    copyDocument(child, directory, uniqueName(directory, childName))
                }
            } catch (error: Exception) {
                directory.delete()
                throw error
            }
            return directory
        }
        val target = parent.createFile(mimeFor(name), name) ?: error("Не удалось создать файл-копию")
        try {
            val input = appContext.contentResolver.openInputStream(source.uri)
                ?: error("Не удалось прочитать исходный файл")
            input.use { sourceStream ->
                val output = appContext.contentResolver.openOutputStream(target.uri, "w")
                    ?: error("Не удалось записать копию файла")
                output.use { targetStream -> sourceStream.copyTo(targetStream) }
            }
        } catch (error: Exception) {
            target.delete()
            throw error
        }
        return target
    }

    private fun uniqueName(parent: DocumentFile, original: String): String {
        if (parent.findFile(original) == null) return original
        val dot = original.lastIndexOf('.')
        val base = if (dot > 0) original.substring(0, dot) else original
        val extension = if (dot > 0) original.substring(dot) else ""
        var index = 1
        while (index < 10_000) {
            val candidate = "$base (копия $index)$extension"
            if (parent.findFile(candidate) == null) return candidate
            index++
        }
        error("Не удалось подобрать свободное имя для копии")
    }

    fun readText(project: Project, uri: Uri): String {
        val file = resolve(project, uri)
        require(!file.isDirectory) { "Нельзя прочитать папку как файл" }
        require(file.length() <= MAX_TEXT_BYTES || file.length() < 0) {
            "Файл слишком большой для предварительного просмотра (лимит 1 МБ)"
        }
        val input = appContext.contentResolver.openInputStream(uri) ?: error("Не удалось прочитать файл")
        return input.use { stream ->
            val output = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8 * 1024)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                total += count
                require(total <= MAX_TEXT_BYTES) {
                    "Файл слишком большой для предварительного просмотра (лимит 1 МБ)"
                }
                output.write(buffer, 0, count)
            }
            output.toString(Charsets.UTF_8.name())
        }
    }

    fun writeText(project: Project, uri: Uri, content: String) {
        val file = resolve(project, uri)
        require(!file.isDirectory && file.canWrite()) { "Файл недоступен для записи" }
        appContext.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(content) }
            ?: error("Не удалось сохранить файл")
    }

    private fun resolve(project: Project, uri: Uri): DocumentFile {
        val tree = DocumentFile.fromTreeUri(appContext, project.treeUri) ?: error("Проект недоступен")
        val root = findByUri(tree, project.uri) ?: error("Корневая папка проекта недоступна")
        return findByUri(root, uri) ?: error("Элемент не принадлежит открытому проекту или удалён")
    }

    private fun findByUri(root: DocumentFile, uri: Uri): DocumentFile? {
        if (root.uri == uri) return root
        if (!root.isDirectory) return null
        for (child in root.listFiles()) {
            if (child.uri == uri) return child
            if (child.isDirectory) findByUri(child, uri)?.let { return it }
        }
        return null
    }

    private fun remember(project: Project) {
        val all = (listOf(project) + recentProjects().filterNot { it.uri == project.uri }).take(MAX_RECENT)
        val array = JSONArray()
        all.forEach { array.put(JSONObject().put("name", it.name).put("uri", it.uri.toString()).put("treeUri", it.treeUri.toString())) }
        prefs.edit().putString(KEY_RECENT, array.toString()).apply()
    }

    private fun validateName(value: String): String {
        val name = value.trim()
        require(name.isNotEmpty()) { "Имя не может быть пустым" }
        require(name.length <= 80 && name !in setOf(".", "..") && name.none { it in "/\\:*?\"<>|" || it.code < 32 }) {
            "Недопустимое имя (до 80 символов, без / \\: * ? \" < > |)"
        }
        return name
    }

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "kt" -> "text/x-kotlin"
        "java" -> "text/x-java-source"
        "xml" -> "application/xml"
        "json" -> "application/json"
        "md" -> "text/markdown"
        "txt", "gradle", "properties", "kts", "yaml", "yml" -> "text/plain"
        else -> "application/octet-stream"
    }

    companion object {
        private const val KEY_RECENT = "recent"
        private const val MAX_RECENT = 12
        private const val MAX_TEXT_BYTES = 1024L * 1024L
    }
}

package dev.barbaross.ide

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.compose.ui.platform.LocalContext
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState

private enum class Section(val title: String, val icon: String) {
    Projects("Проекты", "📁"),
    Editor("Редактор", "✏️"),
    Terminal("Терминал", "⌨️"),
    Extensions("Расширения", "🧩"),
    Settings("Настройки", "⚙️"),
}

class MainActivity : ComponentActivity() {
    private lateinit var runtime: RuntimeClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runtime = RuntimeClient(applicationContext)
        setContent {
            val sysDark = isSystemInDarkTheme()
            var themeMode by remember { mutableIntStateOf(AppPrefs.theme(applicationContext)) }
            val dark = when (themeMode) {
                1 -> false
                2 -> true
                else -> sysDark
            }
            BarbarossTheme(dark) {
                val state by runtime.state.collectAsState()
                val workspace = remember { Workspace() }
                var selected by rememberSaveable { mutableIntStateOf(AppPrefs.section(applicationContext).coerceIn(0, Section.entries.size - 1)) }
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            Section.entries.forEach { s ->
                                // «Редактор» — это вкладка проекта: показываем её как отдельный пункт.
                                val inEditor = selected == Section.Projects.ordinal && workspace.tab == 2
                                val isSelected = when (s) {
                                    Section.Editor -> inEditor
                                    Section.Projects -> selected == s.ordinal && !inEditor
                                    else -> selected == s.ordinal
                                }
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        if (s == Section.Editor) {
                                            selected = Section.Projects.ordinal
                                            workspace.tab = if (workspace.selectedProject != null && workspace.sessions.isNotEmpty()) 2 else 0
                                        } else {
                                            selected = s.ordinal
                                            if (s == Section.Projects && workspace.tab == 2) workspace.tab = 0
                                        }
                                        AppPrefs.setSection(applicationContext, selected)
                                    },
                                    icon = { Text(s.icon) },
                                    label = { Text(s.title) },
                                )
                            }
                        }
                    },
                ) { padding ->
                    val section = Section.entries[selected]
                    Column(
                        Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Text(if (section == Section.Editor) Section.Projects.title else section.title, style = MaterialTheme.typography.titleLarge)
                        if (section == Section.Projects) {
                            ProjectsScreen(runtime, state, workspace)
                        } else if (section == Section.Extensions) {
                            ExtensionsScreen(workspace)
                        } else if (section == Section.Terminal) {
                            TerminalScreen(runtime, state, workspace)
                        } else if (section == Section.Settings) {
                            Collapsible("Внешний вид", startOpen = true) {
                                AppearanceCard(themeMode) { themeMode = it; AppPrefs.setTheme(applicationContext, it) }
                            }
                            Collapsible("Инструменты сборки и Git", startOpen = true) { ToolchainCard(runtime, state) }
                            Collapsible("Версии: JDK, Gradle, SDK") { VersionsCard(runtime, state) }
                            Collapsible("Подпись release-APK") { SigningCard(runtime, state) }
                            Collapsible("Место на устройстве") { StorageCard(runtime, state) }
                            Collapsible("Диагностика (для разработки)") {
                                RuntimeStatus(
                                    state,
                                    onRetry = { runtime.disconnect(); runtime.connect() },
                                    onDiagnostics = { runtime.runDiagnostics() },
                                    onStartJdk = { runtime.startJdkProbe() },
                                    onJdkStatus = { runtime.jdkProbeStatus() },
                                    onStartGradle = { runtime.startGradleProbe() },
                                    onGradleStatus = { runtime.gradleProbeStatus() },
                                    onStartAndroid = { runtime.startAndroidBuildProbe() },
                                    onAndroidStatus = { runtime.androidBuildProbeStatus() },
                                    onStartCompose = { runtime.startComposeBuildProbe() },
                                    onComposeStatus = { runtime.composeBuildProbeStatus() },
                                )
                            }
                        } else {
                            ProjectsScreen(runtime, state, workspace)
                        }
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        runtime.connect()
    }

    override fun onStop() {
        runtime.disconnect()
        super.onStop()
    }
}

@Composable
private fun RuntimeStatus(
    state: RuntimeState,
    onRetry: () -> Unit,
    onDiagnostics: suspend () -> String,
    onStartJdk: suspend () -> Boolean,
    onJdkStatus: suspend () -> String,
    onStartGradle: suspend () -> Boolean,
    onGradleStatus: suspend () -> String,
    onStartAndroid: suspend () -> Boolean,
    onAndroidStatus: suspend () -> String,
    onStartCompose: suspend () -> Boolean,
    onComposeStatus: suspend () -> String,
) {
    Text("Build Runtime", style = MaterialTheme.typography.titleMedium)
    val text = when (state) {
        RuntimeState.Disconnected -> "Нет соединения."
        RuntimeState.ServiceUnavailable ->
            "Сервис сборки не найден в приложении (ошибка сборки APK)."
        is RuntimeState.IncompatibleProtocol ->
            "Версия протокола Runtime (${state.runtimeVersion}) несовместима с этой IDE."
        is RuntimeState.Connected ->
            "Подключено, протокол v${state.protocolVersion}.\n" +
                "JDK: ${if (state.jdk) "есть" else "нет"}; " +
                "Gradle: ${if (state.gradle) "есть" else "нет"}; " +
                "Android SDK: ${if (state.sdk) "есть" else "нет"}; " +
                "готово к сборке: ${if (state.ready) "да" else "нет"}."
        is RuntimeState.Error -> "Ошибка связи: ${state.detail}"
    }
    Text(text)
    Button(onClick = onRetry) { Text("Проверить снова") }

    var showExperiments by remember { mutableStateOf(false) }
    Button(onClick = { showExperiments = !showExperiments }) {
        Text(if (showExperiments) "Скрыть эксперименты" else "Эксперименты (старые пробы)")
    }
    if (!showExperiments) return

    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }
    Button(
        enabled = state is RuntimeState.Connected && !running,
        onClick = {
            running = true
            scope.launch {
                report = onDiagnostics()
                running = false
            }
        },
    ) { Text(if (running) "Выполняется…" else "Диагностика исполнения") }
    report?.let {
        SelectionContainer {
            Text(it, style = MaterialTheme.typography.bodySmall)
        }
    }

    val ready = state is RuntimeState.Connected
    ProbeSection("Проба JDK (скачает сотни МБ)", ready, onStartJdk, onJdkStatus)
    ProbeSection("Проба Gradle (после пробы JDK)", ready, onStartGradle, onGradleStatus)
    ProbeSection("Проба сборки Android-приложения (после JDK и Gradle)", ready, onStartAndroid, onAndroidStatus)
    val context = LocalContext.current
    Button(onClick = { installBuiltApk(context, "androidprobe") }) { Text("Установить собранное приложение") }
    ProbeSection("Проба сборки Kotlin + Compose (тяжёлая, после пробы Android)", ready, onStartCompose, onComposeStatus)
    Button(onClick = { installBuiltApk(context, "composeprobe") }) { Text("Установить собранное Compose-приложение") }
}

/** Кнопка фонового эксперимента + живой лог. Если эксперимент уже идёт (экран открыт заново), подхватывает его. */
@Composable
private fun ProbeSection(
    label: String,
    enabled: Boolean,
    onStart: suspend () -> Boolean,
    onStatus: suspend () -> String,
) {
    val scope = rememberCoroutineScope()
    var log by remember { mutableStateOf<String?>(null) }
    var running by remember { mutableStateOf(false) }

    suspend fun poll() {
        running = true
        while (true) {
            val s = onStatus()
            log = s
            if (!s.startsWith("[выполняется]")) break
            delay(1500)
        }
        running = false
    }

    LaunchedEffect(enabled) {
        if (enabled && onStatus().startsWith("[выполняется]")) poll()
    }

    Button(
        enabled = enabled && !running,
        onClick = { scope.launch { onStart(); poll() } },
    ) { Text(if (running) "Выполняется…" else label) }
    log?.let { SelectionContainer { Text(it, style = MaterialTheme.typography.bodySmall) } }
}

/** Отдаёт собранный на телефоне APK системному установщику (через FileProvider). */
private fun installBuiltApk(context: Context, probeDir: String) {
    val dir = File(context.filesDir, "$probeDir/app/build/outputs/apk/debug")
    val apk = dir.listFiles { f -> f.name.endsWith(".apk") }?.firstOrNull()
    if (apk == null) {
        Toast.makeText(context, "APK не найден — сначала выполните пробу сборки", Toast.LENGTH_LONG).show()
        return
    }
    installApkFile(context, apk)
}

/** Предлагает отправить APK другому приложению (через FileProvider). */
internal fun shareApkFile(context: Context, apk: File) {
    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", apk)
    val send = Intent(Intent.ACTION_SEND)
        .setType("application/vnd.android.package-archive")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, "Поделиться APK").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Отдаёт APK системному установщику (через FileProvider). */
internal fun installApkFile(context: Context, apk: File) {
    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", apk)
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "application/vnd.android.package-archive")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

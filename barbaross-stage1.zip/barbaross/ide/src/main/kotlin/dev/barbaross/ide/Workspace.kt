package dev.barbaross.ide

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/**
 * Рабочее пространство IDE: выбранный проект, вкладка проекта и открытые файлы.
 * Живёт на уровне Activity, чтобы несохранённый текст не терялся при переходе между разделами.
 */
class Workspace {
    var selectedProject by mutableStateOf<File?>(null)

    /** 0 — файлы, 1 — сборка, 2 — редактор. */
    var tab by mutableIntStateOf(0)
    var pendingBuild by mutableStateOf(false)

    val sessions = mutableStateListOf<EditorSession>()
    var active by mutableStateOf<EditorSession?>(null)

    /** Открывает файл (при необходимости на строке line, нумерация с 1) и переключает на редактор. */
    fun open(file: File, line: Int = 0) {
        val s = sessions.firstOrNull { it.file == file } ?: EditorSession(file).also { sessions.add(it) }
        if (line > 0) s.requestedLine = line
        active = s
        tab = 2
    }

    fun close(s: EditorSession) {
        val i = sessions.indexOf(s)
        sessions.remove(s)
        if (active == s) active = sessions.getOrNull(minOf(i, sessions.size - 1))
    }

    fun anyDirty(): Boolean = sessions.any { it.state.dirty }

    fun saveAll(): Boolean = sessions.filter { it.state.dirty }.all { it.save() }
}

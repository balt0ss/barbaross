package dev.barbaross.ide

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.content.Context
import java.io.File

/** Боковые панели (как в VS Code): проводник, поиск, Git, расширения, настройки. */
enum class Sidebar(val title: String, val icon: String) {
    Files("Проводник", "📁"),
    Search("Поиск", "🔍"),
    Git("Git", "🌿"),
    Extensions("Расширения", "🧩"),
    Settings("Настройки", "⚙️"),
}

/**
 * Рабочее пространство IDE: выбранный проект, открытые файлы, состояние боковой и нижней панелей.
 * Живёт на уровне Activity, чтобы несохранённый текст не терялся при переключении панелей.
 */
class Workspace {
    var selectedProject by mutableStateOf<File?>(null)

    /** Открытая боковая панель (null — закрыта). */
    var sidebar by mutableStateOf<Sidebar?>(null)

    /** В проводнике показывать список проектов (создание, импорт, клонирование) вместо дерева файлов. */
    var showProjects by mutableStateOf(false)

    /** Нижняя панель: 0 — сборка, 1 — терминал, 2 — проблемы. */
    var panelOpen by mutableStateOf(false)
    var panelTab by mutableIntStateOf(0)

    var pendingBuild by mutableStateOf(false)

    /** Буфер обмена файлового менеджера: что скопировали/вырезали. */
    var clipFiles by mutableStateOf<List<File>>(emptyList())
    var clipCut by mutableStateOf(false)

    val sessions = mutableStateListOf<EditorSession>()
    var active by mutableStateOf<EditorSession?>(null)

    /** Открывает файл (при необходимости на строке line, нумерация с 1) и закрывает боковую панель. */
    fun open(file: File, line: Int = 0) {
        val s = sessions.firstOrNull { it.file == file } ?: EditorSession(file).also { sessions.add(it) }
        if (line > 0) s.requestedLine = line
        active = s
        sidebar = null
    }

    fun close(s: EditorSession) {
        val i = sessions.indexOf(s)
        sessions.remove(s)
        if (active == s) active = sessions.getOrNull(minOf(i, sessions.size - 1))
    }

    /** Запускает сборку Debug и показывает нижнюю панель с логом. */
    fun runBuild() {
        panelTab = 0
        panelOpen = true
        pendingBuild = true
    }

    fun anyDirty(): Boolean = sessions.any { it.state.dirty }

    fun saveAll(): Boolean = sessions.filter { it.state.dirty }.all { it.save() }

    /** Закрывает открытые файлы внутри path. Возвращает текст ошибки, если там есть несохранённые изменения. */
    fun closeUnder(path: File): String? {
        val own = sessions.filter { it.file == path || it.file.path.startsWith(path.path + File.separator) }
        if (own.any { it.state.dirty }) return "Есть несохранённые файлы в «${path.name}». Сначала сохраните или закройте их."
        own.forEach { close(it) }
        return null
    }

    /** Восстанавливает последний проект и открытые файлы после перезапуска приложения. */
    fun restore(context: Context) {
        val projectsRoot = File(context.filesDir, "projects")
        val p = AppPrefs.lastProject(context)?.let { File(it) }
        if (p == null || !p.isDirectory || p.parentFile != projectsRoot) return
        selectedProject = p
        val files = AppPrefs.openFiles(context).map { File(it) }
            .filter { it.isFile && it.path.startsWith(p.path + File.separator) && !Fs.isLink(it) }
        files.forEach { sessions.add(EditorSession(it)) }
        val a = AppPrefs.activeFile(context)
        active = sessions.firstOrNull { it.file.path == a } ?: sessions.firstOrNull()
    }

    /** Запоминает проект и открытые файлы (без сохранения текста). */
    fun persist(context: Context) {
        AppPrefs.setWorkspace(context, selectedProject?.path, sessions.map { it.file.path }, active?.file?.path)
    }
}

package dev.barbaross.ide.runtime

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import dev.barbaross.ipc.BuildProtocol
import dev.barbaross.ipc.IBuildService
import dev.barbaross.runtime.BuildService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Состояние связи IDE с Build Runtime. */
sealed interface RuntimeState {
    data object Disconnected : RuntimeState
    data object ServiceUnavailable : RuntimeState
    data class IncompatibleProtocol(val runtimeVersion: Int) : RuntimeState
    data class Connected(
        val protocolVersion: Int,
        val jdk: Boolean,
        val gradle: Boolean,
        val sdk: Boolean,
    ) : RuntimeState
    data class Error(val detail: String) : RuntimeState
}

/**
 * Bind к собственному сервису сборки (процесс ":build" внутри этого же APK).
 * Binder-вызовы выполняются на IO-потоке, а результаты публикуются в StateFlow.
 */
class RuntimeClient(context: Context) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow<RuntimeState>(RuntimeState.Disconnected)
    val state: StateFlow<RuntimeState> = _state.asStateFlow()

    // connect/disconnect и ServiceConnection callbacks выполняются на главном потоке.
    private var bound = false
    private var generation = 0L
    private var connection: ServiceConnection? = null

    @Volatile
    private var api: IBuildService? = null

    fun connect() {
        if (bound || connection != null) return

        val token = ++generation
        lateinit var candidate: ServiceConnection
        candidate = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, service: IBinder) {
                if (!isCurrent(token, this)) return

                val remote = IBuildService.Stub.asInterface(service)
                if (remote == null) {
                    _state.value = RuntimeState.Error("Runtime вернул пустой Binder")
                    return
                }
                api = remote
                val callbackConnection = this

                // Даже короткие синхронные Binder-транзакции не должны блокировать UI.
                scope.launch {
                    val result = withContext(Dispatchers.IO) {
                        try {
                            val version = remote.getProtocolVersion()
                            if (!BuildProtocol.isCompatible(version)) {
                                RuntimeState.IncompatibleProtocol(version)
                            } else {
                                val status = remote.getToolchainStatus()
                                RuntimeState.Connected(
                                    protocolVersion = version,
                                    jdk = status.getBoolean(BuildProtocol.KEY_JDK_INSTALLED),
                                    gradle = status.getBoolean(BuildProtocol.KEY_GRADLE_INSTALLED),
                                    sdk = status.getBoolean(BuildProtocol.KEY_SDK_INSTALLED),
                                )
                            }
                        } catch (e: Exception) {
                            RuntimeState.Error(e.message ?: e.javaClass.simpleName)
                        }
                    }
                    if (isCurrent(token, callbackConnection)) {
                        _state.value = result
                    }
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
                if (!isCurrent(token, this)) return
                api = null
                _state.value = RuntimeState.Disconnected
            }

            override fun onBindingDied(name: ComponentName) {
                releaseDeadBinding(token, this)
            }

            override fun onNullBinding(name: ComponentName) {
                releaseDeadBinding(token, this)
            }
        }

        connection = candidate
        try {
            bound = appContext.bindService(
                Intent(appContext, BuildService::class.java),
                candidate,
                Context.BIND_AUTO_CREATE,
            )
            if (!bound) {
                connection = null
                api = null
                _state.value = RuntimeState.ServiceUnavailable
                // bindService вернул false: регистрация не состоялась, unbindService вызывать нельзя.
            }
        } catch (e: SecurityException) {
            connection = null
            bound = false
            api = null
            _state.value = RuntimeState.Error("bind запрещён: ${e.message}")
        } catch (e: RuntimeException) {
            connection = null
            bound = false
            api = null
            _state.value = RuntimeState.Error("Не удалось подключить Runtime: ${e.message}")
        }
    }

    private fun isCurrent(token: Long, candidate: ServiceConnection): Boolean =
        generation == token && connection === candidate && bound

    private fun releaseDeadBinding(token: Long, candidate: ServiceConnection) {
        if (generation != token || connection !== candidate) return
        api = null
        connection = null
        val wasBound = bound
        bound = false
        if (wasBound) {
            try {
                appContext.unbindService(candidate)
            } catch (_: IllegalArgumentException) {
                // Защита от повторного unbind при гонке системных callbacks.
            }
        }
        _state.value = RuntimeState.ServiceUnavailable
    }

    /** Диагностика выполняется в процессе :build, Binder-вызов — на IO-потоке. */
    suspend fun runDiagnostics(): String = withContext(Dispatchers.IO) {
        val service = api ?: return@withContext "Нет соединения с сервисом сборки."
        try {
            service.runDiagnostics()
        } catch (e: Exception) {
            "Ошибка диагностики: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    suspend fun startJdkProbe(): Boolean = withContext(Dispatchers.IO) {
        try { api?.startJdkProbe() ?: false } catch (_: Exception) { false }
    }

    suspend fun jdkProbeStatus(): String = withContext(Dispatchers.IO) {
        try { api?.getJdkProbeStatus() ?: "[завершено]\nНет соединения с сервисом сборки." }
        catch (e: Exception) { "[завершено]\nОшибка: ${e.javaClass.simpleName}: ${e.message}" }
    }

    suspend fun startGradleProbe(): Boolean = withContext(Dispatchers.IO) {
        try { api?.startGradleProbe() ?: false } catch (_: Exception) { false }
    }

    suspend fun gradleProbeStatus(): String = withContext(Dispatchers.IO) {
        try { api?.getGradleProbeStatus() ?: "[завершено]\nНет соединения с сервисом сборки." }
        catch (e: Exception) { "[завершено]\nОшибка: ${e.javaClass.simpleName}: ${e.message}" }
    }

    suspend fun startAndroidBuildProbe(): Boolean = withContext(Dispatchers.IO) {
        try { api?.startAndroidBuildProbe() ?: false } catch (_: Exception) { false }
    }

    suspend fun androidBuildProbeStatus(): String = withContext(Dispatchers.IO) {
        try { api?.getAndroidBuildProbeStatus() ?: "[завершено]\nНет соединения с сервисом сборки." }
        catch (e: Exception) { "[завершено]\nОшибка: ${e.javaClass.simpleName}: ${e.message}" }
    }

    suspend fun startComposeBuildProbe(): Boolean = withContext(Dispatchers.IO) {
        try { api?.startComposeBuildProbe() ?: false } catch (_: Exception) { false }
    }

    suspend fun composeBuildProbeStatus(): String = withContext(Dispatchers.IO) {
        try { api?.getComposeBuildProbeStatus() ?: "[завершено]\nНет соединения с сервисом сборки." }
        catch (e: Exception) { "[завершено]\nОшибка: ${e.javaClass.simpleName}: ${e.message}" }
    }

    fun disconnect() {
        ++generation // инвалидирует ещё не завершившиеся callbacks/проверки подключения
        val oldConnection = connection
        connection = null
        api = null
        val wasBound = bound
        bound = false
        if (wasBound && oldConnection != null) {
            try {
                appContext.unbindService(oldConnection)
            } catch (_: IllegalArgumentException) {
                // Сервис уже отвязан системой.
            }
        }
        _state.value = RuntimeState.Disconnected
    }
}

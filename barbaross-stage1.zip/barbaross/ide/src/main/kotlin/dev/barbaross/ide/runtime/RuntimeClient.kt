package dev.barbaross.ide.runtime

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import dev.barbaross.runtime.BuildService
import android.content.ServiceConnection
import android.os.IBinder
import dev.barbaross.ipc.BuildProtocol
import dev.barbaross.ipc.IBuildService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/** Состояние связи IDE с Build Runtime. */
sealed interface RuntimeState {
    data object Disconnected : RuntimeState
    data object ServiceUnavailable : RuntimeState
    data class IncompatibleProtocol(val runtimeVersion: Int) : RuntimeState
    data class Connected(
        val protocolVersion: Int,
        val jdk: Boolean,
        val gradle: Boolean,
        val sdk: Boolean,
    ) : RuntimeState
    data class Error(val detail: String) : RuntimeState
}

/**
 * Bind к собственному сервису сборки (процесс ":build" внутри этого же APK).
 * Явный Intent на класс сервиса: чужие приложения подключиться не могут (сервис не экспортирован).
 * Вызовы Binder ниже короткие; тяжёлые вызовы в будущем выполнять не на главном потоке.
 */
class RuntimeClient(private val context: Context) {
    private val _state = MutableStateFlow<RuntimeState>(RuntimeState.Disconnected)
    val state: StateFlow<RuntimeState> = _state.asStateFlow()

    private var bound = false

    @Volatile
    private var api: IBuildService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            _state.value = try {
                val api = IBuildService.Stub.asInterface(service)
                    ?: throw IllegalStateException("Runtime вернул пустой Binder")
                this@RuntimeClient.api = api
                val version = api.getProtocolVersion()
                if (!BuildProtocol.isCompatible(version)) {
                    RuntimeState.IncompatibleProtocol(version)
                } else {
                    val s = api.getToolchainStatus()
                    RuntimeState.Connected(
                        protocolVersion = version,
                        jdk = s.getBoolean(BuildProtocol.KEY_JDK_INSTALLED),
                        gradle = s.getBoolean(BuildProtocol.KEY_GRADLE_INSTALLED),
                        sdk = s.getBoolean(BuildProtocol.KEY_SDK_INSTALLED),
                    )
                }
            } catch (e: Exception) {
                RuntimeState.Error(e.message ?: e.javaClass.simpleName)
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            api = null
            _state.value = RuntimeState.Disconnected
        }
    }

    fun connect() {
        if (bound) return
        val intent = Intent(context, BuildService::class.java)
        try {
            bound = context.bindService(intent, connection, Context.BIND_AUTO_CREATE)
            if (!bound) {
                // Сервис не объявлен в манифесте (ошибка сборки/слияния манифестов).
                _state.value = RuntimeState.ServiceUnavailable
                context.unbindService(connection)
            }
        } catch (e: SecurityException) {
            bound = false
            _state.value = RuntimeState.Error("bind запрещён: ${e.message}")
        }
    }

    /** Запускает диагностику в процессе :build. Binder-вызов выполняется на IO-потоке. */
    suspend fun runDiagnostics(): String = withContext(Dispatchers.IO) {
        val service = api ?: return@withContext "Нет соединения с сервисом сборки."
        try {
            service.runDiagnostics()
        } catch (e: Exception) {
            "Ошибка диагностики: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    fun disconnect() {
        api = null
        if (bound) {
            context.unbindService(connection)
            bound = false
        }
        _state.value = RuntimeState.Disconnected
    }
}

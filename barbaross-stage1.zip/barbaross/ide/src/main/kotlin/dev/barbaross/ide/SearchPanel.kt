package dev.barbaross.ide

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Hit(val file: File, val rel: String, val line: Int, val text: String)

private class SearchResult(val hits: List<Hit>, val files: Int, val truncated: Boolean)

private val SKIP_DIRS = setOf(".git", "build", ".gradle", ".idea", "node_modules")
private val BINARY_EXT = setOf(
    "png", "jpg", "jpeg", "gif", "webp", "ico", "apk", "aab", "jar", "aar", "zip", "so", "class", "dex", "ttf", "otf",
    "mp3", "mp4", "pdf", "keystore", "jks",
)
private const val MAX_HITS = 300

/** Поиск строки по всем текстовым файлам проекта (по сохранённым на диск версиям файлов). */
private fun searchProject(root: File, query: String): SearchResult {
    val hits = ArrayList<Hit>()
    var files = 0
    var truncated = false
    val rootPath = root.canonicalPath

    fun walk(dir: File) {
        val children = dir.listFiles()?.sortedBy { it.name } ?: return
        for (f in children) {
            if (truncated) return
            if (f.isDirectory) {
                if (f.name in SKIP_DIRS) continue
                // Не выходим за пределы проекта по символическим ссылкам.
                if (!f.canonicalPath.startsWith(rootPath + File.separator)) continue
                walk(f)
            } else if (f.isFile) {
                if (f.extension.lowercase() in BINARY_EXT || f.length() > 1_000_000) continue
                if (!f.canonicalPath.startsWith(rootPath + File.separator)) continue
                val bytes = try { f.readBytes() } catch (e: Exception) { continue }
                if (bytes.take(4096).any { it == 0.toByte() }) continue
                files++
                val rel = f.canonicalPath.removePrefix(rootPath + File.separator)
                String(bytes, Charsets.UTF_8).lineSequence().forEachIndexed { i, ln ->
                    if (!truncated && ln.contains(query, ignoreCase = true)) {
                        if (hits.size >= MAX_HITS) truncated = true else hits.add(Hit(f, rel, i + 1, ln.trim().take(160)))
                    }
                }
            }
        }
    }
    walk(root)
    return SearchResult(hits, files, truncated)
}

/** Вкладка «Поиск»: результаты по всему проекту, нажатие открывает файл на нужной строке. */
@Composable
fun SearchPanel(project: File, onOpen: (File, Int) -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SearchResult?>(null) }
    var searched by remember { mutableStateOf("") }

    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Искать во всём проекте") }, singleLine = true)
    Button(enabled = !busy && query.length >= 2, onClick = {
        val q = query
        busy = true
        result = null
        scope.launch {
            val r = withContext(Dispatchers.IO) { searchProject(project, q) }
            searched = q
            result = r
            busy = false
        }
    }) { Text(if (busy) "Ищу…" else "Найти") }
    if (query.length < 2) Text("Введите минимум 2 символа.", style = MaterialTheme.typography.bodySmall)

    result?.let { r ->
        if (r.hits.isEmpty()) {
            Text("«$searched»: ничего не найдено (просмотрено файлов: ${r.files}).")
        } else {
            val extra = if (r.truncated) " Показаны первые $MAX_HITS." else ""
            Text("Найдено: ${r.hits.size} в файлах: ${r.hits.map { it.rel }.distinct().size}.$extra", style = MaterialTheme.typography.bodySmall)
            r.hits.forEach { h ->
                TextButton(onClick = { onOpen(h.file, h.line) }) {
                    Text("${h.rel}:${h.line}  ${h.text}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Text("Поиск идёт по сохранённым файлам: сначала сохраните изменения.", style = MaterialTheme.typography.bodySmall)
    }
}

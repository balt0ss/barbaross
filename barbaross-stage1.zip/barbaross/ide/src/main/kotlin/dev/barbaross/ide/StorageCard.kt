package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.launch

private class CleanItem(val key: String, val title: String, val hint: String)

private val ITEMS = listOf(
    CleanItem("probes", "Старые пробные данные", "Остатки первых проверок. Не нужны, когда инструменты сборки установлены."),
    CleanItem("gradle", "Кэш Gradle", "Скачанные библиотеки. Следующая сборка скачает их заново: нужен интернет, она будет долгой."),
    CleanItem("downloads", "Скачанные установочные файлы", "Архивы, оставшиеся после установки инструментов."),
    CleanItem("builds", "Папки build в проектах", "Результаты прошлых сборок. Пересоздаются при следующей сборке."),
)

private fun fmt(b: Long): String =
    if (b >= 1L shl 30) String.format("%.1f ГБ", b / (1024.0 * 1024.0 * 1024.0)) else "${b / (1024 * 1024)} МБ"

/** Использование места и очистка: старые пробы, кэш Gradle, скачанные файлы, build. */
@Composable
fun StorageCard(runtime: RuntimeClient, state: RuntimeState) {
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var info by remember { mutableStateOf<Bundle?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<CleanItem?>(null) }
    var busy by remember { mutableStateOf(false) }

    suspend fun refresh() {
        val b = runtime.invoke("storage.info")
        info = if (b.getString("error") == null) b else null
    }

    LaunchedEffect(connected) { if (connected) refresh() }

    Text("Место на устройстве", style = MaterialTheme.typography.titleMedium)
    val i = info
    if (i == null) {
        Text(if (connected) "Считаю…" else "Нет соединения с сервисом сборки.")
        return
    }
    Text("Свободно: ${fmt(i.getLong("free"))}. Инструменты сборки занимают: ${fmt(i.getLong("toolchain"))}.", style = MaterialTheme.typography.bodySmall)
    ITEMS.forEach { item ->
        val size = i.getLong(item.key)
        Text("${item.title}: ${fmt(size)}")
        OutlinedButton(enabled = !busy && size > 0, onClick = { confirm = item }) { Text("Очистить") }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    OutlinedButton(enabled = !busy, onClick = { scope.launch { refresh() } }) { Text("Пересчитать") }

    confirm?.let { item ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Очистить: ${item.title}?") },
            text = { Text(item.hint) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    busy = true
                    message = "Очищаю…"
                    scope.launch {
                        val r = runtime.invoke("storage.clean", Bundle().apply { putString("target", item.key) })
                        message = r.getString("error") ?: "Готово."
                        refresh()
                        busy = false
                    }
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Отмена") } },
        )
    }
}

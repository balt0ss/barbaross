package dev.barbaross.ide

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Расширения: сниппеты и шаблоны проектов (без исполняемого кода). */
@Composable
fun ExtensionsScreen(ws: Workspace) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(ExtensionManager.list(context)) }
    var url by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val projectsDir = remember { File(context.filesDir, "projects").apply { mkdirs() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            message = "Устанавливаю…"
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    try {
                        val input = context.contentResolver.openInputStream(uri)
                        if (input == null) null to "Не удалось открыть файл." else input.use { ExtensionManager.install(context, it) }
                    } catch (e: Exception) {
                        null to "Ошибка: ${e.message}"
                    }
                }
                message = r.second ?: "Установлено: ${r.first?.name}"
                items = ExtensionManager.list(context)
                busy = false
            }
        }
    }

    Text(
        "Расширения добавляют сниппеты для автодополнения и шаблоны проектов. Исполняемого кода в IDE они не содержат, " +
            "но шаблон — это обычный проект: при сборке Gradle выполняет его скрипты. Ставьте только из источников, которым доверяете.",
        style = MaterialTheme.typography.bodySmall,
    )
    OutlinedButton(enabled = !busy, onClick = { picker.launch(arrayOf("*/*")) }) { Text("Установить из zip-файла") }
    OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Ссылка на zip (https://…)") }, singleLine = true)
    Button(enabled = !busy && url.startsWith("https://"), onClick = {
        val u = url
        busy = true
        message = "Скачиваю и устанавливаю…"
        scope.launch {
            val r = withContext(Dispatchers.IO) { ExtensionManager.installFromUrl(context, u) }
            message = r.second ?: "Установлено: ${r.first?.name}"
            items = ExtensionManager.list(context)
            busy = false
        }
    }) { Text("Установить по ссылке") }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

    if (items.isEmpty()) {
        Text("Установленных расширений нет.")
    }
    items.forEach { ext ->
        ExtensionCard(ext, projectsDir, ws,
            onRemoved = {
                ExtensionManager.remove(context, ext.id)
                items = ExtensionManager.list(context)
                message = "Удалено: ${ext.name}"
            },
            onMessage = { message = it },
        )
    }
}

@Composable
private fun ExtensionCard(ext: Extension, projectsDir: File, ws: Workspace, onRemoved: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    Text("${ext.name} ${ext.version}".trim(), style = MaterialTheme.typography.titleMedium)
    if (ext.description.isNotBlank()) Text(ext.description, style = MaterialTheme.typography.bodySmall)
    Text("Сниппетов: ${ext.snippets.size}, шаблонов: ${ext.templates.size}", style = MaterialTheme.typography.bodySmall)
    ext.templates.forEach { (title, dir) ->
        var name by remember(ext.id, dir) { mutableStateOf("") }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Имя проекта из шаблона «$title»") }, singleLine = true)
        OutlinedButton(enabled = name.isNotBlank(), onClick = {
            val r = ExtensionManager.createProject(context, ext, dir, name.trim(), projectsDir)
            val project = r.first
            if (project != null) {
                ws.selectedProject = project
                ws.tab = 0
                onMessage("Проект создан: ${project.name}. Откройте раздел «Проекты».")
                name = ""
            } else {
                onMessage(r.second.orEmpty())
            }
        }) { Text("Создать проект") }
    }
    OutlinedButton(onClick = onRemoved) { Text("Удалить расширение") }
}

package dev.barbaross.ide

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Расширения без исполняемого кода: сниппеты для автодополнения и шаблоны проектов.
 * Формат: zip с extension.json в корне (или в единственной папке верхнего уровня — как у архивов GitHub).
 * { "id": "my.pack", "name": "...", "version": "1.0", "description": "...",
 *   "snippets": [ { "label": "foo", "insert": "foo(|)" } ],
 *   "templates": [ { "name": "Мой шаблон", "dir": "template" } ] }
 */
internal class Extension(
    val id: String,
    val name: String,
    val version: String,
    val description: String,
    val snippets: List<Pair<String, String>>,
    val templates: List<Pair<String, String>>,
    val dir: File,
)

internal object ExtensionManager {
    private const val MAX_ZIP_BYTES = 30L * 1024 * 1024
    private const val MAX_ENTRIES = 3000
    private const val MAX_SNIPPETS = 200
    private val ID_RE = Regex("[a-z0-9][a-z0-9._-]{0,49}")
    private val NAME_RE = Regex("[A-Za-z0-9_][A-Za-z0-9._-]{0,39}")

    private fun root(context: Context) = File(context.filesDir, "extensions")

    fun list(context: Context): List<Extension> =
        (root(context).listFiles() ?: emptyArray()).filter { it.isDirectory }
            .mapNotNull { parse(it).first }
            .sortedBy { it.name.lowercase() }

    /** Все сниппеты установленных расширений: метка → текст вставки. */
    fun snippets(context: Context): List<Pair<String, String>> = list(context).flatMap { it.snippets }

    fun remove(context: Context, id: String) {
        if (!ID_RE.matches(id)) return
        File(root(context), id).deleteRecursively()
    }

    private fun parse(dir: File): Pair<Extension?, String?> {
        val f = File(dir, "extension.json")
        if (!f.isFile || f.length() > 200_000) return null to "Нет extension.json (или он слишком большой)."
        return try {
            val j = JSONObject(f.readText())
            val id = j.optString("id")
            if (!ID_RE.matches(id)) return null to "Неверный id: строчные латинские буквы, цифры, точка, дефис, подчёркивание."
            val snippets = ArrayList<Pair<String, String>>()
            j.optJSONArray("snippets")?.let { arr ->
                for (i in 0 until minOf(arr.length(), MAX_SNIPPETS)) {
                    val o = arr.optJSONObject(i) ?: continue
                    val label = o.optString("label").trim()
                    val insert = o.optString("insert")
                    if (label.isNotEmpty() && label.length <= 40 && insert.isNotEmpty() && insert.length <= 4000) {
                        snippets.add(label to insert)
                    }
                }
            }
            val templates = ArrayList<Pair<String, String>>()
            j.optJSONArray("templates")?.let { arr ->
                for (i in 0 until minOf(arr.length(), 20)) {
                    val o = arr.optJSONObject(i) ?: continue
                    val name = o.optString("name").trim().take(60)
                    val tdir = o.optString("dir")
                    if (name.isNotEmpty() && tdir.isNotEmpty()) templates.add(name to tdir)
                }
            }
            Extension(
                id = id,
                name = j.optString("name", id).take(60).ifBlank { id },
                version = j.optString("version", "").take(20),
                description = j.optString("description", "").take(300),
                snippets = snippets,
                templates = templates,
                dir = dir,
            ) to null
        } catch (e: Exception) {
            null to "extension.json повреждён: ${e.message}"
        }
    }

    /** Безопасная распаковка: без выхода за пределы папки, с ограничением размера и числа файлов. */
    private fun unzip(input: InputStream, target: File): String? {
        val base = target.canonicalFile
        var total = 0L
        var entries = 0
        ZipInputStream(input.buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                if (++entries > MAX_ENTRIES) return "В архиве слишком много файлов."
                val name = e.name.replace('\\', '/')
                if (name.startsWith("__MACOSX/") || name.startsWith("/") || name.split('/').any { it == ".." }) {
                    if (name.startsWith("__MACOSX/")) continue
                    return "Небезопасный путь в архиве: $name"
                }
                val out = File(base, name).canonicalFile
                if (!out.path.startsWith(base.path + File.separator) && out != base) return "Небезопасный путь в архиве: $name"
                if (e.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile?.mkdirs()
                out.outputStream().use { o ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = zin.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_ZIP_BYTES) return "Архив слишком большой после распаковки."
                        o.write(buf, 0, n)
                    }
                }
            }
        }
        return null
    }

    /** Устанавливает расширение из zip. Возвращает расширение или текст ошибки. */
    fun install(context: Context, input: InputStream): Pair<Extension?, String?> {
        val work = File(context.cacheDir, "ext-" + System.nanoTime()).apply { mkdirs() }
        try {
            unzip(input, work)?.let { return null to it }
            var src = work
            if (!File(src, "extension.json").isFile) {
                val subs = work.listFiles()?.filter { it.isDirectory } ?: emptyList()
                if (subs.size == 1 && File(subs[0], "extension.json").isFile) src = subs[0]
                else return null to "В архиве нет extension.json."
            }
            val (ext, err) = parse(src)
            if (ext == null) return null to err
            val dest = File(root(context), ext.id)
            root(context).mkdirs()
            dest.deleteRecursively()
            if (!src.copyRecursively(dest, overwrite = true)) return null to "Не удалось сохранить расширение."
            return parse(dest).first to null
        } catch (e: Exception) {
            return null to "Не удалось установить: ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            work.deleteRecursively()
        }
    }

    /** Скачивает zip по https (до 30 МБ) и устанавливает. */
    fun installFromUrl(context: Context, url: String): Pair<Extension?, String?> {
        if (!url.startsWith("https://")) return null to "Нужна ссылка https://…"
        val tmp = File(context.cacheDir, "ext-download-" + System.nanoTime() + ".zip")
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = true
            if (c.responseCode != 200) return null to "Сервер ответил: ${c.responseCode}"
            var total = 0L
            c.inputStream.use { i ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = i.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_ZIP_BYTES) return null to "Файл больше 30 МБ."
                        o.write(buf, 0, n)
                    }
                }
            }
            return tmp.inputStream().use { install(context, it) }
        } catch (e: Exception) {
            return null to "Не удалось скачать: ${e.javaClass.simpleName}: ${e.message}"
        } finally {
            tmp.delete()
        }
    }

    /** Создаёт проект из шаблона расширения. Возвращает папку проекта или текст ошибки. */
    fun createProject(context: Context, ext: Extension, templateDir: String, name: String, projectsDir: File): Pair<File?, String?> {
        if (!NAME_RE.matches(name)) return null to "Имя проекта: латиница, цифры, точка, дефис, подчёркивание."
        val target = File(projectsDir, name)
        if (target.exists()) return null to "Проект с таким именем уже есть."
        val extRoot = ext.dir.canonicalFile
        val src = File(extRoot, templateDir).canonicalFile
        if (!src.path.startsWith(extRoot.path + File.separator) || !src.isDirectory) return null to "Папка шаблона не найдена в расширении."
        return try {
            if (!src.copyRecursively(target, overwrite = false)) {
                target.deleteRecursively()
                null to "Не удалось скопировать шаблон."
            } else target to null
        } catch (e: Exception) {
            target.deleteRecursively()
            null to "Не удалось создать проект: ${e.message}"
        }
    }
}

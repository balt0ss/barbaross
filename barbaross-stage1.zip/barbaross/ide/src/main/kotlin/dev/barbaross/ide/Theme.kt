package dev.barbaross.ide

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Скругление кнопок и полей в стиле IntelliJ: небольшое, не «таблетка». */
internal val IdeShape = RoundedCornerShape(6.dp)

// Тёмная тема в духе IntelliJ IDEA (New UI Dark): редактор 1E1F22, панели 2B2D30, акцент 3574F0.
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF3574F0),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2E436E),
    onPrimaryContainer = Color(0xFFDFE1E5),
    secondary = Color(0xFF6F737A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2E436E),
    onSecondaryContainer = Color(0xFFDFE1E5),
    tertiary = Color(0xFF5FB865),
    onTertiary = Color.Black,
    background = Color(0xFF1E1F22),
    onBackground = Color(0xFFDFE1E5),
    surface = Color(0xFF2B2D30),
    onSurface = Color(0xFFDFE1E5),
    surfaceVariant = Color(0xFF393B40),
    onSurfaceVariant = Color(0xFF9DA0A8),
    surfaceTint = Color(0xFF3574F0),
    error = Color(0xFFF75464),
    onError = Color.White,
    errorContainer = Color(0xFF5A2A30),
    onErrorContainer = Color(0xFFFFDAD9),
    outline = Color(0xFF4E5157),
    outlineVariant = Color(0xFF393B40),
    surfaceBright = Color(0xFF393B40),
    surfaceDim = Color(0xFF1E1F22),
    surfaceContainerLowest = Color(0xFF1E1F22),
    surfaceContainerLow = Color(0xFF25262A),
    surfaceContainer = Color(0xFF2B2D30),
    surfaceContainerHigh = Color(0xFF313338),
    surfaceContainerHighest = Color(0xFF393B40),
)

// Светлая тема в духе IntelliJ IDEA (New UI Light).
private val LightScheme = lightColorScheme(
    primary = Color(0xFF3574F0),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4E2FF),
    onPrimaryContainer = Color(0xFF1E1F22),
    secondary = Color(0xFF6C707E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD4E2FF),
    onSecondaryContainer = Color(0xFF1E1F22),
    tertiary = Color(0xFF208A3C),
    onTertiary = Color.White,
    background = Color(0xFFF7F8FA),
    onBackground = Color(0xFF1E1F22),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1E1F22),
    surfaceVariant = Color(0xFFEBECF0),
    onSurfaceVariant = Color(0xFF6C707E),
    surfaceTint = Color(0xFF3574F0),
    error = Color(0xFFDB5860),
    onError = Color.White,
    errorContainer = Color(0xFFFAD4D8),
    onErrorContainer = Color(0xFF5A1A20),
    outline = Color(0xFFC9CCD6),
    outlineVariant = Color(0xFFEBECF0),
    surfaceBright = Color(0xFFFFFFFF),
    surfaceDim = Color(0xFFEBECF0),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF7F8FA),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFF2F3F5),
    surfaceContainerHighest = Color(0xFFEBECF0),
)

private val Base = Typography()

// Мельче, как в IDE: основной текст 13–14 sp.
private val IdeTypography = Typography(
    bodyLarge = Base.bodyLarge.copy(fontSize = 14.sp, lineHeight = 20.sp),
    bodyMedium = Base.bodyMedium.copy(fontSize = 13.sp, lineHeight = 18.sp),
    bodySmall = Base.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = Base.labelLarge.copy(fontSize = 13.sp, lineHeight = 18.sp),
    titleLarge = Base.titleLarge.copy(fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium = Base.titleMedium.copy(fontSize = 15.sp, lineHeight = 20.sp),
    titleSmall = Base.titleSmall.copy(fontSize = 13.sp, lineHeight = 18.sp),
)

private val IdeShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(10.dp),
    extraLarge = RoundedCornerShape(12.dp),
)

@Composable
fun BarbarossTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkScheme else LightScheme,
        typography = IdeTypography,
        shapes = IdeShapes,
        content = content,
    )
}

package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/**
 * Терминал: одна команда за раз (`sh -c`) в каталоге выбранного проекта. В PATH есть java, git, gradle и инструменты Termux.
 * Ввода с клавиатуры в запущенную программу нет.
 */
@Composable
fun TerminalScreen(runtime: RuntimeClient, state: RuntimeState, ws: Workspace) {
    val context = LocalContext.current
    val connected = state is RuntimeState.Connected
    val scope = rememberCoroutineScope()
    var command by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var next by remember { mutableLongStateOf(0L) }
    var pollKey by remember { mutableIntStateOf(0) }
    var exitCode by remember { mutableStateOf<Int?>(null) }
    var started by remember { mutableStateOf(false) }
    val history = remember { mutableStateListOf<String>() }
    val dir = ws.selectedProject ?: File(context.filesDir, "projects").apply { mkdirs() }

    LaunchedEffect(connected, pollKey) {
        if (!connected) return@LaunchedEffect
        while (true) {
            val r = runtime.invoke("term.read", Bundle().apply { putLong("offset", next) })
            if (r.getString("error") != null) break
            val t = r.getString("text").orEmpty()
            if (t.isNotEmpty()) output = (output + t).takeLast(30_000)
            next = r.getLong("next")
            running = r.getBoolean("running")
            if (!running) {
                if (started) exitCode = r.getInt("exit")
                if (t.isEmpty()) break
            }
            delay(400)
        }
    }

    fun run(cmd: String) {
        if (cmd.isBlank() || running) return
        scope.launch {
            val r = runtime.invoke(
                "term.start",
                Bundle().apply {
                    putString("dir", dir.absolutePath)
                    putString("command", cmd)
                },
            )
            val err = r.getString("error")
            if (err != null) {
                output = err + "\n"
            } else {
                history.remove(cmd)
                history.add(0, cmd)
                if (history.size > 10) history.removeAt(history.size - 1)
                output = "$ $cmd\n"
                next = 0L
                exitCode = null
                started = true
                running = true
                pollKey++
            }
        }
    }

    Text("Каталог: ${dir.name}", style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(
        value = command,
        onValueChange = { command = it },
        label = { Text("Команда (sh)") },
        singleLine = true,
        modifier = Modifier,
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = connected && !running && command.isNotBlank(), onClick = { run(command) }) { Text("Выполнить") }
        OutlinedButton(enabled = running, onClick = { scope.launch { runtime.invoke("term.stop") } }) { Text("Остановить") }
        OutlinedButton(onClick = { output = ""; exitCode = null }) { Text("Очистить") }
    }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("java -version", "git --version", "ls -la", "gradle --version").forEach { c ->
            OutlinedButton(enabled = !running, onClick = { command = c }) { Text(c) }
        }
        history.forEach { c ->
            OutlinedButton(enabled = !running, onClick = { command = c }) { Text(c.take(30)) }
        }
    }
    if (running) Text("Выполняется…", style = MaterialTheme.typography.bodySmall)
    exitCode?.let { if (!running) Text("Код выхода: $it", style = MaterialTheme.typography.bodySmall) }
    if (output.isNotEmpty()) {
        SelectionContainer {
            Text(output, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }
    } else if (!connected) {
        Text("Нет соединения с сервисом сборки.")
    }
}

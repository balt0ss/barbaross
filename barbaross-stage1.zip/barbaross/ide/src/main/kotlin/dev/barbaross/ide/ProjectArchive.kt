package dev.barbaross.ide

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Импорт проекта из zip и экспорт проекта в zip. Выполняется вне главного потока. */
object ProjectArchive {
    class ImportResult(val dir: File?, val error: String?)

    private const val MAX_ENTRIES = 50_000
    private const val MAX_BYTES = 1L * 1024 * 1024 * 1024
    private val SKIP_ROOT = setOf("build", ".gradle", ".idea")

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }

    fun importZip(context: Context, uri: Uri, projectsDir: File): ImportResult {
        // Проход 1: имена записей — определить общий корневой каталог архива.
        val names = ArrayList<String>()
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return ImportResult(null, "Не удалось открыть файл.")
            input.use { raw ->
                ZipInputStream(raw.buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        names.add(e.name)
                        if (names.size > MAX_ENTRIES) return ImportResult(null, "Слишком много файлов в архиве.")
                    }
                }
            }
        } catch (e: Exception) {
            return ImportResult(null, "Не удалось прочитать архив: ${e.message}")
        }
        val real = names.filter { !it.startsWith("__MACOSX/") && it.isNotEmpty() }
        if (real.isEmpty()) return ImportResult(null, "Архив пуст.")
        val tops = real.map { it.substringBefore('/') }.toSet()
        val strip = if (tops.size == 1 && real.all { '/' in it }) tops.single() + "/" else ""
        val baseName = if (strip.isNotEmpty()) tops.single() else (displayName(context, uri) ?: "project").removeSuffix(".zip")
        val safeName = baseName.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('.', '_').ifEmpty { "project" }

        projectsDir.mkdirs()
        var dir = File(projectsDir, safeName)
        var n = 2
        while (dir.exists()) {
            dir = File(projectsDir, "$safeName$n")
            n++
        }
        dir.mkdirs()
        val dirPath = dir.toPath().toAbsolutePath().normalize()

        // Проход 2: распаковка с защитой от выхода за пределы каталога и от zip-бомб.
        var total = 0L
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return ImportResult(null, "Не удалось открыть файл.")
            input.use { raw ->
                ZipInputStream(raw.buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        if (e.name.startsWith("__MACOSX/") || e.isDirectory) continue
                        val rel = e.name.removePrefix(strip)
                        if (rel.isEmpty() || rel.substringBefore('/') in SKIP_ROOT && '/' in rel) continue
                        val out = File(dir, rel)
                        if (!out.toPath().toAbsolutePath().normalize().startsWith(dirPath)) continue
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = z.read(buf)
                                if (r < 0) break
                                total += r
                                if (total > MAX_BYTES) throw IllegalStateException("архив распаковывается больше чем в 1 ГБ")
                                o.write(buf, 0, r)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            return ImportResult(null, "Не удалось распаковать: ${e.message}")
        }

        if (!File(dir, "settings.gradle").isFile && !File(dir, "settings.gradle.kts").isFile) {
            dir.deleteRecursively()
            return ImportResult(null, "В архиве не найден settings.gradle(.kts) в корне проекта.")
        }
        return ImportResult(dir, null)
    }

    /** Пишет проект в zip: каталоги build, .gradle, .idea и local.properties не включаются. */
    fun exportZip(project: File, out: OutputStream) {
        ZipOutputStream(out.buffered()).use { z ->
            project.walkTopDown()
                .onEnter { !Fs.isLink(it) && !(it.parentFile == project && it.name in SKIP_ROOT) }
                .forEach { f ->
                    if (f.isFile && !Fs.isLink(f) && f.name != "local.properties") {
                        z.putNextEntry(ZipEntry(project.name + "/" + f.relativeTo(project).invariantSeparatorsPath))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                    }
                }
        }
    }
}

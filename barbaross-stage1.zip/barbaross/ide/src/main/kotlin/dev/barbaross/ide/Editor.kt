package dev.barbaross.ide

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private class Loaded(val text: String?, val error: String?)

private fun loadText(f: File): Loaded {
    if (f.length() > 1_000_000) return Loaded(null, "Файл больше 1 МБ — в редакторе не открывается.")
    val bytes = f.readBytes()
    if (bytes.any { it == 0.toByte() }) return Loaded(null, "Похоже, файл двоичный — в редакторе не открывается.")
    return Loaded(String(bytes, Charsets.UTF_8), null)
}

/** Состояние редактора: текст, история отмены/повтора, признак несохранённых изменений. */
private class EditorState(initial: String) {
    var value by mutableStateOf(TextFieldValue(initial))
    var saved by mutableStateOf(initial)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    private val undoStack = ArrayList<TextFieldValue>()
    private val redoStack = ArrayList<TextFieldValue>()
    private var lastPush = 0L

    val dirty: Boolean get() = value.text != saved

    fun onChange(new: TextFieldValue) {
        val old = value
        if (new.text == old.text) {
            value = new // только выделение/курсор
            return
        }
        val edited = autoEdit(old, new)
        val now = System.currentTimeMillis()
        // Подряд идущий набор объединяем в один шаг отмены.
        if (undoStack.isEmpty() || now - lastPush > 700 || kotlin.math.abs(edited.text.length - old.text.length) > 1) {
            undoStack.add(old)
            if (undoStack.size > 200) undoStack.removeAt(0)
        }
        lastPush = now
        redoStack.clear()
        value = edited
        sync()
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(value)
        value = undoStack.removeAt(undoStack.size - 1)
        sync()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(value)
        value = redoStack.removeAt(redoStack.size - 1)
        sync()
    }

    private fun sync() {
        undoCount = undoStack.size
        redoCount = redoStack.size
    }
}

/** Автоотступ после Enter и автозакрытие скобок. */
private fun autoEdit(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    if (new.text.length != old.text.length + 1 || !new.selection.collapsed) return new
    val t = new.text
    val pos = new.selection.start
    if (pos < 1 || pos > t.length) return new
    return when (val ch = t[pos - 1]) {
        '\n' -> {
            val prevStart = t.lastIndexOf('\n', pos - 2) + 1
            val prev = t.substring(prevStart, pos - 1)
            val indent = prev.takeWhile { it == ' ' || it == '\t' }
            val trimmed = prev.trimEnd()
            val extra = if (trimmed.endsWith("{") || trimmed.endsWith("(")) "    " else ""
            val ins = indent + extra
            if (ins.isEmpty()) new else TextFieldValue(t.substring(0, pos) + ins + t.substring(pos), TextRange(pos + ins.length))
        }
        '(', '[', '{' -> {
            val close = when (ch) {
                '(' -> ')'
                '[' -> ']'
                else -> '}'
            }
            TextFieldValue(t.substring(0, pos) + close + t.substring(pos), TextRange(pos))
        }
        else -> new
    }
}

// ---------- подсветка синтаксиса ----------

private val KEYWORDS = setOf(
    "package", "import", "class", "interface", "object", "fun", "val", "var", "if", "else", "when", "for", "while", "do",
    "return", "break", "continue", "in", "is", "as", "try", "catch", "finally", "throw", "null", "true", "false", "this",
    "super", "override", "private", "public", "protected", "internal", "open", "abstract", "final", "sealed", "data", "enum",
    "companion", "suspend", "inline", "lateinit", "by", "typealias", "const", "static", "void", "int", "long", "boolean",
    "new", "extends", "implements", "def", "plugins", "android", "dependencies", "repositories",
)

private val CODE_RE = Regex(
    "(//[^\\n]*|/\\*[\\s\\S]*?\\*/)" +                                    // 1 комментарий
        "|(\"\"\"[\\s\\S]*?\"\"\"|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*')" + // 2 строка
        "|(\\b\\d[\\d_.]*[fFLl]?\\b)" +                                   // 3 число
        "|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)"                                 // 4 слово
)

private val XML_RE = Regex("(<!--[\\s\\S]*?-->)|(\"[^\"]*\")|(</?[A-Za-z][\\w:.-]*)")

private val C_KEYWORD = Color(0xFF0033B3)
private val C_STRING = Color(0xFF067D17)
private val C_COMMENT = Color(0xFF8C8C8C)
private val C_NUMBER = Color(0xFF1750EB)

private fun highlight(src: String, ext: String): AnnotatedString {
    if (src.length > 200_000) return AnnotatedString(src)
    val b = AnnotatedString.Builder(src)
    if (ext == "xml") {
        for (m in XML_RE.findAll(src)) {
            val color = when {
                m.groups[1] != null -> C_COMMENT
                m.groups[2] != null -> C_STRING
                else -> C_KEYWORD
            }
            b.addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
        }
    } else {
        for (m in CODE_RE.findAll(src)) {
            val color = when {
                m.groups[1] != null -> C_COMMENT
                m.groups[2] != null -> C_STRING
                m.groups[3] != null -> C_NUMBER
                else -> if (m.value in KEYWORDS) C_KEYWORD else null
            } ?: continue
            b.addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
        }
    }
    return b.toAnnotatedString()
}

private class Highlighter(private val ext: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(highlight(text.text, ext), OffsetMapping.Identity)
}

// ---------- экран редактора ----------

/** Редактор файла: номера строк, undo/redo, автоотступ и скобки, подсветка Kotlin/Java/Gradle/XML, защита от потери изменений. */
@Composable
fun EditorScreen(file: File, onClose: () -> Unit, onSaveAndBuild: () -> Unit) {
    val loaded = remember(file) { loadText(file) }
    val ed = remember(file) { EditorState(loaded.text.orEmpty()) }
    var message by remember(file) { mutableStateOf<String?>(null) }
    var confirmClose by remember(file) { mutableStateOf(false) }
    val ext = file.extension.lowercase()
    val highlighter = remember(ext) { Highlighter(ext) }
    val scroll = rememberScrollState()

    fun save(): Boolean = try {
        file.writeText(ed.value.text)
        ed.saved = ed.value.text
        message = "Сохранено"
        true
    } catch (e: Exception) {
        message = "Не удалось сохранить: ${e.message}"
        false
    }

    BackHandler(enabled = true) { if (loaded.error == null && ed.dirty) confirmClose = true else onClose() }

    if (loaded.error != null) {
        Text(file.name, style = MaterialTheme.typography.titleMedium)
        Text(loaded.error)
        Button(onClick = onClose) { Text("Назад") }
        return
    }

    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = { if (ed.dirty) confirmClose = true else onClose() }) { Text("← Назад") }
        TextButton(enabled = ed.undoCount > 0, onClick = { ed.undo() }) { Text("Отмена") }
        TextButton(enabled = ed.redoCount > 0, onClick = { ed.redo() }) { Text("Повтор") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = ed.dirty, onClick = { save() }) { Text("Сохранить") }
        OutlinedButton(onClick = { if (save()) onSaveAndBuild() }) { Text("Сохранить и собрать") }
    }
    Text(file.name + if (ed.dirty) " •" else "", style = MaterialTheme.typography.titleSmall)
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

    val codeStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 18.sp)
    val lines = ed.value.text.count { it == '\n' } + 1
    Row {
        Text(
            (1..lines).joinToString("\n"),
            style = codeStyle.copy(color = Color(0xFF9E9E9E), textAlign = TextAlign.End),
            modifier = Modifier.padding(end = 8.dp),
        )
        Box(Modifier.horizontalScroll(scroll)) {
            BasicTextField(
                value = ed.value,
                onValueChange = { ed.onChange(it) },
                textStyle = codeStyle.copy(color = MaterialTheme.colorScheme.onSurface),
                visualTransformation = highlighter,
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.widthIn(min = 240.dp),
            )
        }
    }

    if (confirmClose) {
        AlertDialog(
            onDismissRequest = { confirmClose = false },
            title = { Text("Несохранённые изменения") },
            text = { Text("Сохранить изменения в ${file.name}?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClose = false
                    if (save()) onClose()
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmClose = false; onClose() }) { Text("Не сохранять") }
                    TextButton(onClick = { confirmClose = false }) { Text("Отмена") }
                }
            },
        )
    }
}

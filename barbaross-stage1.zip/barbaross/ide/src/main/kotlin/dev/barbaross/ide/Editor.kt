package dev.barbaross.ide

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private class Loaded(val text: String?, val error: String?)

private fun loadText(f: File): Loaded {
    if (f.length() > 1_000_000) return Loaded(null, "Файл больше 1 МБ — в редакторе не открывается.")
    val bytes = f.readBytes()
    if (bytes.any { it == 0.toByte() }) return Loaded(null, "Похоже, файл двоичный — в редакторе не открывается.")
    return Loaded(String(bytes, Charsets.UTF_8), null)
}

/** Состояние редактора: текст, история отмены/повтора, признак несохранённых изменений. */
internal class EditorState(initial: String) {
    var value by mutableStateOf(TextFieldValue(initial))
    var saved by mutableStateOf(initial)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    private val undoStack = ArrayList<TextFieldValue>()
    private val redoStack = ArrayList<TextFieldValue>()
    private var lastPush = 0L

    val dirty: Boolean get() = value.text != saved

    fun onChange(new: TextFieldValue) {
        val old = value
        if (new.text == old.text) {
            value = new // только выделение/курсор
            return
        }
        val edited = autoEdit(old, new)
        val now = System.currentTimeMillis()
        // Подряд идущий набор объединяем в один шаг отмены.
        if (undoStack.isEmpty() || now - lastPush > 700 || kotlin.math.abs(edited.text.length - old.text.length) > 1) {
            pushUndo(old)
        }
        lastPush = now
        redoStack.clear()
        value = edited
        sync()
    }

    /** Замена текста целиком (поиск/замена): один шаг отмены, без автоправок. */
    fun replaceValue(new: TextFieldValue) {
        pushUndo(value)
        lastPush = 0L
        redoStack.clear()
        value = new
        sync()
    }

    fun moveCursor(offset: Int) {
        value = value.copy(selection = TextRange(offset.coerceIn(0, value.text.length)))
    }

    fun select(start: Int, end: Int) {
        value = value.copy(selection = TextRange(start, end))
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(value)
        value = undoStack.removeAt(undoStack.size - 1)
        sync()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(value)
        value = redoStack.removeAt(redoStack.size - 1)
        sync()
    }

    private fun pushUndo(v: TextFieldValue) {
        undoStack.add(v)
        if (undoStack.size > 200) undoStack.removeAt(0)
    }

    private fun sync() {
        undoCount = undoStack.size
        redoCount = redoStack.size
    }
}

/** Открытый файл: состояние редактора, сообщения, запрос перехода к строке. */
class EditorSession(val file: File) {
    private val loaded = loadText(file)
    val error: String? = loaded.error
    internal val state = EditorState(loaded.text.orEmpty())
    var requestedLine by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    internal var problems by mutableStateOf<List<CodeAssist.Problem>>(emptyList())

    fun save(): Boolean = try {
        file.writeText(state.value.text)
        state.saved = state.value.text
        message = "Сохранено"
        true
    } catch (e: Exception) {
        message = "Не удалось сохранить: ${e.message}"
        false
    }
}

/** Автоотступ после Enter и автозакрытие скобок. */
private fun autoEdit(old: TextFieldValue, new: TextFieldValue): TextFieldValue {
    if (new.text.length != old.text.length + 1 || !new.selection.collapsed) return new
    val t = new.text
    val pos = new.selection.start
    if (pos < 1 || pos > t.length) return new
    return when (val ch = t[pos - 1]) {
        '\n' -> {
            val prevStart = t.lastIndexOf('\n', pos - 2) + 1
            val prev = t.substring(prevStart, pos - 1)
            val indent = prev.takeWhile { it == ' ' || it == '\t' }
            val trimmed = prev.trimEnd()
            val extra = if (trimmed.endsWith("{") || trimmed.endsWith("(")) "    " else ""
            val ins = indent + extra
            if (ins.isEmpty()) new else TextFieldValue(t.substring(0, pos) + ins + t.substring(pos), TextRange(pos + ins.length))
        }
        '(', '[', '{' -> {
            val close = when (ch) {
                '(' -> ')'
                '[' -> ']'
                else -> '}'
            }
            TextFieldValue(t.substring(0, pos) + close + t.substring(pos), TextRange(pos))
        }
        else -> new
    }
}

/** Смещение начала строки line0 (с нуля). */
private fun lineOffset(text: String, line0: Int): Int {
    var idx = 0
    repeat(line0) {
        val n = text.indexOf('\n', idx)
        if (n < 0) return text.length
        idx = n + 1
    }
    return idx
}

// ---------- подсветка синтаксиса ----------

private val KEYWORDS = setOf(
    "package", "import", "class", "interface", "object", "fun", "val", "var", "if", "else", "when", "for", "while", "do",
    "return", "break", "continue", "in", "is", "as", "try", "catch", "finally", "throw", "null", "true", "false", "this",
    "super", "override", "private", "public", "protected", "internal", "open", "abstract", "final", "sealed", "data", "enum",
    "companion", "suspend", "inline", "lateinit", "by", "typealias", "const", "static", "void", "int", "long", "boolean",
    "new", "extends", "implements", "def", "plugins", "android", "dependencies", "repositories",
)

private val CODE_RE = Regex(
    "(//[^\\n]*|/\\*[\\s\\S]*?\\*/)" +                                    // 1 комментарий
        "|(\"\"\"[\\s\\S]*?\"\"\"|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*')" + // 2 строка
        "|(\\b\\d[\\d_.]*[fFLl]?\\b)" +                                   // 3 число
        "|(@[A-Za-z_][A-Za-z0-9_]*)" +                                      // 4 аннотация
        "|(\\b[A-Za-z_][A-Za-z0-9_]*\\b)"                                 // 5 слово
)

private val XML_RE = Regex("(<!--[\\s\\S]*?-->)|(\"[^\"]*\")|(</?[A-Za-z][\\w:.-]*)")

private class SyntaxColors(
    val keyword: Color,
    val string: Color,
    val comment: Color,
    val number: Color,
    val annotation: Color,
    val function: Color,
)

// Цвета как в IntelliJ IDEA: светлая схема и тёмная (New UI Dark).
private val LIGHT_COLORS = SyntaxColors(Color(0xFF0033B3), Color(0xFF067D17), Color(0xFF8C8C8C), Color(0xFF1750EB), Color(0xFF9E880D), Color(0xFF00627A))
private val DARK_COLORS = SyntaxColors(Color(0xFFCF8E6D), Color(0xFF6AAB73), Color(0xFF7A7E85), Color(0xFF2AACB8), Color(0xFFB3AE60), Color(0xFF56A8F5))

private fun highlight(src: String, ext: String, dark: Boolean): AnnotatedString {
    val c = if (dark) DARK_COLORS else LIGHT_COLORS
    if (src.length > 200_000) return AnnotatedString(src)
    val b = AnnotatedString.Builder(src)
    if (ext == "xml") {
        for (m in XML_RE.findAll(src)) {
            val color = when {
                m.groups[1] != null -> c.comment
                m.groups[2] != null -> c.string
                else -> c.keyword
            }
            b.addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
        }
    } else {
        for (m in CODE_RE.findAll(src)) {
            val color = when {
                m.groups[1] != null -> c.comment
                m.groups[2] != null -> c.string
                m.groups[3] != null -> c.number
                m.groups[4] != null -> c.annotation
                else -> when {
                    m.value in KEYWORDS -> c.keyword
                    src.getOrNull(m.range.last + 1) == '(' -> c.function
                    else -> null
                }
            } ?: continue
            b.addStyle(SpanStyle(color = color), m.range.first, m.range.last + 1)
        }
    }
    return b.toAnnotatedString()
}

private class Highlighter(private val ext: String, private val dark: Boolean) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(highlight(text.text, ext, dark), OffsetMapping.Identity)
}

// ---------- вкладки открытых файлов ----------

@Composable
fun EditorTabs(ws: Workspace) {
    var closing by remember { mutableStateOf<EditorSession?>(null) }
    val accent = MaterialTheme.colorScheme.primary
    // Полоса вкладок: активная подчёркнута акцентным цветом, у каждой свой крестик.
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).horizontalScroll(rememberScrollState())) {
        ws.sessions.forEach { s ->
            val active = s == ws.active
            Column(Modifier.width(IntrinsicSize.Max).clickable { ws.active = s }) {
                Row(Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        s.file.name + if (s.state.dirty) " •" else "",
                        color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                    )
                    Text(
                        "✕",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { if (s.state.dirty) closing = s else ws.close(s) }.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
                Box(Modifier.fillMaxWidth().height(2.dp).background(if (active) accent else Color.Transparent))
            }
        }
    }
    closing?.let { s ->
        AlertDialog(
            onDismissRequest = { closing = null },
            title = { Text("Несохранённые изменения") },
            text = { Text("Сохранить изменения в ${s.file.name}?") },
            confirmButton = {
                TextButton(onClick = {
                    closing = null
                    if (s.save()) ws.close(s)
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { closing = null; ws.close(s) }) { Text("Не сохранять") }
                    TextButton(onClick = { closing = null }) { Text("Отмена") }
                }
            },
        )
    }
}

// ---------- экран редактора ----------

/** Редактор файла: номера строк, undo/redo, поиск/замена, автоотступ и скобки, подсветка, переход к строке. */
@Composable
fun EditorScreen(session: EditorSession, onSaveAndBuild: () -> Unit, onShowProblems: () -> Unit) {
    val ed = session.state
    if (session.error != null) {
        Text(session.file.name, style = MaterialTheme.typography.titleMedium)
        Text(session.error)
        return
    }

    Column(Modifier.fillMaxSize()) {
    val ext = session.file.extension.lowercase()
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val highlighter = remember(ext, dark) { Highlighter(ext, dark) }
    val vscroll = rememberScrollState()
    val hscroll = rememberScrollState()
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }
    var showFind by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var findMessage by remember { mutableStateOf<String?>(null) }

    val appContext = LocalContext.current
    var fontSize by remember { mutableIntStateOf(AppPrefs.fontSize(appContext)) }
    val codeStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = fontSize.sp, lineHeight = (fontSize * 1.4f).sp)
    val lineHeightPx = with(LocalDensity.current) { (fontSize * 1.4f).sp.toPx() }
    var showTools by remember { mutableStateOf(false) }

    fun scrollToLine(line0: Int) {
        scope.launch { vscroll.scrollTo(((line0 - 3).coerceAtLeast(0) * lineHeightPx).toInt()) }
    }

    fun find() {
        if (query.isEmpty()) return
        val t = ed.value.text
        var i = t.indexOf(query, ed.value.selection.end, ignoreCase = true)
        var wrapped = false
        if (i < 0) {
            i = t.indexOf(query, 0, ignoreCase = true)
            wrapped = true
        }
        if (i < 0) {
            findMessage = "Не найдено"
            return
        }
        ed.select(i, i + query.length)
        findMessage = if (wrapped) "Поиск с начала файла" else null
        scrollToLine(t.substring(0, i).count { it == '\n' })
        try { focus.requestFocus() } catch (_: Exception) {}
    }

    fun replaceCurrent() {
        val v = ed.value
        val sel = v.selection
        if (query.isNotEmpty() && !sel.collapsed && v.text.substring(sel.min, sel.max).equals(query, ignoreCase = true)) {
            val newText = v.text.substring(0, sel.min) + repl + v.text.substring(sel.max)
            ed.replaceValue(TextFieldValue(newText, TextRange(sel.min + repl.length)))
        }
        find()
    }

    fun replaceAll() {
        if (query.isEmpty()) return
        val re = Regex(Regex.escape(query), RegexOption.IGNORE_CASE)
        val t = ed.value.text
        val count = re.findAll(t).count()
        if (count == 0) {
            findMessage = "Не найдено"
            return
        }
        ed.replaceValue(TextFieldValue(re.replace(t) { repl }, TextRange(0)))
        findMessage = "Заменено: $count"
    }

    LaunchedEffect(session.requestedLine) {
        val line = session.requestedLine
        if (line > 0) {
            ed.moveCursor(lineOffset(ed.value.text, line - 1))
            delay(150) // дождаться раскладки, чтобы прокрутка не обрезалась до нуля
            vscroll.scrollTo(((line - 4).coerceAtLeast(0) * lineHeightPx).toInt())
            session.requestedLine = 0
        }
    }

    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Button(enabled = ed.dirty, onClick = { session.save() }) { Text("Сохранить") }
        Button(
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3F8F4A), contentColor = Color.White),
            onClick = { if (session.save()) onSaveAndBuild() },
        ) { Text("▶ Собрать") }
        TextButton(enabled = ed.undoCount > 0, onClick = { ed.undo() }) { Text("↶ Отмена") }
        TextButton(enabled = ed.redoCount > 0, onClick = { ed.redo() }) { Text("↷ Повтор") }
        TextButton(onClick = { showTools = !showTools }) { Text(if (showTools) "Меньше ▴" else "Ещё ▾") }
    }
    session.message?.let { Text(it, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 10.dp)) }

    var showGoto by remember { mutableStateOf(false) }
    var gotoText by remember { mutableStateOf("") }
    val canComment = ext in CodeAssist.CODE_EXT
    fun focusEditor() {
        try { focus.requestFocus() } catch (_: Exception) {}
    }
    if (showTools) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        TextButton(onClick = { showFind = !showFind }) { Text(if (showFind) "Скрыть поиск" else "Поиск") }
        TextButton(onClick = { gotoText = ""; showGoto = true }) { Text("К строке") }
        TextButton(enabled = canComment, onClick = { EditorOps.toggleComment(ed); focusEditor() }) { Text("Комментарий") }
        TextButton(onClick = { EditorOps.indent(ed); focusEditor() }) { Text("Отступ →") }
        TextButton(onClick = { EditorOps.outdent(ed); focusEditor() }) { Text("← Отступ") }
        TextButton(onClick = { EditorOps.duplicateLine(ed); focusEditor() }) { Text("Дубль строки") }
        TextButton(onClick = { fontSize = (fontSize - 1).coerceAtLeast(9); AppPrefs.setFontSize(appContext, fontSize) }) { Text("A−") }
        TextButton(onClick = { fontSize = (fontSize + 1).coerceAtMost(26); AppPrefs.setFontSize(appContext, fontSize) }) { Text("A+") }
    }
    if (showGoto) {
        AlertDialog(
            onDismissRequest = { showGoto = false },
            title = { Text("Перейти к строке") },
            text = {
                OutlinedTextField(
                    value = gotoText,
                    onValueChange = { gotoText = it.filter { c -> c.isDigit() }.take(7) },
                    singleLine = true,
                    label = { Text("Номер строки") },
                )
            },
            confirmButton = {
                TextButton(enabled = gotoText.isNotEmpty(), onClick = {
                    val total = ed.value.text.count { it == '\n' } + 1
                    val n = (gotoText.toIntOrNull() ?: 1).coerceIn(1, total)
                    showGoto = false
                    ed.moveCursor(lineOffset(ed.value.text, n - 1))
                    scrollToLine(n - 1)
                    focusEditor()
                }) { Text("Перейти") }
            },
            dismissButton = { TextButton(onClick = { showGoto = false }) { Text("Отмена") } },
        )
    }

    if (showFind) {
        OutlinedTextField(value = query, onValueChange = { query = it }, singleLine = true, label = { Text("Найти") })
        OutlinedTextField(value = repl, onValueChange = { repl = it }, singleLine = true, label = { Text("Заменить на") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { find() }) { Text("Далее") }
            OutlinedButton(onClick = { replaceCurrent() }) { Text("Заменить") }
            OutlinedButton(onClick = { replaceAll() }) { Text("Все") }
        }
        findMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }

    val isCode = ext in CodeAssist.CODE_EXT
    LaunchedEffect(ed.value.text, isCode) {
        if (!isCode) {
            session.problems = emptyList()
        } else {
            delay(500)
            val t = ed.value.text
            session.problems = withContext(Dispatchers.Default) { CodeAssist.check(t) }
        }
    }
    val extraSnippets = remember(session) { ExtensionManager.snippets(appContext) }
    val suggestions = if (isCode) CodeAssist.suggest(ed.value.text, ed.value.selection, extraSnippets) else emptyList()
    if (suggestions.isNotEmpty()) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            suggestions.forEach { sg ->
                OutlinedButton(onClick = {
                    ed.replaceValue(CodeAssist.apply(ed.value, sg))
                    try { focus.requestFocus() } catch (_: Exception) {}
                }) { Text(sg.label) }
            }
        }
    }

    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        OutlinedButton(contentPadding = PaddingValues(horizontal = 14.dp), onClick = { EditorOps.insert(ed, "    "); focusEditor() }) { Text("Tab") }
        listOf(
            "{", "}", "(", ")", "[", "]", ";", "\"", "=", ":", ".", ",", "<", ">", "/", "!", "?", "&", "|", "$", "_", "-", "+", "*", "#", "@", "'", "\\",
        ).forEach { s ->
            OutlinedButton(contentPadding = PaddingValues(horizontal = 14.dp), onClick = { EditorOps.insert(ed, s); focusEditor() }) { Text(s) }
        }
    }

    val lines = ed.value.text.count { it == '\n' } + 1
    Box(Modifier.fillMaxWidth().weight(1f).verticalScroll(vscroll)) {
        Row {
            Text(
                (1..lines).joinToString("\n"),
                style = codeStyle.copy(color = if (dark) Color(0xFF6F737A) else Color(0xFFA0A3AB), textAlign = TextAlign.End),
                modifier = Modifier.padding(end = 8.dp),
            )
            Box(Modifier.horizontalScroll(hscroll)) {
                BasicTextField(
                    value = ed.value,
                    onValueChange = { ed.onChange(it) },
                    textStyle = codeStyle.copy(color = MaterialTheme.colorScheme.onSurface),
                    visualTransformation = highlighter,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.widthIn(min = 240.dp).focusRequester(focus),
                )
            }
        }
    }

    // Строка состояния как в IDE: позиция курсора, кодировка, язык.
    run {
        val text = ed.value.text
        val off = ed.value.selection.start.coerceIn(0, text.length)
        val before = text.substring(0, off)
        val curLine = before.count { it == '\n' } + 1
        val curCol = off - (before.lastIndexOf('\n') + 1) + 1
        val language = when (ext) {
            "kt" -> "Kotlin"
            "kts" -> "Kotlin Script"
            "java" -> "Java"
            "xml" -> "XML"
            "gradle" -> "Gradle"
            "json" -> "JSON"
            "md" -> "Markdown"
            else -> "Текст"
        }
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("$curLine:$curCol", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("UTF-8", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(language, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (session.problems.isNotEmpty()) {
                Text(
                    "⚠ ${session.problems.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.clickable { onShowProblems() },
                )
            }
        }
    }
    }
}

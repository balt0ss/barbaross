package dev.barbaross.ide

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import dev.barbaross.runtime.ProjectTemplates
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun listProjects(dir: File): List<File> =
    dir.listFiles { f -> f.isDirectory }?.sortedBy { it.name } ?: emptyList()

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Проекты в filesDir/projects: шаблон, файлы, редактор с вкладками, сборка Gradle с логом и ссылками на ошибки. */
@Composable
fun ProjectsScreen(runtime: RuntimeClient, state: RuntimeState, ws: Workspace) {
    val context = LocalContext.current
    val projectsDir = remember { File(context.filesDir, "projects").apply { mkdirs() } }
    var projects by remember { mutableStateOf(listProjects(projectsDir)) }
    var newName by remember { mutableStateOf("hello") }
    var showExit by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var ioMessage by remember { mutableStateOf<String?>(null) }
    var ioBusy by remember { mutableStateOf(false) }
    var exportProject by remember { mutableStateOf<File?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            ioBusy = true
            ioMessage = "Импортирую…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { ProjectArchive.importZip(context, uri, projectsDir) }
                ioBusy = false
                val dir = r.dir
                if (dir != null) {
                    ws.selectedProject = dir
                    ws.tab = 0
                    projects = listProjects(projectsDir)
                    ioMessage = "Импортировано: ${dir.name}"
                } else {
                    ioMessage = r.error
                }
            }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val p = exportProject
        if (uri != null && p != null) {
            scope.launch {
                ioMessage = withContext(Dispatchers.IO) {
                    try {
                        val out = context.contentResolver.openOutputStream(uri) ?: return@withContext "Не удалось открыть файл для записи."
                        out.use { ProjectArchive.exportZip(p, it) }
                        "Проект экспортирован: ${p.name}.zip"
                    } catch (e: Exception) {
                        "Не удалось экспортировать: ${e.message}"
                    }
                }
            }
        }
    }

    // Выход из приложения с несохранёнными файлами — только после подтверждения.
    BackHandler(enabled = ws.anyDirty()) { showExit = true }

    Text("Новый проект (Kotlin + Compose)")
    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Имя") }, singleLine = true)
    Button(onClick = {
        ws.selectedProject = ProjectTemplates.createComposeApp(projectsDir, newName)
        ws.tab = 0
        projects = listProjects(projectsDir)
    }) { Text("Создать проект") }

    OutlinedButton(enabled = !ioBusy, onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Импортировать проект (zip)") }
    ioMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

    if (projects.isEmpty()) {
        Text("Проектов пока нет.")
    } else {
        Text("Проекты", style = MaterialTheme.typography.titleMedium)
        projects.forEach { p ->
            TextButton(onClick = { ws.selectedProject = p; ws.tab = 0 }) {
                Text(if (p == ws.selectedProject) "▶ ${p.name}" else p.name)
            }
        }
    }

    ws.selectedProject?.let { project ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Файлы", "Редактор", "Сборка").forEachIndexed { i, title ->
                val index = intArrayOf(0, 2, 1)[i] // порядок вкладок: файлы, редактор, сборка
                if (ws.tab == index) Button(onClick = { ws.tab = index }) { Text(title) }
                else OutlinedButton(onClick = { ws.tab = index }) { Text(title) }
            }
        }
        OutlinedButton(onClick = {
            exportProject = project
            exportLauncher.launch(project.name + ".zip")
        }) { Text("Экспортировать проект (zip)") }
        when (ws.tab) {
            0 -> FileBrowser(project, onOpen = { ws.open(it) })
            2 -> {
                if (ws.sessions.isEmpty()) {
                    Text("Откройте файл на вкладке «Файлы».")
                } else {
                    EditorTabs(ws)
                    ws.active?.let { s ->
                        key(s) { EditorScreen(s, onSaveAndBuild = { ws.tab = 1; ws.pendingBuild = true }) }
                    }
                }
            }
            else -> BuildPanel(
                runtime, state, project,
                pendingBuild = ws.pendingBuild,
                onPendingConsumed = { ws.pendingBuild = false },
                onOpenIssue = { file, line -> ws.open(file, line) },
            )
        }
    }

    if (showExit) {
        AlertDialog(
            onDismissRequest = { showExit = false },
            title = { Text("Несохранённые изменения") },
            text = { Text("Есть несохранённые файлы. Сохранить их перед выходом?") },
            confirmButton = {
                TextButton(onClick = {
                    showExit = false
                    if (ws.saveAll()) context.findActivity()?.finish()
                }) { Text("Сохранить и выйти") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { showExit = false; context.findActivity()?.finish() }) { Text("Выйти без сохранения") }
                    TextButton(onClick = { showExit = false }) { Text("Отмена") }
                }
            },
        )
    }
}

// ---------- ошибки сборки ----------

private class BuildIssue(val file: File, val line: Int, val message: String)

private val ISSUE_RE = Regex("""^(?:ERROR: |e: |w: )?(?:file://)?(/\S+?\.(?:kt|kts|java|xml|gradle)):(\d+)(?::\d+)?:?\s*(.*)$""")

/** Разбор строки лога: Kotlin («e: file:///…/X.kt:12:5 …»), javac и aapt («/…/X.java:10: error: …»). */
private fun parseIssue(raw: String, project: File): BuildIssue? {
    val line = raw.trim()
    val isError = line.startsWith("e: ") || line.startsWith("ERROR: ") || line.contains(" error: ")
    if (!isError) return null
    val m = ISSUE_RE.find(line) ?: return null
    return try {
        val f = File(m.groupValues[1])
        val root = project.canonicalPath
        if (!f.canonicalPath.startsWith(root + File.separator) || !f.isFile) return null
        BuildIssue(f, m.groupValues[2].toIntOrNull() ?: 1, m.groupValues[3].removePrefix("error: ").take(200))
    } catch (e: Exception) {
        null
    }
}

@Composable
private fun BuildPanel(
    runtime: RuntimeClient,
    state: RuntimeState,
    project: File,
    pendingBuild: Boolean,
    onPendingConsumed: () -> Unit,
    onOpenIssue: (File, Int) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var building by remember(project) { mutableStateOf(false) }
    var logText by remember(project) { mutableStateOf("") }
    var result by remember(project) { mutableStateOf<String?>(null) }
    var apk by remember(project) { mutableStateOf<String?>(null) }
    var issues by remember(project) { mutableStateOf<List<BuildIssue>>(emptyList()) }
    var saveMessage by remember(project) { mutableStateOf<String?>(null) }
    val apkSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.android.package-archive"),
    ) { uri ->
        val path = apk
        if (uri != null && path != null) {
            scope.launch {
                saveMessage = withContext(Dispatchers.IO) {
                    try {
                        val out = context.contentResolver.openOutputStream(uri) ?: return@withContext "Не удалось открыть файл для записи."
                        out.use { o -> File(path).inputStream().use { it.copyTo(o) } }
                        "APK сохранён"
                    } catch (e: Exception) {
                        "Не удалось сохранить APK: ${e.message}"
                    }
                }
            }
        }
    }
    val connected = state is RuntimeState.Connected

    suspend fun follow() {
        building = true
        var offset = 0
        val sb = StringBuilder()
        var carry = ""
        val found = ArrayList<BuildIssue>()

        fun scan(text: String) {
            val parts = (carry + text).split('\n')
            carry = parts.last()
            for (line in parts.dropLast(1)) {
                val issue = parseIssue(line, project) ?: continue
                if (found.size < 30 && found.none { it.file == issue.file && it.line == issue.line && it.message == issue.message }) {
                    found.add(issue)
                }
            }
            issues = found.toList()
        }

        while (true) {
            val b = runtime.invoke("build.log", Bundle().apply { putInt("offset", offset) })
            val chunk = b.getString("text").orEmpty()
            if (chunk.isNotEmpty()) {
                sb.append(chunk)
                if (sb.length > 30_000) sb.delete(0, sb.length - 30_000)
                logText = sb.toString()
                scan(chunk)
            }
            offset = b.getInt("next", offset)
            val st = b.getInt("state")
            if (st != 1) {
                scan("\n") // дочитать хвост без перевода строки
                result = when (st) {
                    2 -> "Успех"
                    3 -> "Ошибка сборки"
                    4 -> "Отменено"
                    else -> null
                }
                apk = b.getString("apk")
                break
            }
            delay(700)
        }
        building = false
    }

    suspend fun startBuild() {
        result = null
        apk = null
        logText = ""
        issues = emptyList()
        val r = runtime.invoke(
            "build.start",
            Bundle().apply { putString("project", project.absolutePath); putString("task", "assembleDebug") },
        )
        val err = r.getString("error")
        if (err != null) result = err else follow()
    }

    LaunchedEffect(project, connected) {
        // Если сборка уже идёт (экран открыт заново) — подхватываем лог.
        if (connected && !pendingBuild && runtime.invoke("build.log").getInt("state") == 1) follow()
    }

    // «Сохранить и собрать» из редактора.
    LaunchedEffect(pendingBuild, connected) {
        if (pendingBuild && connected) {
            onPendingConsumed()
            if (!building) startBuild()
        }
    }

    Text("Проект: ${project.name}", style = MaterialTheme.typography.titleMedium)
    Button(enabled = connected && !building, onClick = {
        scope.launch { startBuild() }
    }) { Text(if (building) "Идёт сборка…" else "Собрать (assembleDebug)") }
    if (building) {
        OutlinedButton(onClick = { scope.launch { runtime.invoke("build.cancel") } }) { Text("Отменить сборку") }
    }
    result?.let { Text(it, style = MaterialTheme.typography.titleSmall) }
    apk?.let { path ->
        Button(onClick = { installApkFile(context, File(path)) }) { Text("Установить APK") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { apkSaver.launch(File(path).name) }) { Text("Сохранить APK…") }
            OutlinedButton(onClick = { shareApkFile(context, File(path)) }) { Text("Поделиться") }
        }
        saveMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
    if (issues.isNotEmpty()) {
        Text("Ошибки (${issues.size}) — нажмите, чтобы открыть:", style = MaterialTheme.typography.titleSmall)
        issues.forEach { issue ->
            TextButton(onClick = { onOpenIssue(issue.file, issue.line) }) {
                Text("${issue.file.name}:${issue.line} — ${issue.message}", maxLines = 3)
            }
        }
    }
    if (logText.isNotEmpty()) {
        SelectionContainer {
            Text(logText, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }
    }
}

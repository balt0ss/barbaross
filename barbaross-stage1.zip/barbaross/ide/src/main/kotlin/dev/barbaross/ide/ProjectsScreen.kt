package dev.barbaross.ide

import android.os.Bundle
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import dev.barbaross.ide.runtime.RuntimeClient
import dev.barbaross.ide.runtime.RuntimeState
import dev.barbaross.runtime.ProjectTemplates
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private fun listProjects(dir: File): List<File> =
    dir.listFiles { f -> f.isDirectory }?.sortedBy { it.name } ?: emptyList()

/** Проекты в filesDir/projects: создание из шаблона, сборка Gradle с живым логом, отмена, установка APK. */
@Composable
fun ProjectsScreen(runtime: RuntimeClient, state: RuntimeState) {
    val context = LocalContext.current
    val projectsDir = remember { File(context.filesDir, "projects").apply { mkdirs() } }
    var projects by remember { mutableStateOf(listProjects(projectsDir)) }
    var selected by remember { mutableStateOf<File?>(null) }
    var newName by remember { mutableStateOf("hello") }
    var openFile by remember { mutableStateOf<File?>(null) }
    var tab by remember { mutableIntStateOf(0) } // 0 — файлы, 1 — сборка
    var pendingBuild by remember { mutableStateOf(false) }

    val editing = openFile
    if (editing != null) {
        EditorScreen(
            file = editing,
            onClose = { openFile = null },
            onSaveAndBuild = { openFile = null; tab = 1; pendingBuild = true },
        )
        return
    }

    Text("Новый проект (Kotlin + Compose)")
    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Имя") }, singleLine = true)
    Button(onClick = {
        selected = ProjectTemplates.createComposeApp(projectsDir, newName)
        projects = listProjects(projectsDir)
    }) { Text("Создать проект") }

    if (projects.isEmpty()) {
        Text("Проектов пока нет.")
    } else {
        Text("Проекты", style = MaterialTheme.typography.titleMedium)
        projects.forEach { p ->
            TextButton(onClick = { selected = p }) {
                Text(if (p == selected) "▶ ${p.name}" else p.name)
            }
        }
    }
    selected?.let { project ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab == 0) Button(onClick = { tab = 0 }) { Text("Файлы") } else OutlinedButton(onClick = { tab = 0 }) { Text("Файлы") }
            if (tab == 1) Button(onClick = { tab = 1 }) { Text("Сборка") } else OutlinedButton(onClick = { tab = 1 }) { Text("Сборка") }
        }
        if (tab == 0) {
            FileBrowser(project, onOpen = { openFile = it })
        } else {
            BuildPanel(runtime, state, project, pendingBuild, onPendingConsumed = { pendingBuild = false })
        }
    }
}

@Composable
private fun BuildPanel(
    runtime: RuntimeClient,
    state: RuntimeState,
    project: File,
    pendingBuild: Boolean,
    onPendingConsumed: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var building by remember(project) { mutableStateOf(false) }
    var logText by remember(project) { mutableStateOf("") }
    var result by remember(project) { mutableStateOf<String?>(null) }
    var apk by remember(project) { mutableStateOf<String?>(null) }
    val connected = state is RuntimeState.Connected

    suspend fun follow() {
        building = true
        var offset = 0
        val sb = StringBuilder()
        while (true) {
            val b = runtime.invoke("build.log", Bundle().apply { putInt("offset", offset) })
            val chunk = b.getString("text").orEmpty()
            if (chunk.isNotEmpty()) {
                sb.append(chunk)
                if (sb.length > 30_000) sb.delete(0, sb.length - 30_000)
                logText = sb.toString()
            }
            offset = b.getInt("next", offset)
            val st = b.getInt("state")
            if (st != 1) {
                result = when (st) {
                    2 -> "Успех"
                    3 -> "Ошибка сборки"
                    4 -> "Отменено"
                    else -> null
                }
                apk = b.getString("apk")
                break
            }
            delay(700)
        }
        building = false
    }

    suspend fun startBuild() {
        result = null
        apk = null
        logText = ""
        val r = runtime.invoke(
            "build.start",
            Bundle().apply { putString("project", project.absolutePath); putString("task", "assembleDebug") },
        )
        val err = r.getString("error")
        if (err != null) result = err else follow()
    }

    LaunchedEffect(project, connected) {
        // Если сборка уже идёт (экран открыт заново) — подхватываем лог.
        if (connected && !pendingBuild && runtime.invoke("build.log").getInt("state") == 1) follow()
    }

    // «Сохранить и собрать» из редактора.
    LaunchedEffect(pendingBuild, connected) {
        if (pendingBuild && connected) {
            onPendingConsumed()
            if (!building) startBuild()
        }
    }

    Text("Проект: ${project.name}", style = MaterialTheme.typography.titleMedium)
    Button(enabled = connected && !building, onClick = {
        scope.launch { startBuild() }
    }) { Text(if (building) "Идёт сборка…" else "Собрать (assembleDebug)") }
    if (building) {
        OutlinedButton(onClick = { scope.launch { runtime.invoke("build.cancel") } }) { Text("Отменить сборку") }
    }
    result?.let { Text(it, style = MaterialTheme.typography.titleSmall) }
    apk?.let { path ->
        Button(onClick = { installApkFile(context, File(path)) }) { Text("Установить APK") }
    }
    if (logText.isNotEmpty()) {
        SelectionContainer {
            Text(logText, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
        }
    }
}

package dev.barbaross.ipc

import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.os.IInterface
import android.os.Parcel

/**
 * Контракт между Barbaross IDE и Barbaross Build Runtime.
 *
 * Написан вручную (без AIDL), потому что инструмент `aidl` из Android Build Tools
 * существует только под x86_64 и не запускается на arm64-телефоне, где идёт сборка.
 * Wire-формат стандартный для Binder: проверка interface token, затем аргументы.
 *
 * Версионирование: BuildProtocol.VERSION. Новые методы — только в конец, с новым кодом транзакции.
 */
interface IBuildService : IInterface {
    /** Версия протокола, которую реализует Runtime. */
    fun getProtocolVersion(): Int

    /** Проверка связи: возвращает переданную строку. */
    fun ping(payload: String?): String

    /** Состояние инструментов (ключи BuildProtocol.KEY_*). */
    fun getToolchainStatus(): Bundle

    /** Диагностика исполнения (протокол v2): текстовый отчёт о том, что разрешает система. */
    fun runDiagnostics(): String

    /** Протокол v3: запуск эксперимента с JDK в фоне. false — уже выполняется. */
    fun startJdkProbe(): Boolean

    /** Протокол v3: текущий отчёт эксперимента; первая строка — [выполняется] или [завершено]. */
    fun getJdkProbeStatus(): String

    /** Протокол v4: эксперимент с Gradle (требует установленный JDK из пробы JDK). */
    fun startGradleProbe(): Boolean

    fun getGradleProbeStatus(): String

    /** Протокол v5: эксперимент со сборкой Android-приложения (требует пробы JDK и Gradle). */
    fun startAndroidBuildProbe(): Boolean

    fun getAndroidBuildProbeStatus(): String

    /** Протокол v6: то же для проекта на Kotlin + Compose. */
    fun startComposeBuildProbe(): Boolean

    fun getComposeBuildProbeStatus(): String

    /**
     * Протокол v7: универсальный вызов по имени метода (новые функции добавляются без правки транзакций).
     * Методы: toolchain.status, toolchain.install.start|status|cancel, build.start|log|cancel.
     * Ошибка возвращается как ключ "error" в результате.
     */
    fun invoke(method: String, args: Bundle): Bundle

    /** Серверная сторона: наследуется в Runtime. */
    abstract class Stub : Binder(), IBuildService {
        init {
            attachInterface(this, DESCRIPTOR)
        }

        override fun asBinder(): IBinder = this

        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            when (code) {
                IBinder.INTERFACE_TRANSACTION -> {
                    reply?.writeString(DESCRIPTOR)
                    return true
                }
                TX_GET_PROTOCOL_VERSION -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getProtocolVersion()
                    reply?.writeNoException()
                    reply?.writeInt(result)
                    return true
                }
                TX_PING -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = ping(data.readString())
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_GET_TOOLCHAIN_STATUS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getToolchainStatus()
                    reply?.writeNoException()
                    reply?.writeBundle(result)
                    return true
                }
                TX_RUN_DIAGNOSTICS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = runDiagnostics()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_START_JDK_PROBE -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = startJdkProbe()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TX_GET_JDK_PROBE_STATUS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getJdkProbeStatus()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_START_GRADLE_PROBE -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = startGradleProbe()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TX_GET_GRADLE_PROBE_STATUS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getGradleProbeStatus()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_START_ANDROID_BUILD_PROBE -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = startAndroidBuildProbe()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TX_GET_ANDROID_BUILD_PROBE_STATUS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getAndroidBuildProbeStatus()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_START_COMPOSE_BUILD_PROBE -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = startComposeBuildProbe()
                    reply?.writeNoException()
                    reply?.writeInt(if (result) 1 else 0)
                    return true
                }
                TX_GET_COMPOSE_BUILD_PROBE_STATUS -> {
                    data.enforceInterface(DESCRIPTOR)
                    val result = getComposeBuildProbeStatus()
                    reply?.writeNoException()
                    reply?.writeString(result)
                    return true
                }
                TX_INVOKE -> {
                    data.enforceInterface(DESCRIPTOR)
                    val method = data.readString().orEmpty()
                    val args = data.readBundle(IBuildService::class.java.classLoader) ?: Bundle.EMPTY
                    val result = invoke(method, args)
                    reply?.writeNoException()
                    reply?.writeBundle(result)
                    return true
                }
            }
            return super.onTransact(code, data, reply, flags)
        }

        companion object {
            const val DESCRIPTOR = "dev.barbaross.ipc.IBuildService"
            const val TX_GET_PROTOCOL_VERSION = IBinder.FIRST_CALL_TRANSACTION
            const val TX_PING = IBinder.FIRST_CALL_TRANSACTION + 1
            const val TX_GET_TOOLCHAIN_STATUS = IBinder.FIRST_CALL_TRANSACTION + 2
            const val TX_RUN_DIAGNOSTICS = IBinder.FIRST_CALL_TRANSACTION + 3
            const val TX_START_JDK_PROBE = IBinder.FIRST_CALL_TRANSACTION + 4
            const val TX_GET_JDK_PROBE_STATUS = IBinder.FIRST_CALL_TRANSACTION + 5
            const val TX_START_GRADLE_PROBE = IBinder.FIRST_CALL_TRANSACTION + 6
            const val TX_GET_GRADLE_PROBE_STATUS = IBinder.FIRST_CALL_TRANSACTION + 7
            const val TX_START_ANDROID_BUILD_PROBE = IBinder.FIRST_CALL_TRANSACTION + 8
            const val TX_GET_ANDROID_BUILD_PROBE_STATUS = IBinder.FIRST_CALL_TRANSACTION + 9
            const val TX_START_COMPOSE_BUILD_PROBE = IBinder.FIRST_CALL_TRANSACTION + 10
            const val TX_GET_COMPOSE_BUILD_PROBE_STATUS = IBinder.FIRST_CALL_TRANSACTION + 11
            const val TX_INVOKE = IBinder.FIRST_CALL_TRANSACTION + 12

            /** Клиентская сторона: оборачивает IBinder в интерфейс. */
            fun asInterface(binder: IBinder?): IBuildService? {
                if (binder == null) return null
                val local = binder.queryLocalInterface(DESCRIPTOR)
                if (local is IBuildService) return local
                return IBuildServiceProxy(binder)
            }
        }
    }
}

internal class IBuildServiceProxy(private val remote: IBinder) : IBuildService {
    override fun asBinder(): IBinder = remote

    override fun getProtocolVersion(): Int = call(IBuildService.Stub.TX_GET_PROTOCOL_VERSION, {}) { it.readInt() }

    override fun ping(payload: String?): String =
        call(IBuildService.Stub.TX_PING, { it.writeString(payload) }) { it.readString().orEmpty() }

    override fun getToolchainStatus(): Bundle =
        call(IBuildService.Stub.TX_GET_TOOLCHAIN_STATUS, {}) {
            it.readBundle(IBuildService::class.java.classLoader) ?: Bundle.EMPTY
        }

    override fun runDiagnostics(): String =
        call(IBuildService.Stub.TX_RUN_DIAGNOSTICS, {}) { it.readString().orEmpty() }

    override fun startJdkProbe(): Boolean =
        call(IBuildService.Stub.TX_START_JDK_PROBE, {}) { it.readInt() != 0 }

    override fun getJdkProbeStatus(): String =
        call(IBuildService.Stub.TX_GET_JDK_PROBE_STATUS, {}) { it.readString().orEmpty() }

    override fun startGradleProbe(): Boolean =
        call(IBuildService.Stub.TX_START_GRADLE_PROBE, {}) { it.readInt() != 0 }

    override fun getGradleProbeStatus(): String =
        call(IBuildService.Stub.TX_GET_GRADLE_PROBE_STATUS, {}) { it.readString().orEmpty() }

    override fun startAndroidBuildProbe(): Boolean =
        call(IBuildService.Stub.TX_START_ANDROID_BUILD_PROBE, {}) { it.readInt() != 0 }

    override fun getAndroidBuildProbeStatus(): String =
        call(IBuildService.Stub.TX_GET_ANDROID_BUILD_PROBE_STATUS, {}) { it.readString().orEmpty() }

    override fun startComposeBuildProbe(): Boolean =
        call(IBuildService.Stub.TX_START_COMPOSE_BUILD_PROBE, {}) { it.readInt() != 0 }

    override fun getComposeBuildProbeStatus(): String =
        call(IBuildService.Stub.TX_GET_COMPOSE_BUILD_PROBE_STATUS, {}) { it.readString().orEmpty() }

    override fun invoke(method: String, args: Bundle): Bundle =
        call(IBuildService.Stub.TX_INVOKE, { it.writeString(method); it.writeBundle(args) }) {
            it.readBundle(IBuildService::class.java.classLoader) ?: Bundle.EMPTY
        }

    private inline fun <T> call(code: Int, write: (Parcel) -> Unit, read: (Parcel) -> T): T {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        try {
            data.writeInterfaceToken(IBuildService.Stub.DESCRIPTOR)
            write(data)
            remote.transact(code, data, reply, 0)
            reply.readException()
            return read(reply)
        } finally {
            reply.recycle()
            data.recycle()
        }
    }
}
